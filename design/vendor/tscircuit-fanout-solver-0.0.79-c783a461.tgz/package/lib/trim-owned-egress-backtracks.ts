import type { Point2D } from "./types"
const EPSILON = 1e-9
/** Clip only retraced portions of freshly owned source copper. Every surviving
* edge occupies a subset of the original polyline; foreign copper is never
* traversed or moved by this normalization. */
export function trimOwnedEgressBacktracks(points: readonly Point2D[]): Point2D[] {
  const trimmed: Point2D[] = []
  for (const point of points) {
    if (trimmed.length && Math.hypot(point.x - trimmed.at(-1)!.x, point.y - trimmed.at(-1)!.y) < EPSILON)
      continue
    while (trimmed.length >= 2) {
      const a = trimmed.at(-2)!, b = trimmed.at(-1)!
      const ix = b.x - a.x, iy = b.y - a.y, ox = point.x - b.x, oy = point.y - b.y
      const cross = ix * oy - iy * ox, dot = ix * ox + iy * oy
      if (dot >= 0 || Math.abs(cross) > EPSILON * Math.min(Math.hypot(ix, iy), Math.hypot(ox, oy)))
        break
      trimmed.pop()
    }
    if (!trimmed.length || Math.hypot(point.x - trimmed.at(-1)!.x, point.y - trimmed.at(-1)!.y) >= EPSILON)
      trimmed.push({ ...point })
  }
  return trimmed
}
