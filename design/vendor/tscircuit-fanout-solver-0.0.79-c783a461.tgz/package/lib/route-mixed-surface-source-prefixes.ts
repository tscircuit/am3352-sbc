import type { Obstacle, SimpleRouteJson } from "@tscircuit/capacity-autorouter"
import { getCopperLayerNames } from "./layer-names"
import { matchComponentDogboneViaSites, getComponentDogboneViaSiteCandidates } from "./match-component-dogbone-via-sites"
import { routeSingleLayerWithAdaptiveExitsSteps } from "./route-single-layer-adaptive-exits"
import { routeViaMinimalWindingAlternativesSteps } from "./route-via-minimal-winding"
import { validateRoutedCopperDrc } from "./validate-routed-copper-drc"
import { normalizeFreshSourceFolds } from "./normalize-fresh-source-folds"
import { changedFanoutCopperIsSelfClear } from "./normalize-fanout-plan-corners"
import { getSourcePadReentries } from "./source-pad-reentry"
import type { FanoutRoutePlan, Point2D, PreparedBus } from "./types"
export interface MixedSurfaceSourcePrefixParams {
  srj: SimpleRouteJson
  /** Independent singleton buses without explicit boundary targets. */
  buses: PreparedBus[]
  traceWidth: number
  clearance: number
  viaDiameter: number
  viaHoleDiameter: number
  gridStep: number
  maximumConnectorAttempts?: number
  maximumSourceLayerRounds?: number
  /** Bounded joint via-site revisions when a required source-layer path is blocked. */
  maximumSiteAlternatives?: number
  maximumWindingAttempts?: number
  maximumWindingSearchStates?: number
  onProgress?: (progress: {
    phase: string
    sourceCount: number
    bridgeCount: number
    sourceConnectionIndexes?: number[]
    bridgeConnectionIndexes?: number[]
  }) => void
}
function sourceReservations(buses: PreparedBus[], sites: ReadonlyMap<number, Point2D>, layerNames: string[], traceWidth: number, viaDiameter: number): Array<Obstacle & {
  shape?: "circle"
}> {
  return buses.flatMap(bus => bus.connections.flatMap(connection => {
    const site = sites.get(connection.connectionIndex)
    if (!site)
      throw new Error("Mixed source prefix has no matched via site")
    const source = connection.sourcePoint
    return [{ type: "rect" as const, center: { x: (source.x + site.x) / 2, y: (source.y + site.y) / 2 },
        width: Math.hypot(source.x - site.x, source.y - site.y) + traceWidth,
        height: traceWidth, layers: [connection.sourceLayer], connectedTo: [connection.connection.name],
        ccwRotationDegrees: Math.atan2(site.y - source.y, site.x - source.x) * 180 / Math.PI },
      { type: "rect" as const, shape: "circle" as const, center: site, width: viaDiameter, height: viaDiameter, layers: layerNames, connectedTo: [connection.connection.name] }]
  }))
}
function spacedExitGuidance(exits: Array<{
  connectionIndex: number
  exitPoint: Point2D
}>, boundary: PreparedBus["sharedBoundary"], pitch: number): Map<number, Point2D> {
  // A sampled grid perimeter can miss the exact boundary by a fraction of a
  // cell. These points guide a fresh winding search, so project the targets
  // onto the actual boundary before manufacturing any copper.
  const targets = new Map(exits.map(exit => {
    const point = { x: Math.max(boundary.minX, Math.min(boundary.maxX, exit.exitPoint.x)), y: Math.max(boundary.minY, Math.min(boundary.maxY, exit.exitPoint.y)) }
    const edges = [
      { distance: Math.abs(point.x - boundary.minX), axis: "x" as const, value: boundary.minX },
      { distance: Math.abs(point.x - boundary.maxX), axis: "x" as const, value: boundary.maxX },
      { distance: Math.abs(point.y - boundary.minY), axis: "y" as const, value: boundary.minY },
      { distance: Math.abs(point.y - boundary.maxY), axis: "y" as const, value: boundary.maxY },
    ].sort((a, b) => a.distance - b.distance)
    point[edges[0]!.axis] = edges[0]!.value
    return [exit.connectionIndex, point] as const
  }))
  const edgeOf = (point: Point2D): string => Math.abs(point.x - boundary.minX) < 1e-7 ? "left" : Math.abs(point.x - boundary.maxX) < 1e-7 ? "right" : Math.abs(point.y - boundary.minY) < 1e-7 ? "bottom" : "top"
  for (const edge of ["left", "right", "bottom", "top"]) {
    const axis = edge === "left" || edge === "right" ? "y" : "x"
    const group = [...targets.values()].filter(point => edgeOf(point) === edge).sort((a, b) => a[axis] - b[axis])
    let previous = -Infinity
    for (const point of group) {
      point[axis] = Math.max(point[axis], previous + pitch)
      previous = point[axis]
    }
    const maximum = axis === "x" ? boundary.maxX : boundary.maxY
    if (previous > maximum + 1e-7)
      return new Map()
  }
  return targets
}
/** Compute every independent source prefix on the two actual outside layers.
* The original native endpoints remain authoritative for downstream routing.
* Provisional flow paths supply boundary guidance only; manufactured winding
* paths and the final copper gate establish acceptance. Partial sets return null.
*/
export function* routeMixedSurfaceSourcePrefixesSteps(params: MixedSurfaceSourcePrefixParams): Generator<void, FanoutRoutePlan[] | null> {
  const { srj, buses, traceWidth, clearance, viaDiameter, viaHoleDiameter, gridStep } = params
  if (!buses.length)
    return []
  if (new Set(buses.map(bus => bus.busId)).size !== buses.length ||
    new Set(buses.flatMap(bus => bus.connections.map(connection => connection.connectionIndex))).size !== buses.reduce((count, bus) => count + bus.connections.length, 0))
    throw new Error("Mixed source prefixes require unique bus and connection identities")
  const sharedBoundary = buses[0]!.sharedBoundary
  if (buses.some(bus => (["minX", "maxX", "minY", "maxY"] as const).some(axis => bus.sharedBoundary[axis] !== sharedBoundary[axis])))
    throw new Error("Mixed source prefixes require one shared boundary")
  for (const [name, value, minimum, maximum] of [
    ["maximumSourceLayerRounds", params.maximumSourceLayerRounds ?? 4, 1, 16],
    ["maximumSiteAlternatives", params.maximumSiteAlternatives ?? 8, 0, 64],
  ] as const)
    if (!Number.isInteger(value) || value < minimum || value > maximum)
      throw new Error(`${name} must be an integer between ${minimum} and ${maximum}`)
  for (const [name, value] of [
    ["maximumWindingAttempts", params.maximumWindingAttempts ?? 120],
    ["maximumWindingSearchStates", params.maximumWindingSearchStates ?? 100000],
  ] as const)
    if (!Number.isSafeInteger(value) || value < 1)
      throw new Error(`${name} must be a positive safe integer`)
  if (buses.some(bus => bus.termination.type !== "boundary" || bus.exitEdge !== undefined || bus.connections.length !== 1 || bus.connections[0]!.hasExplicitLayeredExitTarget ||
    bus.connections[0]!.exitTargetPoint && (Math.abs(bus.connections[0]!.exitTargetPoint!.x - bus.connections[0]!.targetPoint.x) > 1e-9 || Math.abs(bus.connections[0]!.exitTargetPoint!.y - bus.connections[0]!.targetPoint.y) > 1e-9)))
    return null
  const layerNames = getCopperLayerNames(srj.layerCount), sourceLayer = buses[0]!.connections[0]!.sourceLayer
  if (!layerNames.includes(sourceLayer) || buses.some(bus => bus.connections[0]!.sourceLayer !== sourceLayer))
    return null
  const surfaceLayers = [layerNames[0]!, layerNames.at(-1)!]
  if (!surfaceLayers.includes(sourceLayer) || (srj as SimpleRouteJson & {
    allowBlindAndBuriedVias?: boolean
  }).allowBlindAndBuriedVias === true)
    return null
  const bridgeLayer = surfaceLayers.find(layer => layer !== sourceLayer)!
  const validateComplete = (provisional: readonly FanoutRoutePlan[]): FanoutRoutePlan[] | null => {
    const plans = normalizeFreshSourceFolds({ inputSrj: srj, plans: provisional, clearance })
    const inside = (point: Point2D): boolean => point.x >= sharedBoundary.minX - 1e-7 && point.x <= sharedBoundary.maxX + 1e-7 && point.y >= sharedBoundary.minY - 1e-7 && point.y <= sharedBoundary.maxY + 1e-7
    const atBoundary = (point: Point2D): boolean => inside(point) && ([Math.abs(point.x - sharedBoundary.minX), Math.abs(point.x - sharedBoundary.maxX), Math.abs(point.y - sharedBoundary.minY), Math.abs(point.y - sharedBoundary.maxY)].some(distance => distance < 1e-7))
    if (!plans || plans.length !== buses.length || new Set(plans.map(plan => plan.connectionIndex)).size !== buses.length || plans.some(plan =>
      !buses.some(bus => bus.busId === plan.busId && bus.connections[0]!.connectionIndex === plan.connectionIndex) ||
      !atBoundary(plan.exitPoint) || plan.segments.some(segment => !inside(segment.start) || !inside(segment.end)) ||
      getSourcePadReentries(plan, clearance).length || !changedFanoutCopperIsSelfClear(plan, plan.segments, clearance, new Set(plan.segments.map((_, index) => index))))) return null
    const drc = validateRoutedCopperDrc({ inputSrj: srj, routedSrj: { ...srj, traces: [...(srj.traces ?? []), ...plans.map(plan => plan.trace)] }, clearance, allowBlindAndBuriedVias: false })
    return drc.valid ? plans : null
  }
  const rules = { traceWidth, clearance, viaDiameter, viaHoleDiameter, expandLocalSites: true, additionalObstacles: srj.obstacles }
  const allowed = (bus: PreparedBus, layer: string): boolean => (bus.routableEscapeLayers ?? bus.allowedLayers ?? surfaceLayers).includes(layer)
  if (buses.some(bus => !surfaceLayers.some(layer => allowed(bus, layer))))
    return null
  const mandatorySource = new Set(buses.filter(bus => !allowed(bus, bridgeLayer) || getComponentDogboneViaSiteCandidates([bus], rules).length === 0).map(bus => bus.connections[0]!.connectionIndex))
  let unavailable: number[] | undefined
  const domains = routeSingleLayerWithAdaptiveExitsSteps({ srj, buses, traceWidth, clearance, gridStep, rankConnectorsByBoundaryReachability: true, maximumConnectorAttempts: 1,
    onSourceBoundaryDomains: values => { unavailable = values.filter(value => value.reachableConnectorCount === 0).map(value => value.connectionIndex); } })
  let domainStep = domains.next()
  while (!domainStep.done && unavailable === undefined) {
    yield
    domainStep = domains.next()
  }
  if (!domainStep.done)
    domains.return(null)
  const bridgeIndices = new Set([...(unavailable ?? []), ...buses.filter(bus => !allowed(bus, sourceLayer)).map(bus => bus.connections[0]!.connectionIndex)])
  params.onProgress?.({ phase: "source-domains", sourceCount: buses.length - bridgeIndices.size, bridgeCount: bridgeIndices.size })
  if ([...bridgeIndices].some(index => mandatorySource.has(index)))
    return null
  let sites = new Map<number, Point2D>(), sourcePlans: FanoutRoutePlan[] = []
  function* findSourcePlans(scene: SimpleRouteJson, sourceBuses: PreparedBus[]): Generator<void, FanoutRoutePlan[]> {
    let best: FanoutRoutePlan[] = [], bestMandatoryCount = -1
    const remember = (plans: FanoutRoutePlan[]): void => {
      const ids = new Set(plans.map(plan => plan.connectionIndex))
      const mandatoryCount = [...mandatorySource].filter(index => ids.has(index)).length
      if (mandatoryCount > bestMandatoryCount || mandatoryCount === bestMandatoryCount && plans.length > best.length) {
        best = plans
        bestMandatoryCount = mandatoryCount
      }
    }
    const flow = routeSingleLayerWithAdaptiveExitsSteps({ srj: scene, buses: sourceBuses, traceWidth, clearance, gridStep, rankConnectorsByBoundaryReachability: true, maximumConnectorAttempts: params.maximumConnectorAttempts ?? 8, prioritySourceConnectionIndexes: mandatorySource, onPartialRoutes: remember })
    let next = flow.next()
    while (!next.done) {
      yield
      next = flow.next()
    }
    if (next.value)
      remember(next.value)
    return best
  }
  const maximumRounds = params.maximumSourceLayerRounds ?? 4
  for (let round = 0; round < maximumRounds; round++) {
    const bridgeBuses = buses.filter(bus => bridgeIndices.has(bus.connections[0]!.connectionIndex))
    const matched = matchComponentDogboneViaSites(bridgeBuses, { ...rules, preferredViaPointsByConnectionIndex: sites })
    if (!matched)
      return null
    sites = matched
    const reservations = sourceReservations(bridgeBuses, sites, layerNames, traceWidth, viaDiameter)
    const scene = { ...srj, obstacles: [...srj.obstacles, ...reservations] }
    const sourceBuses = buses.filter(bus => !bridgeIndices.has(bus.connections[0]!.connectionIndex))
    let best = yield* findSourcePlans(scene, sourceBuses)
    const presentMandatory = (plans: FanoutRoutePlan[]) => new Set(plans.map(plan => plan.connectionIndex))
    if ([...mandatorySource].some(index => !presentMandatory(best).has(index)) &&
      sourceBuses.every(bus => presentMandatory(best).has(bus.connections[0]!.connectionIndex) || mandatorySource.has(bus.connections[0]!.connectionIndex))) {
      // Local conventional sites can close another source's only package
      // corridor. Revise provisional same-phase sites, then reroute the complete
      // source cohort. Every alternative comes from the native matcher domains.
      const seen = new Set([JSON.stringify([...sites])])
      let attempted = 0
      const candidates = getComponentDogboneViaSiteCandidates(bridgeBuses, rules)
      for (const candidate of candidates) {
        if (attempted >= (params.maximumSiteAlternatives ?? 8))
          break
        const original = sites.get(candidate.connectionIndex)!
        if (Math.hypot(original.x - candidate.point.x, original.y - candidate.point.y) < 1e-9)
          continue
        const alternative = matchComponentDogboneViaSites(bridgeBuses, { ...rules, fixedViaPointsByConnectionIndex: new Map([[candidate.connectionIndex, candidate.point]]), preferredViaPointsByConnectionIndex: sites })
        if (!alternative)
          continue
        const key = JSON.stringify([...alternative])
        if (seen.has(key))
          continue
        seen.add(key)
        attempted++
        const alternativeScene = { ...srj, obstacles: [...srj.obstacles, ...sourceReservations(bridgeBuses, alternative, layerNames, traceWidth, viaDiameter)] }
        const plans = yield* findSourcePlans(alternativeScene, sourceBuses)
        params.onProgress?.({ phase: "source-site-alternative", sourceCount: plans.length, bridgeCount: bridgeIndices.size, sourceConnectionIndexes: plans.map(plan => plan.connectionIndex), bridgeConnectionIndexes: [...bridgeIndices] })
        if ([...mandatorySource].every(index => presentMandatory(plans).has(index))) {
          best = plans
          sites = alternative
          break
        }
      }
    }
    params.onProgress?.({ phase: "source-flow", sourceCount: best.length, bridgeCount: bridgeIndices.size, sourceConnectionIndexes: best.map(plan => plan.connectionIndex), bridgeConnectionIndexes: [...bridgeIndices] })
    if (!best.length && sourceBuses.length)
      return null
    const present = new Set(best.map(plan => plan.connectionIndex))
    const missing = buses.filter(bus => !present.has(bus.connections[0]!.connectionIndex))
    const jointSites = missing.some(bus => mandatorySource.has(bus.connections[0]!.connectionIndex)) ? null : matchComponentDogboneViaSites(missing, { ...rules, preferredViaPointsByConnectionIndex: sites,
      blockingSegments: best.flatMap(plan => plan.segments.map(segment => ({ connectionIndex: plan.connectionIndex, segment }))) })
    if (jointSites) {
      sourcePlans = best
      sites = jointSites
      for (const bus of missing)
        bridgeIndices.add(bus.connections[0]!.connectionIndex)
      break
    }
    const previousSize = bridgeIndices.size
    for (const bus of missing)
      if (!mandatorySource.has(bus.connections[0]!.connectionIndex))
        bridgeIndices.add(bus.connections[0]!.connectionIndex)
    if (bridgeIndices.size === previousSize || round === maximumRounds - 1)
      return null
  }
  const bridgeBuses = buses.filter(bus => bridgeIndices.has(bus.connections[0]!.connectionIndex))
  if (!bridgeBuses.length)
    return validateComplete(sourcePlans)
  const reservations = sourceReservations(bridgeBuses, sites, layerNames, traceWidth, viaDiameter)
  const scene = { ...srj, obstacles: [...srj.obstacles, ...reservations] }
  const connections = bridgeBuses.flatMap(bus => bus.connections)
  const bridgeAtSites = bridgeBuses.map(bus => ({ ...bus, connections: bus.connections.map(connection => ({ ...connection,
      sourcePoint: { ...sites.get(connection.connectionIndex)!, layer: bridgeLayer }, sourceLayer: bridgeLayer,
      sourceObstacle: reservations.find(obstacle => obstacle.shape === "circle" && obstacle.connectedTo.includes(connection.connection.name))! })) }))
  const guidance: Array<Array<{
    connectionIndex: number
    exitPoint: Point2D
  }>> = []
  const flow = routeSingleLayerWithAdaptiveExitsSteps({ srj: scene, buses: bridgeAtSites, traceWidth, clearance, gridStep, maximumConnectorAttempts: 24, onFlowExitCandidates: values => guidance.push(values) })
  let next = flow.next()
  while (!next.done) {
    yield
    next = flow.next()
  }
  if (next.value)
    guidance.unshift(next.value.map(plan => ({ connectionIndex: plan.connectionIndex, exitPoint: plan.exitPoint })))
  params.onProgress?.({ phase: "bridge-exit-guidance", sourceCount: sourcePlans.length, bridgeCount: guidance.length })
  for (const exits of guidance) {
    const boundary = bridgeBuses[0]!.sharedBoundary, targets = spacedExitGuidance(exits, boundary, traceWidth + clearance + gridStep / 10)
    if (targets.size !== connections.length)
      continue
    const bus = { ...bridgeBuses[0]!, busId: "mixed-source-bridge", direction: "right" as const, preferredExit: "right" as const, exitEdge: "right" as const, connections }
    const winding = routeViaMinimalWindingAlternativesSteps({ srj: scene, bus, targetLayer: bridgeLayer,
      terminals: connections.map(connection => ({ connection, viaPoint: sites.get(connection.connectionIndex)!, exitPoint: targets.get(connection.connectionIndex)! })),
      acceptedPlans: sourcePlans, layerNames, traceWidth, clearance, viaDiameter, viaHoleDiameter, allowBlindAndBuriedVias: false, allowSameNetMerges: true,
      gridStep, maximumRouteOrderAttempts: params.maximumWindingAttempts ?? 120, maximumSearchStates: params.maximumWindingSearchStates ?? 100000, heuristicWeight: 1.25, reserveTerminalExitPoints: true, adaptiveRouteOrder: true,
      sourceEscapePaths: new Map(connections.map(connection => [connection.connectionIndex, [connection.sourcePoint, sites.get(connection.connectionIndex)!]])) }, 1)
    let result = winding.next()
    while (!result.done) {
      yield
      result = winding.next()
    }
    const woundBridgePlans = result.value[0]
    if (!woundBridgePlans)
      continue
    // Joint winding coordinates copper search only. Preserve each declared
    // singleton bus and its actual boundary edge in the accepted plans.
    const bridgePlans = woundBridgePlans.map((plan): FanoutRoutePlan => {
      const owner = bridgeBuses.find(bus => bus.connections[0]!.connectionIndex === plan.connectionIndex)!
      const boundary = owner.sharedBoundary
      const direction = Math.abs(plan.exitPoint.x - boundary.minX) < 1e-7 ? "left" :
        Math.abs(plan.exitPoint.x - boundary.maxX) < 1e-7 ? "right" :
          Math.abs(plan.exitPoint.y - boundary.minY) < 1e-7 ? "down" : "up"
      owner.direction = direction
      owner.preferredExit = direction === "up" ? "top" : direction === "down" ? "bottom" : direction
      const { exitEdge, ...original } = plan
      return { ...original, busId: owner.busId, direction }
    })
    const plans = validateComplete([...sourcePlans, ...bridgePlans])
    if (plans)
      return plans
  }
  return null
}
