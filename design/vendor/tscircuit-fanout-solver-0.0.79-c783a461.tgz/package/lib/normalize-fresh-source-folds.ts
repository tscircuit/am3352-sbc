import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter"
import { distance, distancePointToSegment, distanceSegmentToObstacle, segmentsAreClear } from "./geometry"
import { changedFanoutCopperIsSelfClear } from "./normalize-fanout-plan-corners"
import { normalizeLayeredPath } from "./normalize-layered-path"
import { getSourcePadReentries } from "./source-pad-reentry"
import { sourcePrefixFoldShortcuts } from "./source-prefix-fold-shortcuts"
import type { FanoutRoutePlan } from "./types"
/** Normalize only newly computed, via-free source prefixes before acceptance.
* Exact native source ports, layers and boundary endpoints remain unchanged.
* Retained prefixes and every physical layer transition are outside this repair.
*/
export function normalizeFreshSourceFolds(params: {
  inputSrj: SimpleRouteJson
  plans: readonly FanoutRoutePlan[]
  clearance: number
}): FanoutRoutePlan[] | null {
  const { inputSrj, clearance } = params
  const plans = [...params.plans]
  for (let index = 0; index < plans.length; index++) {
    const original = plans[index]!
    if (original.trace.route.some(point => point.route_type !== "wire"))
      continue
    const allIndices = new Set(original.segments.map((_, index) => index))
    if (changedFanoutCopperIsSelfClear(original, original.segments, clearance, allIndices) && !getSourcePadReentries(original, clearance).length)
      continue
    const others = plans.filter((_, other) => other !== index), width = original.segments[0]!.width
    const segmentIsClear = (start: {
      x: number
      y: number
    }, end: {
      x: number
      y: number
    }): boolean => {
      const segment = { start, end, layer: original.sourceLayer, width }
      return inputSrj.obstacles.every(obstacle => !obstacle.layers.includes(segment.layer) || obstacle === original.sourceObstacle ||
        distanceSegmentToObstacle(segment, obstacle) >= width / 2 + clearance - 1e-9) &&
        others.every(plan => plan.segments.every(other => other.layer !== segment.layer || segmentsAreClear(segment, other, clearance)) &&
          [plan.via, ...(plan.additionalVias ?? []), plan.planeEndpointVia].filter(via => !!via).every(via => !via.spanLayers.includes(segment.layer) ||
            distancePointToSegment(via.center, start, end) >= (via.diameter + width) / 2 + clearance - 1e-9))
    }
    let repaired: FanoutRoutePlan | undefined
    for (const proposal of sourcePrefixFoldShortcuts({ ...original, sourceEscapeSegmentCount: original.segments.length }, clearance)) {
      const normalized = normalizeLayeredPath({ points: proposal.map(point => ({ ...point, z: 0 })), chamfer: width / 2, repairReversingDiagonalCorners: true, segmentIsClear })
      if (!normalized)
        continue
      const points = normalized.map(({ x, y }) => ({ x, y })), segments = points.slice(1).map((end, index) => ({ start: points[index]!, end, width, layer: original.sourceLayer })), candidate = { ...original, segments, length: segments.reduce((sum, segment) => sum + distance(segment.start, segment.end), 0), trace: { ...original.trace, route: points.map((point, index) => ({ ...point, route_type: "wire" as const, layer: original.sourceLayer, width, ...(index === 0 ? original.trace.route[0] : index === points.length - 1 ? original.trace.route.at(-1) : {}) })) } }
      if (distance(points[0]!, original.sourcePoint) > 1e-7 || distance(points.at(-1)!, original.exitPoint) > 1e-7 || getSourcePadReentries(candidate, clearance).length)
        continue
      if (!changedFanoutCopperIsSelfClear(candidate, segments, clearance, new Set(segments.map((_, index) => index))))
        continue
      repaired = candidate
      break
    }
    if (!repaired)
      return null
    plans[index] = repaired
  }
  return plans
}
