import type {
  ConnectionPoint,
  SimpleRouteJson,
  SimplifiedPcbTrace,
} from "@tscircuit/capacity-autorouter"
import { getCornerBandSide } from "./boundary-exit"
import {
  distance,
  distancePointToObstacle,
  distancePointToSegment,
  distanceSegmentToObstacle,
  distanceSegmentToSegment,
  segmentsAreClear,
} from "./geometry"
import { getAllRoutedTraceCopper } from "./get-routed-trace-copper"
import { getSourcePadReentries } from "./source-pad-reentry"
import {
  connectionsShareElectricalNet,
  obstacleSharesElectricalNet,
} from "./net-identity"
import type {
  Bounds,
  FanoutEdge,
  FanoutRoutePlan,
  FanoutValidationIssue,
  FanoutValidationReport,
  Point2D,
  PreparedBus,
  RoutedSegment,
} from "./types"
import { segmentIsLegalTerminalBodyEscape } from "./validate-routed-copper-drc"

const EPSILON = 1e-6

function pointsMatch(first: Point2D, second: Point2D): boolean {
  return distance(first, second) <= EPSILON
}

function getPointLayers(point: ConnectionPoint): string[] {
  return "layer" in point ? [point.layer] : point.layers
}

function getPlanSegments(plan: FanoutRoutePlan): RoutedSegment[] {
  return [...plan.segments, ...(plan.planeEndpointSegments ?? [])]
}

function getPlanVias(plan: FanoutRoutePlan) {
  return [
    plan.via,
    ...(plan.additionalVias ?? []),
    plan.planeEndpointVia,
  ].filter((via): via is NonNullable<FanoutRoutePlan["via"]> => Boolean(via))
}

function connectionPointsMatch(
  first: ConnectionPoint,
  second: ConnectionPoint,
): boolean {
  return (
    pointsMatch(first, second) &&
    getPointLayers(first).join("\0") === getPointLayers(second).join("\0") &&
    first.pointId === second.pointId &&
    first.pcb_port_id === second.pcb_port_id
  )
}

function pointIsOnBoundary(point: Point2D, boundary: Bounds): boolean {
  const inside =
    point.x >= boundary.minX - EPSILON &&
    point.x <= boundary.maxX + EPSILON &&
    point.y >= boundary.minY - EPSILON &&
    point.y <= boundary.maxY + EPSILON
  const onEdge =
    Math.abs(point.x - boundary.minX) <= EPSILON ||
    Math.abs(point.x - boundary.maxX) <= EPSILON ||
    Math.abs(point.y - boundary.minY) <= EPSILON ||
    Math.abs(point.y - boundary.maxY) <= EPSILON
  return inside && onEdge
}

function pointIsOnBoundaryEdge(
  point: Point2D,
  edge: FanoutEdge,
  boundary: Bounds,
): boolean {
  const inside =
    point.x >= boundary.minX - EPSILON &&
    point.x <= boundary.maxX + EPSILON &&
    point.y >= boundary.minY - EPSILON &&
    point.y <= boundary.maxY + EPSILON
  if (!inside) return false
  switch (edge) {
    case "left":
      return Math.abs(point.x - boundary.minX) <= EPSILON
    case "right":
      return Math.abs(point.x - boundary.maxX) <= EPSILON
    case "top":
      return Math.abs(point.y - boundary.maxY) <= EPSILON
    case "bottom":
      return Math.abs(point.y - boundary.minY) <= EPSILON
  }
}

function pointIsInsideBounds(point: Point2D, bounds: Bounds): boolean {
  return (
    point.x >= bounds.minX - EPSILON &&
    point.x <= bounds.maxX + EPSILON &&
    point.y >= bounds.minY - EPSILON &&
    point.y <= bounds.maxY + EPSILON
  )
}

function addIssue(
  issues: FanoutValidationIssue[],
  code: FanoutValidationIssue["code"],
  message: string,
  plan?: FanoutRoutePlan,
  otherConnectionName?: string,
): void {
  issues.push({
    code,
    message,
    ...(plan
      ? {
          connectionName: plan.connectionName,
          busId: plan.busId,
        }
      : {}),
    ...(otherConnectionName ? { otherConnectionName } : {}),
  })
}

function extractTraceSegments(params: {
  trace: SimplifiedPcbTrace
  plan: FanoutRoutePlan
  issues: FanoutValidationIssue[]
}): RoutedSegment[] {
  const { trace, plan, issues } = params
  const segments: RoutedSegment[] = []
  let previousWire:
    | Extract<SimplifiedPcbTrace["route"][number], { route_type: "wire" }>
    | undefined
  let pendingVia:
    | Extract<SimplifiedPcbTrace["route"][number], { route_type: "via" }>
    | undefined

  for (const routePoint of trace.route) {
    if (routePoint.route_type === "via") {
      if (
        !previousWire ||
        !pointsMatch(previousWire, routePoint) ||
        previousWire.layer !== routePoint.from_layer
      ) {
        addIssue(
          issues,
          "disconnected-trace",
          `Trace ${trace.pcb_trace_id} reaches a via without a matching ${routePoint.from_layer} wire endpoint`,
          plan,
        )
      }
      pendingVia = routePoint
      continue
    }
    if (routePoint.route_type !== "wire") {
      addIssue(
        issues,
        "unsupported-route-point",
        `Trace ${trace.pcb_trace_id} contains unsupported ${routePoint.route_type} geometry`,
        plan,
      )
      continue
    }

    if (pendingVia) {
      if (
        !pointsMatch(routePoint, pendingVia) ||
        routePoint.layer !== pendingVia.to_layer
      ) {
        addIssue(
          issues,
          "disconnected-trace",
          `Trace ${trace.pcb_trace_id} does not continue from its via on ${pendingVia.to_layer}`,
          plan,
        )
      }
      previousWire = routePoint
      pendingVia = undefined
      continue
    }

    if (previousWire) {
      if (previousWire.layer !== routePoint.layer) {
        addIssue(
          issues,
          "disconnected-trace",
          `Trace ${trace.pcb_trace_id} changes from ${previousWire.layer} to ${routePoint.layer} without a via`,
          plan,
        )
      } else if (!pointsMatch(previousWire, routePoint)) {
        segments.push({
          start: { x: previousWire.x, y: previousWire.y },
          end: { x: routePoint.x, y: routePoint.y },
          width: routePoint.width,
          layer: routePoint.layer,
        })
      }
    }
    previousWire = routePoint
  }

  if (pendingVia) {
    addIssue(
      issues,
      "disconnected-trace",
      `Trace ${trace.pcb_trace_id} ends at a via without a wire on ${pendingVia.to_layer}`,
      plan,
    )
  }
  return segments
}

function validatePlanStructure(params: {
  plan: FanoutRoutePlan
  preparedBus: PreparedBus | undefined
  inputSrj: SimpleRouteJson
  outputSrj: SimpleRouteJson
  sharedBoundary: Bounds
  issues: FanoutValidationIssue[]
}): void {
  const { plan, preparedBus, inputSrj, outputSrj, sharedBoundary, issues } =
    params
  const inputConnection = inputSrj.connections[plan.connectionIndex]
  if (!inputConnection || inputConnection.name !== plan.connectionName) {
    addIssue(
      issues,
      "connection-mismatch",
      `Plan index ${plan.connectionIndex} does not identify connection ${plan.connectionName}`,
      plan,
    )
    return
  }
  const preparedConnection = preparedBus?.connections.find(
    (connection) => connection.connectionIndex === plan.connectionIndex,
  )
  if (
    !preparedConnection ||
    preparedConnection.sourcePointIndex !== plan.sourcePointIndex ||
    !connectionPointsMatch(preparedConnection.sourcePoint, plan.sourcePoint) ||
    preparedConnection.sourceObstacle.obstacleId !==
      plan.sourceObstacle.obstacleId
  ) {
    addIssue(
      issues,
      "source-mismatch",
      `Plan ${plan.connectionName} does not start at its prepared component endpoint`,
      plan,
    )
  }
  if (preparedBus?.termination.type !== plan.termination.type) {
    addIssue(
      issues,
      "termination-mismatch",
      `Plan ${plan.connectionName} does not use its bus termination`,
      plan,
    )
  }
  const expectedCornerBandSide = getCornerBandSide(
    preparedBus?.exitEdge,
    preparedBus?.preferredExit,
  )
  if (
    preparedBus?.exitEdge !== plan.exitEdge ||
    expectedCornerBandSide !== plan.cornerBandSide
  ) {
    addIssue(
      issues,
      "output-exit-mismatch",
      `Plan ${plan.connectionName} does not retain its prepared boundary edge and band`,
      plan,
    )
  } else if (
    preparedBus?.exitEdge &&
    !pointIsOnBoundaryEdge(plan.exitPoint, preparedBus.exitEdge, sharedBoundary)
  ) {
    addIssue(
      issues,
      "output-exit-mismatch",
      `Plan ${plan.connectionName} does not terminate on its declared ${preparedBus.exitEdge} edge`,
      plan,
    )
  }
  const isAllowedViaInPadPlaneTermination =
    (inputSrj as SimpleRouteJson & { allowViaInPad?: boolean })
      .allowViaInPad === true &&
    plan.termination.type === "plane" &&
    plan.via !== undefined &&
    pointsMatch(plan.via.center, plan.sourcePoint) &&
    pointsMatch(plan.exitPoint, plan.sourcePoint)
  if (
    !isAllowedViaInPadPlaneTermination &&
    (plan.segments.length === 0 || plan.length <= EPSILON)
  ) {
    addIssue(
      issues,
      "not-broken-out",
      `Plan ${plan.connectionName} has no non-zero escape geometry`,
      plan,
    )
  } else {
    const routableBounds = {
      minX: Math.min(inputSrj.bounds.minX, sharedBoundary.minX),
      maxX: Math.max(inputSrj.bounds.maxX, sharedBoundary.maxX),
      minY: Math.min(inputSrj.bounds.minY, sharedBoundary.minY),
      maxY: Math.max(inputSrj.bounds.maxY, sharedBoundary.maxY),
    }
    if (
      plan.segments.some(
        (segment) =>
          !pointIsInsideBounds(segment.start, routableBounds) ||
          !pointIsInsideBounds(segment.end, routableBounds),
      )
    ) {
      addIssue(
        issues,
        "outside-routing-bounds",
        `Plan ${plan.connectionName} leaves the routable SRJ/shared-boundary area`,
        plan,
      )
    }
    if (
      plan.segments[0] &&
      !pointsMatch(plan.segments[0].start, plan.sourcePoint)
    ) {
      addIssue(
        issues,
        "disconnected-trace",
        `Plan ${plan.connectionName} does not start at its source pad`,
        plan,
      )
    }
    if (
      plan.segments.at(-1) &&
      !pointsMatch(plan.segments.at(-1)!.end, plan.exitPoint)
    ) {
      addIssue(
        issues,
        "disconnected-trace",
        `Plan ${plan.connectionName} does not end at its declared exit`,
        plan,
      )
    }
    for (let index = 1; index < plan.segments.length; index++) {
      const previous = plan.segments[index - 1]!
      const current = plan.segments[index]!
      if (!pointsMatch(previous.end, current.start)) {
        addIssue(
          issues,
          "disconnected-trace",
          `Plan ${plan.connectionName} has a gap between route segments`,
          plan,
        )
      }
      const transitionVia = getPlanVias(plan).find(
        (via) =>
          pointsMatch(previous.end, via.center) &&
          via.spanLayers.includes(previous.layer) &&
          via.spanLayers.includes(current.layer),
      )
      if (previous.layer !== current.layer && !transitionVia) {
        addIssue(
          issues,
          "disconnected-trace",
          `Plan ${plan.connectionName} changes layers without a connecting via`,
          plan,
        )
      }
    }
  }

  const measuredLength = [
    ...plan.segments,
    ...(plan.planeEndpointSegments ?? []),
  ].reduce((total, segment) => total + distance(segment.start, segment.end), 0)
  if (Math.abs(measuredLength - plan.length) > 1e-6) {
    addIssue(
      issues,
      "plan-length-mismatch",
      `Plan ${plan.connectionName} declares ${plan.length.toFixed(6)}mm but contains ${measuredLength.toFixed(6)}mm of routed copper`,
      plan,
    )
  }

  const traceSegments = extractTraceSegments({
    trace: plan.trace,
    plan,
    issues,
  })
  const declaredTraceSegments = plan.segments.filter(
    (segment) => distance(segment.start, segment.end) > EPSILON,
  )
  if (
    traceSegments.length !== declaredTraceSegments.length ||
    traceSegments.some((segment, index) => {
      const declared = declaredTraceSegments[index]
      return (
        !declared ||
        segment.layer !== declared.layer ||
        Math.abs(segment.width - declared.width) > EPSILON ||
        !pointsMatch(segment.start, declared.start) ||
        !pointsMatch(segment.end, declared.end)
      )
    })
  ) {
    addIssue(
      issues,
      "trace-plan-mismatch",
      `Trace ${plan.trace.pcb_trace_id} does not encode its declared route segments`,
      plan,
    )
  }

  if (
    plan.planeEndpointTrace ||
    plan.planeEndpointSegments ||
    plan.planeEndpointVia
  ) {
    if (
      !plan.planeEndpointTrace ||
      !plan.planeEndpointSegments ||
      !plan.planeEndpointVia
    ) {
      addIssue(
        issues,
        "trace-plan-mismatch",
        `Plane endpoint geometry for ${plan.connectionName} is incomplete`,
        plan,
      )
    } else {
      const endpointSegments = extractTraceSegments({
        trace: plan.planeEndpointTrace,
        plan,
        issues,
      })
      if (
        endpointSegments.length !== plan.planeEndpointSegments.length ||
        endpointSegments.some((segment, index) => {
          const declared = plan.planeEndpointSegments?.[index]
          return (
            !declared ||
            segment.layer !== declared.layer ||
            Math.abs(segment.width - declared.width) > EPSILON ||
            !pointsMatch(segment.start, declared.start) ||
            !pointsMatch(segment.end, declared.end)
          )
        }) ||
        distance(plan.planeEndpointVia.center, plan.targetPoint) <= EPSILON
      ) {
        addIssue(
          issues,
          "trace-plan-mismatch",
          `Trace ${plan.planeEndpointTrace.pcb_trace_id} does not encode a valid offset plane-to-endpoint dogbone`,
          plan,
        )
      }
    }
  }

  const firstRoutePoint = plan.trace.route.find(
    (routePoint): routePoint is Extract<typeof routePoint, { x: number }> =>
      "x" in routePoint && "y" in routePoint,
  )
  const lastRoutePoint = [...plan.trace.route]
    .reverse()
    .find(
      (routePoint): routePoint is Extract<typeof routePoint, { x: number }> =>
        "x" in routePoint && "y" in routePoint,
    )
  if (
    !firstRoutePoint ||
    !lastRoutePoint ||
    !pointsMatch(firstRoutePoint, plan.sourcePoint) ||
    !pointsMatch(lastRoutePoint, plan.exitPoint)
  ) {
    addIssue(
      issues,
      "disconnected-trace",
      `Trace ${plan.trace.pcb_trace_id} does not span its source and exit`,
      plan,
    )
  }

  const outputConnection = outputSrj.connections.find(
    (connection) => connection.name === plan.connectionName,
  )
  if (plan.termination.type === "boundary") {
    if (!outputConnection) {
      addIssue(
        issues,
        "output-connection-missing",
        `Boundary connection ${plan.connectionName} was removed from the output`,
        plan,
      )
    } else {
      const outputSource =
        outputConnection.pointsToConnect[plan.sourcePointIndex]
      if (
        !outputSource ||
        !pointsMatch(outputSource, plan.exitPoint) ||
        !("layer" in outputSource) ||
        outputSource.layer !== plan.targetLayer
      ) {
        addIssue(
          issues,
          "output-exit-mismatch",
          `Output connection ${plan.connectionName} is not attached to its fanout exit`,
          plan,
        )
      }
      for (
        let index = 0;
        index < inputConnection.pointsToConnect.length;
        index++
      ) {
        if (index === plan.sourcePointIndex) continue
        const inputPoint = inputConnection.pointsToConnect[index]
        const outputPoint = outputConnection.pointsToConnect[index]
        if (
          !inputPoint ||
          !outputPoint ||
          !connectionPointsMatch(inputPoint, outputPoint)
        ) {
          addIssue(
            issues,
            "downstream-endpoint-lost",
            `Output connection ${plan.connectionName} did not retain downstream endpoint ${index}`,
            plan,
          )
        }
      }
    }
  } else if (outputConnection) {
    addIssue(
      issues,
      "plane-connection-retained",
      `Plane-terminated connection ${plan.connectionName} remains in the output`,
      plan,
    )
  }
}

function plansHaveConnectedCopper(
  first: FanoutRoutePlan,
  second: FanoutRoutePlan,
): boolean {
  const firstSegments = getPlanSegments(first)
  const secondSegments = getPlanSegments(second)
  const firstVias = getPlanVias(first)
  const secondVias = getPlanVias(second)
  for (const firstSegment of firstSegments) {
    for (const secondSegment of secondSegments) {
      if (
        firstSegment.layer === secondSegment.layer &&
        distanceSegmentToSegment(
          firstSegment.start,
          firstSegment.end,
          secondSegment.start,
          secondSegment.end,
        ) <=
          (firstSegment.width + secondSegment.width) / 2 + EPSILON
      ) {
        return true
      }
    }
    for (const secondVia of secondVias) {
      if (
        secondVia.spanLayers.includes(firstSegment.layer) &&
        distancePointToSegment(
          secondVia.center,
          firstSegment.start,
          firstSegment.end,
        ) <=
          secondVia.diameter / 2 + firstSegment.width / 2 + EPSILON
      ) {
        return true
      }
    }
  }
  for (const firstVia of firstVias) {
    for (const secondSegment of secondSegments) {
      if (
        firstVia.spanLayers.includes(secondSegment.layer) &&
        distancePointToSegment(
          firstVia.center,
          secondSegment.start,
          secondSegment.end,
        ) <=
          firstVia.diameter / 2 + secondSegment.width / 2 + EPSILON
      ) {
        return true
      }
    }
    for (const secondVia of secondVias) {
      if (
        firstVia.spanLayers.some((layer) =>
          secondVia.spanLayers.includes(layer),
        ) &&
        distance(firstVia.center, secondVia.center) <=
          (firstVia.diameter + secondVia.diameter) / 2 + EPSILON
      ) {
        return true
      }
    }
  }
  return false
}

function validateBreakoutConnectivity(params: {
  plans: readonly FanoutRoutePlan[]
  inputSrj: SimpleRouteJson
  sharedBoundary: Bounds
  issues: FanoutValidationIssue[]
}): Set<FanoutRoutePlan> {
  const { plans, inputSrj, sharedBoundary, issues } = params
  const connectedPlans = new Set<FanoutRoutePlan>()
  const neighboringPlans = new Map<FanoutRoutePlan, FanoutRoutePlan[]>()
  for (const plan of plans) neighboringPlans.set(plan, [])

  for (let firstIndex = 0; firstIndex < plans.length; firstIndex++) {
    const first = plans[firstIndex]!
    if (
      first.termination.type === "plane"
        ? Boolean(first.via)
        : first.segments.some(
            (segment) =>
              pointIsOnBoundary(segment.start, sharedBoundary) ||
              pointIsOnBoundary(segment.end, sharedBoundary),
          )
    ) {
      connectedPlans.add(first)
    }
    for (
      let secondIndex = firstIndex + 1;
      secondIndex < plans.length;
      secondIndex++
    ) {
      const second = plans[secondIndex]!
      if (
        !connectionsShareElectricalNet(
          inputSrj,
          first.connectionName,
          second.connectionName,
        ) ||
        !plansHaveConnectedCopper(first, second)
      ) {
        continue
      }
      neighboringPlans.get(first)!.push(second)
      neighboringPlans.get(second)!.push(first)
    }
  }

  const queue = [...connectedPlans]
  while (queue.length > 0) {
    const plan = queue.shift()!
    for (const neighbor of neighboringPlans.get(plan) ?? []) {
      if (connectedPlans.has(neighbor)) continue
      connectedPlans.add(neighbor)
      queue.push(neighbor)
    }
  }

  for (const plan of plans) {
    if (connectedPlans.has(plan)) continue
    addIssue(
      issues,
      "not-broken-out",
      plan.termination.type === "boundary"
        ? `Connection ${plan.connectionName} has no continuous same-net copper path to the shared boundary`
        : `Plane connection ${plan.connectionName} has no terminating via`,
      plan,
    )
  }
  return connectedPlans
}

function validateClearances(params: {
  plans: readonly FanoutRoutePlan[]
  inputSrj: SimpleRouteJson
  clearance: number
  allowBlindAndBuriedVias: boolean
  issues: FanoutValidationIssue[]
}): void {
  const { plans, inputSrj, clearance, allowBlindAndBuriedVias, issues } = params
  for (const plan of plans) {
    if (
      getSourcePadReentries(plan, clearance).some(
        (issue) => issue.kind !== "clearance",
      )
    )
      addIssue(
        issues,
        "source-pad-reentry",
        `Trace ${plan.connectionName} returns into its source pad after leaving it`,
        plan,
      )
    const segments = getPlanSegments(plan)
    for (let segmentIndex = 0; segmentIndex < segments.length; segmentIndex++) {
      const segment = segments[segmentIndex]!
      for (const obstacle of inputSrj.obstacles) {
        if (!obstacle.layers.includes(segment.layer)) continue
        if (
          obstacleSharesElectricalNet(inputSrj, obstacle, plan.connectionName)
        ) {
          continue
        }
        if (
          segmentIndex === 0 &&
          obstacle.obstacleId === plan.sourceObstacle.obstacleId &&
          segment.layer === plan.sourceLayer
        ) {
          continue
        }
        if (
          segmentIsLegalTerminalBodyEscape({
            inputSrj,
            segment,
            bodyObstacle: obstacle,
            connectionName: plan.connectionName,
          })
        ) {
          continue
        }
        const actual = distanceSegmentToObstacle(segment, obstacle)
        const required = segment.width / 2 + clearance
        if (actual < required - 1e-9) {
          addIssue(
            issues,
            "obstacle-clearance",
            `Trace ${plan.connectionName} on ${segment.layer} is ${actual.toFixed(4)}mm from different-net obstacle ${obstacle.obstacleId}; ${required.toFixed(4)}mm is required`,
            plan,
          )
        }
      }
    }
    for (const via of getPlanVias(plan)) {
      for (const obstacle of inputSrj.obstacles) {
        if (
          !obstacle.layers.some((layer) => via.spanLayers.includes(layer)) ||
          obstacle.isCopperPour ||
          obstacleSharesElectricalNet(inputSrj, obstacle, plan.connectionName)
        ) {
          continue
        }
        const actual = distancePointToObstacle(via.center, obstacle)
        const required = via.diameter / 2 + clearance
        if (actual < required - 1e-9) {
          addIssue(
            issues,
            "via-obstacle-clearance",
            `Via ${plan.connectionName} is ${actual.toFixed(4)}mm from different-net obstacle ${obstacle.obstacleId} on its layer span; ${required.toFixed(4)}mm is required`,
            plan,
          )
        }
      }
    }

    for (const traceCopper of getAllRoutedTraceCopper(
      inputSrj,
      allowBlindAndBuriedVias,
    )) {
      if (
        plan.connectionName === traceCopper.connectionName ||
        connectionsShareElectricalNet(
          inputSrj,
          plan.connectionName,
          traceCopper.connectionName,
        )
      ) {
        continue
      }
      for (const segment of getPlanSegments(plan)) {
        for (const existingSegment of traceCopper.segments) {
          if (!segmentsAreClear(segment, existingSegment, clearance)) {
            addIssue(
              issues,
              "different-net-trace-clearance",
              `Trace ${plan.connectionName} violates routed trace ${traceCopper.trace.pcb_trace_id} on ${segment.layer}`,
              plan,
              traceCopper.connectionName,
            )
          }
        }
        for (const existingVia of traceCopper.vias) {
          if (
            existingVia.spanLayers.includes(segment.layer) &&
            distancePointToSegment(
              existingVia.center,
              segment.start,
              segment.end,
            ) <
              existingVia.diameter / 2 + segment.width / 2 + clearance - 1e-9
          ) {
            addIssue(
              issues,
              "different-net-trace-via-clearance",
              `Trace ${plan.connectionName} violates a via in routed trace ${traceCopper.trace.pcb_trace_id} on ${segment.layer}`,
              plan,
              traceCopper.connectionName,
            )
          }
        }
      }
      for (const via of getPlanVias(plan)) {
        for (const existingSegment of traceCopper.segments) {
          if (
            via.spanLayers.includes(existingSegment.layer) &&
            distancePointToSegment(
              via.center,
              existingSegment.start,
              existingSegment.end,
            ) <
              via.diameter / 2 + existingSegment.width / 2 + clearance - 1e-9
          ) {
            addIssue(
              issues,
              "different-net-trace-via-clearance",
              `Via ${plan.connectionName} violates routed trace ${traceCopper.trace.pcb_trace_id} on ${existingSegment.layer}`,
              plan,
              traceCopper.connectionName,
            )
          }
        }
        for (const existingVia of traceCopper.vias) {
          if (
            via.spanLayers.some((layer) =>
              existingVia.spanLayers.includes(layer),
            ) &&
            distance(via.center, existingVia.center) <
              (via.diameter + existingVia.diameter) / 2 + clearance - 1e-9
          ) {
            addIssue(
              issues,
              "different-net-via-clearance",
              `Via ${plan.connectionName} violates a via in routed trace ${traceCopper.trace.pcb_trace_id}`,
              plan,
              traceCopper.connectionName,
            )
          }
        }
      }
    }
  }

  for (let firstIndex = 0; firstIndex < plans.length; firstIndex++) {
    const first = plans[firstIndex]!
    for (
      let secondIndex = firstIndex + 1;
      secondIndex < plans.length;
      secondIndex++
    ) {
      const second = plans[secondIndex]!
      if (
        connectionsShareElectricalNet(
          inputSrj,
          first.connectionName,
          second.connectionName,
        )
      ) {
        continue
      }
      const firstSegments = getPlanSegments(first)
      const secondSegments = getPlanSegments(second)
      const firstVias = getPlanVias(first)
      const secondVias = getPlanVias(second)
      for (const firstSegment of firstSegments) {
        for (const secondSegment of secondSegments) {
          if (!segmentsAreClear(firstSegment, secondSegment, clearance)) {
            addIssue(
              issues,
              "different-net-trace-clearance",
              `Different-net traces ${first.connectionName} and ${second.connectionName} intersect or violate clearance on ${firstSegment.layer}`,
              first,
              second.connectionName,
            )
          }
        }
        for (const secondVia of secondVias) {
          if (
            secondVia.spanLayers.includes(firstSegment.layer) &&
            distancePointToSegment(
              secondVia.center,
              firstSegment.start,
              firstSegment.end,
            ) <
              secondVia.diameter / 2 + firstSegment.width / 2 + clearance - 1e-9
          ) {
            addIssue(
              issues,
              "different-net-trace-via-clearance",
              `Trace ${first.connectionName} violates via clearance to ${second.connectionName} on ${firstSegment.layer}`,
              first,
              second.connectionName,
            )
          }
        }
      }
      for (const firstVia of firstVias) {
        for (const secondSegment of secondSegments) {
          if (
            firstVia.spanLayers.includes(secondSegment.layer) &&
            distancePointToSegment(
              firstVia.center,
              secondSegment.start,
              secondSegment.end,
            ) <
              firstVia.diameter / 2 + secondSegment.width / 2 + clearance - 1e-9
          ) {
            addIssue(
              issues,
              "different-net-trace-via-clearance",
              `Via ${first.connectionName} violates trace clearance to ${second.connectionName} on ${secondSegment.layer}`,
              first,
              second.connectionName,
            )
          }
        }
        for (const secondVia of secondVias) {
          if (
            firstVia.spanLayers.some((layer) =>
              secondVia.spanLayers.includes(layer),
            ) &&
            distance(firstVia.center, secondVia.center) <
              (firstVia.diameter + secondVia.diameter) / 2 + clearance - 1e-9
          ) {
            addIssue(
              issues,
              "different-net-via-clearance",
              `Vias ${first.connectionName} and ${second.connectionName} violate clearance on an overlapping layer span`,
              first,
              second.connectionName,
            )
          }
        }
      }
    }
  }
}

function validateDifferentialPairs(
  inputSrj: SimpleRouteJson,
  plansByConnection: ReadonlyMap<string, readonly FanoutRoutePlan[]>,
  issues: FanoutValidationIssue[],
): void {
  const pairs: unknown = inputSrj.differentialPairs
  if (pairs === undefined) return
  if (!Array.isArray(pairs)) {
    addIssue(
      issues,
      "invalid-differential-pair",
      "Differential pairs must be an array",
    )
    return
  }
  const inputIndicesByName = new Map<string, number[]>()
  inputSrj.connections.forEach((connection, index) => {
    const indices = inputIndicesByName.get(connection.name) ?? []
    indices.push(index)
    inputIndicesByName.set(connection.name, indices)
  })
  pairs.forEach((value: unknown, pairIndex) => {
    const pair = value as {
      connectionNames?: unknown
      lengthTolerance?: unknown
    } | null
    const names = pair?.connectionNames
    const tolerance = pair?.lengthTolerance
    if (
      !Array.isArray(names) ||
      names.length !== 2 ||
      names.some((name) => typeof name !== "string" || name.length === 0) ||
      names[0] === names[1] ||
      typeof tolerance !== "number" ||
      !Number.isFinite(tolerance) ||
      tolerance < 0
    ) {
      addIssue(
        issues,
        "invalid-differential-pair",
        `Differential pair ${pairIndex} must name two distinct connections and a finite nonnegative length tolerance`,
      )
      return
    }
    // Resolve original connection identity, never an electrical-net alias or an
    // output SRJ declaration. A pair can be stricter than its containing bus.
    const pairPlans: FanoutRoutePlan[] = []
    for (const name of names) {
      const indices = inputIndicesByName.get(name)
      const plans = plansByConnection.get(name)
      if (
        indices?.length !== 1 ||
        plans?.length !== 1 ||
        plans[0]!.connectionIndex !== indices[0]
      ) {
        addIssue(
          issues,
          "invalid-differential-pair",
          `Differential pair ${pairIndex} cannot resolve exactly one original plan for connection ${name}`,
        )
        return
      }
      pairPlans.push(plans[0]!)
    }
    // Measure copper rather than trusting cached plan.length metadata. Vertical
    // via barrel lengths are not represented in the SRJ's planar length units.
    const lengths = pairPlans.map((plan) =>
      getPlanSegments(plan).reduce(
        (sum, segment) => sum + distance(segment.start, segment.end),
        0,
      ),
    )
    if (lengths.some((length) => !Number.isFinite(length))) {
      addIssue(
        issues,
        "invalid-differential-pair",
        `Differential pair ${pairIndex} has nonfinite routed copper length`,
        pairPlans[0],
        names[1],
      )
      return
    }
    const skew = Math.abs(lengths[0]! - lengths[1]!)
    if (skew > tolerance + EPSILON) {
      addIssue(
        issues,
        "differential-pair-length-skew",
        `Differential pair ${names[0]}/${names[1]} has ${skew.toFixed(6)}mm routed-length skew; ${tolerance.toFixed(6)}mm is allowed`,
        pairPlans[0],
        names[1],
      )
    }
  })
}

export function validateFanoutSolution(params: {
  inputSrj: SimpleRouteJson
  outputSrj: SimpleRouteJson
  plans: readonly FanoutRoutePlan[]
  preparedBuses: readonly PreparedBus[]
  sharedBoundary: Bounds
  clearance: number
  allowBlindAndBuriedVias?: boolean
}): FanoutValidationReport {
  const {
    inputSrj,
    outputSrj,
    plans,
    preparedBuses,
    sharedBoundary,
    clearance,
    allowBlindAndBuriedVias = true,
  } = params
  const issues: FanoutValidationIssue[] = []
  const plansByConnection = new Map<string, FanoutRoutePlan[]>()
  const preparedBusById = new Map(preparedBuses.map((bus) => [bus.busId, bus]))
  for (const plan of plans) {
    const connectionPlans = plansByConnection.get(plan.connectionName) ?? []
    connectionPlans.push(plan)
    plansByConnection.set(plan.connectionName, connectionPlans)
  }
  validateDifferentialPairs(inputSrj, plansByConnection, issues)
  for (const bus of preparedBuses) {
    if (bus.maxLengthSkew === undefined) continue
    const busPlans = plans.filter((plan) => plan.busId === bus.busId)
    if (busPlans.length < 2) continue
    const lengths = busPlans.map((plan) => plan.length)
    const skew = Math.max(...lengths) - Math.min(...lengths)
    if (skew > bus.maxLengthSkew + 1e-6) {
      addIssue(
        issues,
        "bus-length-skew",
        `Bus ${bus.busId} has ${skew.toFixed(6)}mm routed-length skew; ${bus.maxLengthSkew.toFixed(6)}mm is allowed`,
        busPlans[0],
      )
    }
  }

  for (const connection of inputSrj.connections) {
    const connectionPlans = plansByConnection.get(connection.name) ?? []
    if (connectionPlans.length === 0) {
      addIssue(
        issues,
        "missing-plan",
        `Connection ${connection.name} has no fanout plan`,
      )
    } else if (connectionPlans.length > 1) {
      addIssue(
        issues,
        "duplicate-plan",
        `Connection ${connection.name} has ${connectionPlans.length} fanout plans`,
        connectionPlans[0],
      )
    }
  }
  for (const plan of plans) {
    if (
      !inputSrj.connections.some(
        (connection) => connection.name === plan.connectionName,
      )
    ) {
      addIssue(
        issues,
        "unknown-plan",
        `Plan ${plan.connectionName} is not an input connection`,
        plan,
      )
      continue
    }
    validatePlanStructure({
      plan,
      preparedBus: preparedBusById.get(plan.busId),
      inputSrj,
      outputSrj,
      sharedBoundary,
      issues,
    })
  }
  const connectedPlans = validateBreakoutConnectivity({
    plans,
    inputSrj,
    sharedBoundary,
    issues,
  })
  validateClearances({
    plans,
    inputSrj,
    clearance,
    allowBlindAndBuriedVias,
    issues,
  })

  return {
    valid: issues.length === 0,
    checkedConnectionCount: inputSrj.connections.length,
    brokenOutConnectionCount: new Set(
      [...connectedPlans].map((plan) => plan.connectionName),
    ).size,
    issues,
  }
}
