import type { Point2D } from "./types"

const EPSILON = 1e-7

/** Remove only forward collinear vertices, retaining floating-point bends. */
export function compressWindingPath(points: Point2D[]): Point2D[] {
  if (points.length < 3) return points
  const compressed = [points[0]!]
  for (let index = 1; index < points.length - 1; index++) {
    const previous = compressed.at(-1)!
    const current = points[index]!
    const next = points[index + 1]!
    const incomingX = current.x - previous.x
    const incomingY = current.y - previous.y
    const outgoingX = next.x - current.x
    const outgoingY = next.y - current.y
    const incomingLength = Math.hypot(incomingX, incomingY)
    const outgoingLength = Math.hypot(outgoingX, outgoingY)
    const cross = incomingX * outgoingY - incomingY * outgoingX
    const dot = incomingX * outgoingX + incomingY * outgoingY
    if (
      incomingLength < EPSILON ||
      outgoingLength < EPSILON ||
      dot <= 0 ||
      Math.abs(cross) > EPSILON * Math.min(incomingLength, outgoingLength)
    ) {
      compressed.push(current)
    }
  }
  compressed.push(points.at(-1)!)
  return compressed
}
