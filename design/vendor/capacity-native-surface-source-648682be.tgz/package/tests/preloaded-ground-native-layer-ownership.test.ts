import { expect, test } from "bun:test"
import type { SimpleRouteJson } from "lib/types"
import { createRoutingLayerDomainSrj } from "lib/utils/createRoutingLayerDomainSrj"
import { createAllowedZResolver } from "lib/utils/getAllowedZForConnection"

test("dropped satisfied ground declarations retain immutable native plane ownership", (): void => {
  const originalSrj: SimpleRouteJson = {
    layerCount: 4, minTraceWidth: 0.1,
    bounds: { minX: -5, maxX: 5, minY: -5, maxY: 5 },
    obstacles: [{ type: "rect", layers: ["inner1"], center: { x: 0, y: 0 }, width: 10, height: 10,
      isCopperPour: true, connectedTo: ["native_ground_source"] }],
    connections: [
      { name: "GROUND", source_trace_id: "native_ground_source", pointsToConnect: [{ x: -2, y: 1, layer: "inner1" }, { x: 2, y: 1, layer: "inner1" }] },
      { name: "DATA", allowedLayers: ["top", "bottom"], pointsToConnect: [{ x: -2, y: -1, layer: "top" }, { x: 2, y: -1, layer: "top" }] },
    ],
    traces: [{ type: "pcb_trace", pcb_trace_id: "ground_preload", connection_name: "GROUND", route: [
      { route_type: "wire", x: -2, y: 1, width: 0.1, layer: "inner1" },
      { route_type: "wire", x: 2, y: 1, width: 0.1, layer: "inner1" },
    ] }],
  }
  const before = JSON.stringify(originalSrj)
  const routingConnections = [{ name: "DATA_pair", rootConnectionName: "DATA", allowedLayers: ["bottom"], pointsToConnect: originalSrj.connections[1]!.pointsToConnect }]
  const domainSrj = createRoutingLayerDomainSrj(originalSrj, routingConnections)
  const resolve = createAllowedZResolver(domainSrj)
  expect(resolve("GROUND")).toEqual([0, 1, 2, 3])
  expect(resolve("DATA_pair")).toEqual([3])
  expect(resolve("DATA")).toEqual([0, 3])
  expect(domainSrj.connections[2]!.pointsToConnect).toEqual([])
  expect(domainSrj.traces).toBe(originalSrj.traces)
  expect(JSON.stringify(originalSrj)).toBe(before)
  expect(JSON.stringify(routingConnections[0]!.pointsToConnect)).toBe(JSON.stringify(originalSrj.connections[1]!.pointsToConnect))
})
