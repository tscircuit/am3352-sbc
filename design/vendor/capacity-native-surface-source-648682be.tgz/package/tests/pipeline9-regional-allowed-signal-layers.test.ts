import { expect, test } from "bun:test"
import { preparePipeline9RegionalB01Candidate, preparePipeline9RegularRegionalCandidate } from "lib/autorouter-pipelines/AutoroutingPipeline9_PreloadedTraceGraph/applyPipeline9RegionalB01Repairs"
import type { SimpleRouteJson } from "lib/types"
import type { HighDensityRoute } from "lib/types/high-density-types"
import { getConnectivityMapFromSimpleRouteJson } from "lib/utils/getConnectivityMapFromSimpleRouteJson"

test("regional repair retains native stackup and each movable connection's own wire layers", (): void => {
  const srj: SimpleRouteJson = { layerCount: 4, minTraceWidth: 0.1,
    bounds: { minX: -6, maxX: 6, minY: -6, maxY: 6 }, obstacles: [],
    connections: [{ name: "DATA", allowedLayers: ["top", "bottom"], pointsToConnect: [{ x: -5, y: 0, layer: "top" }, { x: 5, y: 0, layer: "top" }] },
      { name: "AUX", allowedLayers: ["inner1"], pointsToConnect: [{ x: -5, y: 1, layer: "inner1" }, { x: 5, y: 1, layer: "inner1" }] }],
  }
  const routes: HighDensityRoute[] = [{ connectionName: "DATA", traceThickness: 0.1, viaDiameter: 0.3, route: [{ x: -5, y: 0, z: 0 }, { x: 5, y: 0, z: 0 }], vias: [] },
    { connectionName: "AUX", traceThickness: 0.1, viaDiameter: 0.3, route: [{ x: -5, y: 1, z: 1 }, { x: 5, y: 1, z: 1 }], vias: [] }]
  const original = JSON.stringify({ srj, routes })
  const parameters = { routes, center: { x: 0, y: 0 }, regionSize: 6, srj,
    connMap: getConnectivityMapFromSimpleRouteJson(srj), colorMap: {}, viaDiameter: 0.3,
    traceWidth: 0.1, obstacleMargin: 0.1, effort: 1 }
  const single = preparePipeline9RegionalB01Candidate({ ...parameters, fixedObstacleRoutes: [], routeIndex: 0 })
  expect(single).toBeDefined()
  const singleNode = single!.solver.unsolvedNodePortPoints[0]!
  expect(singleNode.availableZ).toEqual([0, 3])
  expect(singleNode.allowedZByConnectionName).toEqual({ DATA: [0, 3] })
  expect(single!.solver.layerCount).toBe(4)
  const regular = preparePipeline9RegularRegionalCandidate({ ...parameters,
    fixedRouteCopperSpatialIndex: { getRoutesOverlappingBounds: (): [] => [] } })
  expect(regular).toBeDefined()
  expect(regular!.problem.nodeWithPortPoints.availableZ).toEqual([0, 1, 3])
  expect(regular!.problem.nodeWithPortPoints.allowedZByConnectionName).toEqual({ DATA: [0, 3], AUX: [1] })
  expect(regular!.solver.params.layerCount).toBe(4)
  expect(JSON.stringify({ srj, routes })).toBe(original)
})
