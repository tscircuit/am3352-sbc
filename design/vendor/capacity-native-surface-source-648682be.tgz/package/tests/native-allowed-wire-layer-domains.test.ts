import { expect, test } from "bun:test"
import type { SimpleRouteJson } from "lib/types"
import { createAllowedZResolver, getAllowedZForConnection } from "lib/utils/getAllowedZForConnection"
import { mergeConnections } from "lib/solvers/NetToPointPairsSolver/mergeConnections"

test("native wire domains intersect board, connection, bus and immutable foreign plane ownership", (): void => {
  const srj: SimpleRouteJson = {
    layerCount: 4, minTraceWidth: 0.1,
    bounds: { minX: -6, maxX: 6, minY: -6, maxY: 6 },
    outline: [{ x: -5, y: -5 }, { x: 5, y: -5 }, { x: 5, y: 5 }, { x: -5, y: 5 }],
    obstacles: ["inner1", "inner2"].map((layer) => ({
      type: "rect", layers: [layer], center: { x: 0, y: 0 }, width: 10, height: 10,
      isCopperPour: true, connectedTo: ["native_ground_source"],
    })),
    connections: [
      { name: "DATA", source_trace_id: "native_data_source", pointsToConnect: [{ x: -3, y: 0, layer: "top" }, { x: 3, y: 0, layer: "top" }] },
      { name: "GROUND", source_trace_id: "native_ground_source", pointsToConnect: [{ x: -2, y: 2, layer: "top" }, { x: 2, y: 2, layer: "inner1" }] },
    ],
  }
  const original = JSON.stringify(srj)
  const resolve = createAllowedZResolver(srj)
  expect(resolve("DATA")).toEqual([0, 3])
  expect(resolve("GROUND")).toEqual([0, 1, 2, 3])
  const merged = mergeConnections([srj.connections[1]!, {
    name: "GROUND_PART", pointsToConnect: [srj.connections[1]!.pointsToConnect[0]!, { x: 1, y: 2, layer: "top" }],
  }])
  expect(merged).toHaveLength(1)
  expect(getAllowedZForConnection({ ...srj, connections: merged }, merged[0]!.name)).toEqual([0, 1, 2, 3])
  const domain = resolve("DATA")
  domain.push(1)
  expect(resolve("DATA")).toEqual([0, 3])
  expect(getAllowedZForConnection({ ...srj, allowedLayers: ["top", "bottom"],
    connections: srj.connections.map((connection) => connection.name === "DATA" ? { ...connection, allowedLayers: ["inner1", "bottom"] } : connection),
    buses: [{ busId: "DATA_BUS", connectionNames: ["DATA"], allowedLayers: ["top", "bottom"] }],
  }, "DATA")).toEqual([3])
  expect(() => getAllowedZForConnection({ ...srj, allowedLayers: ["inner1"] }, "DATA")).toThrow("no legal wire layers")
  expect(() => getAllowedZForConnection({ ...srj, allowedLayers: ["inner3"] }, "GROUND")).toThrow("Invalid allowed routing layer")
  expect(() => getAllowedZForConnection({ ...srj, allowedLayers: [] }, "GROUND")).toThrow("no legal wire layers")
  expect(JSON.stringify(srj)).toBe(original)
})
