import { expect, test } from "bun:test"
import { CapacityMeshEdgeSolver2_NodeTreeOptimization } from "lib/solvers/CapacityMeshSolver/CapacityMeshEdgeSolver2_NodeTreeOptimization"
import type { CapacityMeshNode } from "lib/types"

test("interior owning pad tiles require an actual same-owner path to a free routing edge", (): void => {
  const nodes: CapacityMeshNode[] = [
    { capacityMeshNodeId: "pad_interior", center: { x: 0, y: 0 }, width: 1, height: 1, layer: "top", availableZ: [0], _containsObstacle: true, _containsTarget: true, _targetConnectionName: "DATA" },
    { capacityMeshNodeId: "pad_perimeter", center: { x: 1, y: 0 }, width: 1, height: 1, layer: "top", availableZ: [0], _containsObstacle: true, _containsTarget: true, _targetConnectionName: "DATA" },
    { capacityMeshNodeId: "routing_space", center: { x: 2, y: 0 }, width: 1, height: 1, layer: "top", availableZ: [0] },
  ]
  const solver = new CapacityMeshEdgeSolver2_NodeTreeOptimization(nodes)
  solver.solve()
  expect(solver.solved).toBe(true)
  expect(solver.edges.some((edge) => edge.nodeIds.includes("pad_interior") && edge.nodeIds.includes("pad_perimeter"))).toBe(true)
  expect(solver.edges.some((edge) => edge.nodeIds.includes("pad_perimeter") && edge.nodeIds.includes("routing_space"))).toBe(true)
  const foreignOwner = nodes.map((node) => node.capacityMeshNodeId === "pad_perimeter" ? { ...node, _targetConnectionName: "OTHER" } : node)
  expect(() => new CapacityMeshEdgeSolver2_NodeTreeOptimization(foreignOwner).solve()).toThrow("no bordering routing edge")
  expect(() => new CapacityMeshEdgeSolver2_NodeTreeOptimization(nodes.slice(0, 2)).solve()).toThrow("no bordering routing edge")
  const forbiddenLayer = nodes.map((node) => node.capacityMeshNodeId === "routing_space" ? { ...node, availableZ: [1], layer: "inner1" } : node)
  expect(() => new CapacityMeshEdgeSolver2_NodeTreeOptimization(forbiddenLayer).solve()).toThrow("no bordering routing edge")
})
