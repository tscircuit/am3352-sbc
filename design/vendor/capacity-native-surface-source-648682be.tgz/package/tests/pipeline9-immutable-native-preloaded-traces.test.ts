import { expect, test } from "bun:test"
import { AutoroutingPipelineSolver9_PreloadedTraceGraph } from "lib/autorouter-pipelines/AutoroutingPipeline9_PreloadedTraceGraph/AutoroutingPipelineSolver9_PreloadedTraceGraph"
import { preparePipeline7PowerTraceExpansionInput, type Pipeline7PowerTraceExpansionInput } from "lib/autorouter-pipelines/AutoroutingPipeline7_MultiGraph/prepare-pipeline7-power-trace-expansion-input"
import { createRegionalFallbackProblem } from "lib/autorouter-pipelines/AutoroutingPipeline9_PreloadedTraceGraph/pipeline9RegionalFallback"
import { convertPreloadedTraceToHdRoutes } from "lib/autorouter-pipelines/AutoroutingPipeline9_PreloadedTraceGraph/convertPreloadedTraceToHdRoutes"
import { evaluateRelaxedDrc } from "lib/testing/evaluate-relaxed-drc"
import type { SimpleRouteJson } from "lib/types"

test("immutable native preloads stay hard through topology, regional repair and power expansion", (): void => {
  const input: SimpleRouteJson = {
    layerCount: 4, allowedLayers: ["top", "bottom"], allowBlindAndBuriedVias: false,
    minTraceWidth: 0.1, minViaPadDiameter: 0.3, minViaHoleDiameter: 0.15,
    defaultObstacleMargin: 0.1, minBoardEdgeClearance: 0.2,
    bounds: { minX: -6, maxX: 6, minY: -6, maxY: 6 },
    outline: [{ x: -5, y: -5 }, { x: 5, y: -5 }, { x: 5, y: 5 }, { x: -5, y: 5 }],
    obstacles: ["inner1", "inner2"].map((layer) => ({ type: "rect", layers: [layer], center: { x: 0, y: 0 }, width: 10, height: 10, isCopperPour: true, connectedTo: ["GROUND"] })),
    connections: [
      { name: "DATA", pointsToConnect: [{ x: -3, y: 0, layer: "top" }, { x: 3, y: 0, layer: "top" }] },
      { name: "FIXED", pointsToConnect: [{ x: 0, y: -4, layer: "top" }, { x: 0, y: 4, layer: "bottom" }] },
    ],
    traces: [{ type: "pcb_trace", pcb_trace_id: "accepted_native_prefix", connection_name: "FIXED", route: [
      { route_type: "wire", x: 0, y: -4, width: 0.2, layer: "top" },
      { route_type: "wire", x: 0, y: 0, width: 0.2, layer: "top" },
      { route_type: "via", x: 0, y: 0, from_layer: "top", to_layer: "bottom", via_diameter: 0.3, via_hole_diameter: 0.15 },
      { route_type: "wire", x: 0, y: 0, width: 0.2, layer: "bottom" },
      { route_type: "wire", x: 0, y: 4, width: 0.2, layer: "bottom" },
    ] }],
  }
  const original = JSON.stringify(input)
  expect(() => new AutoroutingPipelineSolver9_PreloadedTraceGraph(input, { immutablePreloadedTraceIds: ["missing"] })).toThrow("Unknown immutable preloaded trace")
  const solver = new AutoroutingPipelineSolver9_PreloadedTraceGraph(input, { immutablePreloadedTraceIds: ["accepted_native_prefix"], capacityDepth: 5, effort: 0.1, cacheProvider: null })
  solver.solve()
  expect(solver.failed).toBe(false)
  expect(solver.solved).toBe(true)
  expect(solver.getMutatedPreloadedTraces()).toEqual([])
  const output = solver.getOutputSimpleRouteJson()
  expect(output.traces!.find((trace) => trace.pcb_trace_id === "accepted_native_prefix")).toEqual(input.traces![0])
  expect(solver.srj.obstacles.find((obstacle) => obstacle.obstacleId?.endsWith("_via"))!.layers).toEqual(["top", "inner1", "inner2", "bottom"])
  expect(evaluateRelaxedDrc({ inputSrj: input, srjWithPointPairs: solver.srjWithPointPairs!, routedTraces: solver.getOutputSimplifiedPcbTraces(), includeBoardClearance: true }).errors).toEqual([])
  const fixedHdRoutes = convertPreloadedTraceToHdRoutes(input.traces![0]!, 0, 4, 0.3, solver.connMap)
  const regional = createRegionalFallbackProblem({ capacityMeshNodeId: "native_test_node", center: { x: 0, y: 0 }, width: 8, height: 8, availableZ: [0, 3], portPoints: [], portPointsInPairs: [] }, fixedHdRoutes, new Set(fixedHdRoutes.map((route) => route.connectionName)), new Set([0]))
  expect(regional.fixedRouteSectionsByConnectionName.size).toBe(0)
  expect(regional.fixedObstacleRoutes.length).toBe(fixedHdRoutes.length)
  const powerInput = preparePipeline7PowerTraceExpansionInput({ originalSrj: input, newlyRoutedTraces: [], expandedConnectionNames: ["FIXED"], immutablePreloadedTraceIds: new Set(["accepted_native_prefix"]) })
  expect(powerInput.traces).toEqual([])
  expect(powerInput.fixedTraces).toEqual(input.traces)
  expect(JSON.stringify(input)).toBe(original)
  const finalInput = solver.powerTraceExpansionSolver!.inputSrj as Pipeline7PowerTraceExpansionInput
  finalInput.fixedTraces = finalInput.fixedTraces.map((trace) => ({ ...trace, route: trace.route.map((point) =>
    point.route_type === "wire" ? { ...point, width: point.width + 0.01 } : point,
  ) }))
  expect(() => solver.getOutputSimpleRouteJson()).toThrow("changed immutable native trace")
  expect(() => solver.getOutputSimplifiedPcbTraces()).toThrow("changed immutable native trace")
})
