import { expect, test } from "bun:test"
import { PortfolioSingleIntraNodeSolver } from "lib/solvers/HyperHighDensitySolver/PortfolioSingleIntraNodeSolver"
import type { NodeWithPortPoints } from "lib/types/high-density-types"

test("detailed routing preserves separate physical wire domains for crossing connections", (): void => {
  const node: NodeWithPortPoints = {
    capacityMeshNodeId: "native-mixed-domains", center: { x: 0, y: 0 }, width: 6, height: 6,
    availableZ: [0, 1, 2, 3], allowedZByConnectionName: { DATA: [0, 3], OTHER: [0, 1] },
    portPoints: [
      { connectionName: "DATA", x: -2, y: -2, z: 0 }, { connectionName: "DATA", x: 2, y: 2, z: 0 },
      { connectionName: "OTHER", x: -2, y: 2, z: 0 }, { connectionName: "OTHER", x: 2, y: -2, z: 0 },
    ],
  }
  const solver = new PortfolioSingleIntraNodeSolver({
    nodeWithPortPoints: node, layerCount: 4, traceWidth: 0.1, viaDiameter: 0.3,
    obstacleMargin: 0.1, effort: 0.1, enableNegotiatedSearch: true, captureSearchDebug: false,
  })
  solver.solve()
  expect(solver.failed).toBe(false)
  expect(solver.solved).toBe(true)
  expect(solver.solvedRoutes).toHaveLength(2)
  for (const route of solver.solvedRoutes) {
    const domain = node.allowedZByConnectionName![route.connectionName]!
    expect(route.route.every((point) => domain.includes(point.z))).toBe(true)
    expect(route.route.some((point) => point.z === 2)).toBe(false)
  }
  expect(solver.solvedRoutes.flatMap((route) => route.vias).length).toBeGreaterThan(0)
})
