import { expect, test } from "bun:test"
import { PortfolioSingleIntraNodeSolver } from "lib/solvers/HyperHighDensitySolver/PortfolioSingleIntraNodeSolver"
import { repairDisconnectedSameRootPortPoints } from "lib/solvers/HyperHighDensitySolver/repairDisconnectedSameRootPortPoints"
import type { HighDensityIntraNodeRoute, NodeWithPortPoints } from "lib/types/high-density-types"

test("a same-root bridge cannot grant its broader wire domain to another connection", (): void => {
  const node: NodeWithPortPoints = {
    capacityMeshNodeId: "same-root-wire-domains", center: { x: 0, y: 0 }, width: 6, height: 6,
    availableZ: [0, 3], allowedZByConnectionName: { DATA: [0], AUX: [0, 3] },
    portPoints: ["DATA", "AUX"].flatMap((connectionName) => [
      { connectionName, rootConnectionName: "ROOT", x: -1, y: 0, z: 0 },
      { connectionName, rootConnectionName: "ROOT", x: 1, y: 0, z: 0 },
    ]),
  }
  const routes: HighDensityIntraNodeRoute[] = [
    { connectionName: "DATA", rootConnectionName: "ROOT", traceThickness: 0.1, viaDiameter: 0.3,
      route: [{ x: -1, y: 0, z: 0 }], vias: [] },
    { connectionName: "AUX", rootConnectionName: "ROOT", traceThickness: 0.1, viaDiameter: 0.3,
      route: [{ x: -1, y: 0, z: 0 }, { x: -1, y: 0, z: 3 },
        { x: 1, y: 0, z: 3 }, { x: 1, y: 0, z: 0 }],
      vias: [{ x: -1, y: 0 }, { x: 1, y: 0 }] },
  ]
  expect(routes.every((route) => route.route.every((point) =>
    node.allowedZByConnectionName![route.connectionName]!.includes(point.z)))).toBe(true)
  expect(repairDisconnectedSameRootPortPoints(routes, node).some((route) =>
    route.connectionName === "DATA" && route.route.some((point) => point.z === 3))).toBe(true)
  const solver = new PortfolioSingleIntraNodeSolver({
    nodeWithPortPoints: node, layerCount: 4, traceWidth: 0.1,
    viaDiameter: 0.3, obstacleMargin: 0.1, effort: 0.1,
  })
  const candidate = { solvedRoutes: routes, solved: true, failed: false, error: null }
  solver.solved = true
  solver.winningSolver = candidate as never
  solver.onSolve({ solver: candidate } as never)
  expect(candidate.solved).toBe(false)
  expect(candidate.failed).toBe(true)
  expect(candidate.error).toBe('Candidate uses a forbidden wire layer for "DATA"')
  expect(solver.solved).toBe(false)
  expect(solver.winningSolver).toBeUndefined()
  expect(solver.solvedRoutes).toEqual([])
})
