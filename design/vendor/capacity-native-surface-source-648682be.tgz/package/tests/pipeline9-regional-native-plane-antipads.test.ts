import { expect, test } from "bun:test"
import { Pipeline9RegionalFallbackSolver } from "lib/autorouter-pipelines/AutoroutingPipeline9_PreloadedTraceGraph/Pipeline9RegionalFallbackSolver"
import type { HighDensityRoute } from "lib/types/high-density-types"
import { getConnectivityMapFromSimpleRouteJson } from "lib/utils/getConnectivityMapFromSimpleRouteJson"
import { copperPourReservationInput } from "./fixtures/copper-pour-reservations"

test("regional candidate validation keeps outer wire constraints and native through-via plane antipads", (): void => {
  const srj = copperPourReservationInput()
  const route: HighDensityRoute = { connectionName: "DATA", traceThickness: 0.1, viaDiameter: 0.3,
    route: [{ x: -3, y: 0, z: 0 }, { x: -2, y: 0, z: 0 }, { x: -2, y: 0, z: 3 },
      { x: 2, y: 0, z: 3 }, { x: 2, y: 0, z: 0 }, { x: 3, y: 0, z: 0 }], vias: [{ x: -2, y: 0 }, { x: 2, y: 0 }] }
  const parameters = { nodeWithPortPoints: { capacityMeshNodeId: "native-region", center: { x: 0, y: 0 }, width: 8, height: 8,
      availableZ: [0, 3], allowedZByConnectionName: { DATA: [0, 3] },
      portPoints: [{ x: -3, y: 0, z: 0, connectionName: "DATA" }, { x: 3, y: 0, z: 0, connectionName: "DATA" }] },
    obstacles: srj.obstacles, boardObstacles: srj.obstacles, connMap: getConnectivityMapFromSimpleRouteJson(srj), colorMap: {},
    layerCount: 4, allowBlindAndBuriedVias: false, viaDiameter: 0.3, traceWidth: 0.1,
    viaToPadClearance: 0.1, obstacleMargin: 0.1, effort: 1, movablePreloadedConnectionNames: new Set(["DATA"]) }
  const original = JSON.stringify({ srj, route })
  const solver = new Pipeline9RegionalFallbackSolver(parameters)
  const validator = solver.highDensitySolver.growShrinkSolutionValidator!
  expect(validator).toBeDefined()
  expect(validator([route])).toBe(true)
  const inner = { ...route, route: route.route.map((point) => ({ ...point, z: point.z === 3 ? 1 : point.z })) }
  expect(validator([inner])).toBe(false)
  expect(solver.stats.layerDomainCandidateRejectionCount).toBe(1)
  const blocked = new Pipeline9RegionalFallbackSolver({ ...parameters,
    boardObstacles: [...srj.obstacles, { type: "rect", center: { x: -2, y: 0 }, width: 0.2, height: 0.2, layers: ["inner2"], connectedTo: ["foreign_pad"] }] })
  expect(blocked.highDensitySolver.growShrinkSolutionValidator!([route])).toBe(false)
  expect(blocked.stats.preloadedViaCandidateRejectionCount).toBe(1)
  expect(JSON.stringify({ srj, route })).toBe(original)
})
