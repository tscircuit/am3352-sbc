const fs = require("node:fs")
const path = require("node:path")
const { execFileSync } = require("node:child_process")

const sourceRoot = process.cwd()
const workDir = path.join(sourceRoot, "work", "package-declarations")
const outputDir = path.join(sourceRoot, "dist")
execFileSync(process.execPath, [
  require.resolve("tsup/dist/cli-default.js"), "./lib/index.ts",
  "--minify", "terser", "--external", "@tscircuit/core",
  "--external", "circuit-to-svg", "--format", "esm", "--sourcemap",
], { cwd: sourceRoot, stdio: "inherit" })
execFileSync(process.execPath, [
  path.join(sourceRoot, "scripts", "build-standalone-declarations.cjs"),
  sourceRoot, workDir,
], { cwd: sourceRoot, stdio: "inherit" })
const manifest = JSON.parse(fs.readFileSync(path.join(workDir, "reachable-declarations.json"), "utf8"))
const stageDir = path.join(workDir, "declaration-stage")
const typesDir = path.join(outputDir, "types")
fs.rmSync(typesDir, { recursive: true, force: true })
for (const filename of manifest.files) {
  const relative = path.relative(stageDir, filename)
  if (path.isAbsolute(relative) || relative.startsWith("..")) {
    throw new Error(`Declaration outside the verified compiler stage: ${filename}`)
  }
  const target = path.join(typesDir, relative)
  fs.mkdirSync(path.dirname(target), { recursive: true })
  fs.copyFileSync(filename, target)
}
fs.rmSync(path.join(outputDir, "index.d.ts"), { force: true })
console.log(`Installed ${manifest.files.length} verified standalone declarations`)
