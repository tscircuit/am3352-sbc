const fs = require('fs');
const path = require('path');
const sourceRoot = fs.realpathSync(path.resolve(process.argv[2] || '.'));
const scratch = path.resolve(process.argv[3] || path.join(sourceRoot, 'work', 'standalone-declarations'));
const ts = require(path.join(sourceRoot, 'node_modules', 'typescript'));
const configPath = path.join(sourceRoot, 'tsconfig.json');
const stage = path.join(scratch, 'declaration-stage');
const originalEntry = path.join(sourceRoot, 'lib', 'index.ts');
fs.mkdirSync(scratch, { recursive: true });
const read = ts.readConfigFile(configPath, ts.sys.readFile);
const parsed = ts.parseJsonConfigFileContent(read.config, ts.sys, path.dirname(configPath));
const options = { ...parsed.options, paths: { ...parsed.options.paths, '@tscircuit/capacity-autorouter':[originalEntry] }, resolveJsonModule:true, types:['bun'], typeRoots:[path.join(sourceRoot,'node_modules','@types')], noEmit: false, declaration: true, emitDeclarationOnly: true, noCheck:true, declarationMap: false, rootDir: sourceRoot, outDir: stage };
const ambientRoots=parsed.fileNames.filter(filename=>filename.endsWith('.d.ts')&&!/(?:fixture|dataset)/i.test(path.basename(filename)));
const compilerHost=ts.createCompilerHost(options);
const sourceFileCache=new Map();
const readSourceFile=compilerHost.getSourceFile.bind(compilerHost);
compilerHost.getSourceFile=(filename,languageVersion,onError,shouldCreateNewSourceFile)=>{
  if(!sourceFileCache.has(filename))sourceFileCache.set(filename,readSourceFile(filename,languageVersion,onError,shouldCreateNewSourceFile));
  return sourceFileCache.get(filename);
};
const initial = ts.createProgram([originalEntry, ...ambientRoots], options, compilerHost);
const roots = initial.getSourceFiles().filter(f => !f.isDeclarationFile && !f.fileName.endsWith('.json')).map(f => f.fileName);
const program = ts.createProgram([originalEntry, ...ambientRoots, ...roots], options, compilerHost, initial);
const diagnostics = ts.getPreEmitDiagnostics(program);
if (diagnostics.length) throw new Error(ts.formatDiagnosticsWithColorAndContext(diagnostics, { getCanonicalFileName:f=>f, getCurrentDirectory:()=>sourceRoot, getNewLine:()=> '\n' }));
fs.rmSync(stage, { recursive: true, force: true });
fs.mkdirSync(stage, { recursive: true });
const originalForStaged = new Map();
const declarationRegenerations = [];
const regenerateRuntimeDeclaration = source => {
  const virtualPath=source.fileName.replace(/\.d\.ts$/,'.declaration-source.ts');
  const host=ts.createCompilerHost(options);
  const normalGetSourceFile=host.getSourceFile.bind(host);
  const normalFileExists=host.fileExists.bind(host);
  const normalReadFile=host.readFile.bind(host);
  host.fileExists=filename=>filename===virtualPath||normalFileExists(filename);
  host.readFile=filename=>filename===virtualPath?source.text:normalReadFile(filename);
  host.getSourceFile=(filename,languageVersion,onError,shouldCreateNewSourceFile)=>filename===virtualPath?ts.createSourceFile(filename,source.text,languageVersion,true):normalGetSourceFile(filename,languageVersion,onError,shouldCreateNewSourceFile);
  const declarationProgram=ts.createProgram([virtualPath],options,host);
  let regenerated;
  const emit=declarationProgram.emit(declarationProgram.getSourceFile(virtualPath),(filename,text)=>{if(filename.endsWith('.d.ts'))regenerated=text;});
  if(emit.emitSkipped||emit.diagnostics.length||!regenerated)throw new Error(`Runtime declaration regeneration failed: ${source.fileName}`);
  const crypto=require('crypto');
  declarationRegenerations.push({source:path.relative(sourceRoot,source.fileName),originalSha256:crypto.createHash('sha256').update(source.text).digest('hex'),regeneratedSha256:crypto.createHash('sha256').update(regenerated).digest('hex')});
  return regenerated;
};
const stagePath = original => {
  const relative = path.relative(sourceRoot, original);
  if (relative.startsWith('..') || path.isAbsolute(relative)) throw new Error(`Unmapped source outside source root: ${original}`);
  return path.join(stage, relative).replace(/(?<!\.d)\.(tsx?|mts|cts)$/, '.d.ts');
};
for (const original of roots) {
  const source = program.getSourceFile(original);
  const emit = program.emit(source, (filename, data, bom, onError, sourceFiles) => {
    fs.mkdirSync(path.dirname(filename), { recursive: true });
    fs.writeFileSync(filename, data);
    if (sourceFiles && sourceFiles.length === 1) originalForStaged.set(filename, sourceFiles[0].fileName);
  });
  if (emit.emitSkipped || emit.diagnostics.length) throw new Error(`Declaration emit failed for ${original}: ${emit.emitSkipped}, ${emit.diagnostics.length}`);
}
for (const source of program.getSourceFiles()) {
  if (!source.isDeclarationFile && !source.fileName.endsWith('.json')) continue;
  const filename = stagePath(source.fileName);
  fs.mkdirSync(path.dirname(filename), { recursive: true });
  const hasRuntimeInitializer=source.isDeclarationFile&&source.statements.some(statement=>ts.isVariableStatement(statement)&&statement.declarationList.declarations.some(declaration=>declaration.initializer));
  fs.writeFileSync(filename, hasRuntimeInitializer?regenerateRuntimeDeclaration(source):source.text);
  if (source.isDeclarationFile) originalForStaged.set(filename, source.fileName);
}
const stagedForOriginal = new Map();
for (const [filename, original] of originalForStaged) {
  stagedForOriginal.set(original, filename);
  stagedForOriginal.set(fs.realpathSync(original), filename);
}
const redirectOriginal = new Map();
for (const [target, aliases] of program.redirectTargetsMap) {
  for (const alias of aliases) {
    redirectOriginal.set(alias, target);
    redirectOriginal.set(fs.realpathSync(alias), target);
  }
}
const preservedPaths = { '@tscircuit/capacity-autorouter':[stagePath(originalEntry)] };
const {getLibraryName}=require(path.join(sourceRoot, 'node_modules/dts-bundle-generator/dist/helpers/node-modules'));
const inlinedLibraries=[...new Set(program.getSourceFiles().map(f=>getLibraryName(f.fileName)).filter(n=>n && n !== 'typescript' && n !== 'bun-types' && n !== '@types/bun' && n !== '@types/node'))];
const publicTypeBoundaryNames=new Set(['circuit-json','zod','@tscircuit/core','transformation-matrix']);
const publicDependencies={};
const publicBoundaryExports=new Map();
const preservePublicBoundary=name=>{
  if(!publicTypeBoundaryNames.has(name))return undefined;
  if(!publicDependencies[name])publicDependencies[name]=JSON.parse(fs.readFileSync(path.join(sourceRoot,'node_modules',name,'package.json'),'utf8')).version;
  return name;
};
const publicBoundaryForSpecifier=specifier=>[...publicTypeBoundaryNames].find(name=>specifier===name||specifier.startsWith(name+'/'));
const duplicateGlobalDeclarations = [];
const stagedSource = filename => program.getSourceFile(originalForStaged.get(filename));
const checker=program.getTypeChecker();
const printer=ts.createPrinter();
let narrowedStatements=0;
const declarationTarget = original => {
  const real=fs.realpathSync(original);
  const canonical=redirectOriginal.get(original)||redirectOriginal.get(real)||real;
  return stagedForOriginal.get(canonical)||stagedForOriginal.get(original)||stagedForOriginal.get(real);
};
const canonicalSymbol = symbol => symbol && (symbol.flags & ts.SymbolFlags.Alias) ? checker.getAliasedSymbol(symbol) : symbol;
let rewrittenImports = 0;
let unresolvedImports = new Set();
const declarationQueue = [stagePath(originalEntry)];
const queuedDeclarations = new Set(declarationQueue);
for (const filename of declarationQueue) {
  const original = originalForStaged.get(filename);
  if (!original) throw new Error(`Declaration lacks compiler source provenance: ${filename}`);
  const effectiveOriginal = redirectOriginal.get(original) || redirectOriginal.get(fs.realpathSync(original)) || original;
  const text = fs.readFileSync(filename, 'utf8');
  const source = ts.createSourceFile(filename, text, ts.ScriptTarget.Latest, true);
  const replacements = [];
  const visit = node => {
    let literal;
    if ((ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) && node.moduleSpecifier && ts.isStringLiteral(node.moduleSpecifier)) literal = node.moduleSpecifier;
    else if (ts.isImportTypeNode(node) && ts.isLiteralTypeNode(node.argument) && ts.isStringLiteral(node.argument.literal)) literal = node.argument.literal;
    else if (ts.isExternalModuleReference(node) && node.expression && ts.isStringLiteral(node.expression)) literal = node.expression;
    if (literal) {
      const directPublicBoundary=publicBoundaryForSpecifier(literal.text);
      if(directPublicBoundary){preservePublicBoundary(directPublicBoundary);return;}
      const originalSource = program.getSourceFile(effectiveOriginal) || program.getSourceFile(original);
      const originalImport = originalSource?.imports?.find(candidate=>candidate.text === literal.text);
      const elements=ts.isImportDeclaration(node)&&node.importClause?.namedBindings&&ts.isNamedImports(node.importClause.namedBindings)&&!node.importClause.name ? node.importClause.namedBindings.elements : ts.isExportDeclaration(node)&&node.exportClause&&ts.isNamedExports(node.exportClause) ? node.exportClause.elements : undefined;
      const moduleSymbol=originalImport&&checker.getSymbolAtLocation(originalImport);
      let enclosingAmbient = literal.parent;
      while (enclosingAmbient && !(ts.isModuleDeclaration(enclosingAmbient) && ts.isStringLiteral(enclosingAmbient.name))) enclosingAmbient = enclosingAmbient.parent;
      if (elements && moduleSymbol && !enclosingAmbient) {
        const exports=checker.getExportsOfModule(moduleSymbol);
        const declarations=[];
        for (const element of elements) {
          const exportedName=(element.propertyName||element.name).text;
          const symbol=canonicalSymbol(exports.find(candidate=>candidate.name===exportedName));
          const definingSource=symbol?.declarations?.[0]?.getSourceFile();
          const definingModule=definingSource&&checker.getSymbolAtLocation(definingSource);
          const target=definingSource&&declarationTarget(definingSource.fileName);
          const definingLibrary=definingSource&&getLibraryName(definingSource.fileName);
          let publicExport;
          if(publicTypeBoundaryNames.has(definingLibrary)){
            if(!publicBoundaryExports.has(definingLibrary)){
              const resolvedBoundary=ts.resolveModuleName(definingLibrary,originalEntry,options,ts.sys).resolvedModule;
              const boundarySource=resolvedBoundary&&program.getSourceFile(resolvedBoundary.resolvedFileName);
              const boundarySymbol=boundarySource&&checker.getSymbolAtLocation(boundarySource);
              publicBoundaryExports.set(definingLibrary,boundarySymbol?checker.getExportsOfModule(boundarySymbol):[]);
            }
            publicExport=publicBoundaryExports.get(definingLibrary).find(candidate=>canonicalSymbol(candidate)===symbol);
          }
          const realExport=definingModule&&checker.getExportsOfModule(definingModule).find(candidate=>canonicalSymbol(candidate)===symbol);
          if (!target || !realExport || !ts.isExternalModule(definingSource)) { declarations.length=0; break; }
          let relative=path.relative(path.dirname(filename),target).replaceAll(path.sep,'/');
          if(!relative.startsWith('.'))relative='./'+relative;
          relative=relative.replace(/\.d\.mts$/,'.mjs').replace(/\.d\.cts$/,'.cjs').replace(/\.d\.ts$/,'');
          if(publicExport)relative=preservePublicBoundary(definingLibrary);
          const actualName=publicExport?publicExport.name:realExport.name;
          const property=actualName===element.name.text?undefined:ts.factory.createIdentifier(actualName);
          const specifier=ts.isImportDeclaration(node)?ts.factory.createImportSpecifier(element.isTypeOnly,property,ts.factory.createIdentifier(element.name.text)):ts.factory.createExportSpecifier(element.isTypeOnly,property,ts.factory.createIdentifier(element.name.text));
          const declaration=ts.isImportDeclaration(node)?ts.factory.createImportDeclaration(undefined,ts.factory.createImportClause(node.importClause.isTypeOnly,undefined,ts.factory.createNamedImports([specifier])),ts.factory.createStringLiteral(relative),undefined):ts.factory.createExportDeclaration(undefined,node.isTypeOnly,ts.factory.createNamedExports([specifier]),ts.factory.createStringLiteral(relative),undefined);
          declarations.push({target:publicExport?undefined:target,declaration});
        }
        if(declarations.length===elements.length && declarations.length>0) {
          for(const item of declarations)if(item.target&&!queuedDeclarations.has(item.target)){queuedDeclarations.add(item.target);declarationQueue.push(item.target);}
          replacements.push({start:node.getStart(source),end:node.getEnd(),text:declarations.map(item=>printer.printNode(ts.EmitHint.Unspecified,item.declaration,source)).join('\n')});
          narrowedStatements++;
          return;
        }
      }
      const captured = originalImport && program.getResolvedModuleFromModuleSpecifier(originalImport, originalSource)?.resolvedModule;
      const resolved = captured || ts.resolveModuleName(literal.text, effectiveOriginal, options, ts.sys).resolvedModule;
      if(resolved&&publicTypeBoundaryNames.has(getLibraryName(resolved.resolvedFileName))){
        const publicBoundary=preservePublicBoundary(getLibraryName(resolved.resolvedFileName));
        replacements.push({start:literal.getStart(source)+1,end:literal.getEnd()-1,text:publicBoundary});
        return;
      }
      if (resolved && !['.js', '.jsx', '.mjs', '.cjs'].includes(resolved.extension)) {
        const resolvedRealpath = fs.realpathSync(resolved.resolvedFileName);
        const canonicalResolved = redirectOriginal.get(resolved.resolvedFileName) || redirectOriginal.get(resolvedRealpath) || resolvedRealpath;
        const target = stagedForOriginal.get(canonicalResolved) || stagedForOriginal.get(resolved.resolvedFileName) || stagedForOriginal.get(resolvedRealpath) || stagePath(canonicalResolved);
        if (!fs.existsSync(target)) throw new Error(`Missing compiler declaration: ${literal.text} from ${original} resolves to ${target}`);
        if (originalForStaged.has(target) && !queuedDeclarations.has(target)) { queuedDeclarations.add(target); declarationQueue.push(target); }
        let relative = path.relative(path.dirname(filename), target).replaceAll(path.sep, '/');
        if (!relative.startsWith('.')) relative = `./${relative}`;
        relative=relative.replace(/\.d\.mts$/,'.mjs').replace(/\.d\.cts$/,'.cjs').replace(/\.d\.ts$/,'');
        let enclosing = literal.parent;
        while (enclosing && !(ts.isModuleDeclaration(enclosing) && ts.isStringLiteral(enclosing.name))) enclosing = enclosing.parent;
        const targetSource = stagedSource(target);
        const globalModule = targetSource && !ts.isExternalModule(targetSource);
        if ((enclosing || globalModule || literal.text === '@tscircuit/core') && !literal.text.startsWith('.')) {
          if (preservedPaths[literal.text] && preservedPaths[literal.text][0] !== target) {
            const previous = stagedSource(preservedPaths[literal.text][0]);
            if (!globalModule || !previous || ts.isExternalModule(previous) || previous.text !== targetSource.text) throw new Error(`Ambient import context conflict: ${literal.text}, ${preservedPaths[literal.text][0]} versus ${target}, importer ${effectiveOriginal}`);
            duplicateGlobalDeclarations.push({ module:literal.text, first:preservedPaths[literal.text][0], duplicate:target });
          } else preservedPaths[literal.text] = [target];
        } else {
          replacements.push({ start: literal.getStart(source) + 1, end: literal.getEnd() - 1, text: relative });
          rewrittenImports++;
        }
      } else unresolvedImports.add(literal.text);
    }
    ts.forEachChild(node, visit);
  };
  visit(source);
  for (const reference of source.referencedFiles) {
    const originalTarget = path.resolve(path.dirname(effectiveOriginal), reference.fileName);
    const target = stagedForOriginal.get(originalTarget) || (fs.existsSync(originalTarget) && stagedForOriginal.get(fs.realpathSync(originalTarget))) || stagePath(originalTarget);
    if (!fs.existsSync(target)) throw new Error(`Missing referenced declaration: ${originalTarget}`);
    if (!queuedDeclarations.has(target)) { queuedDeclarations.add(target); declarationQueue.push(target); }
    let relative = path.relative(path.dirname(filename), target).replaceAll(path.sep, '/');
    if (!relative.startsWith('.')) relative = `./${relative}`;
    replacements.push({ start: reference.pos, end: reference.end, text: relative });
  }
  replacements.sort((a,b) => b.start-a.start);
  let rewritten = text;
  for (const replacement of replacements) rewritten = rewritten.slice(0,replacement.start) + replacement.text + rewritten.slice(replacement.end);
  fs.writeFileSync(filename, rewritten);
}
for (const source of program.getSourceFiles()) {
  if (!source.fileName.startsWith(path.join(sourceRoot,'lib')+path.sep) && !source.fileName.startsWith(path.join(sourceRoot,'types')+path.sep)) continue;
  if (fs.readFileSync(source.fileName,'utf8') !== source.text) throw new Error(`Source changed during declaration snapshot: ${source.fileName}`);
}
fs.writeFileSync(path.join(scratch,'reachable-declarations.json'),JSON.stringify({entry:stagePath(originalEntry),files:declarationQueue},null,2));
const stagedEntry = stagePath(originalEntry);
const boundaryFiles=declarationQueue.filter(filename=>publicTypeBoundaryNames.has(getLibraryName(filename)));
if(boundaryFiles.length)throw new Error(`Public package declarations were inlined: ${boundaryFiles.join(', ')}`);
for(const name of publicTypeBoundaryNames)fs.rmSync(path.join(stage,'node_modules',name),{recursive:true,force:true});
const validationModules=path.join(scratch,'node_modules');
fs.mkdirSync(validationModules,{recursive:true});
for(const name of Object.keys(publicDependencies)){
  const installedPath=path.join(validationModules,name);
  fs.mkdirSync(path.dirname(installedPath),{recursive:true});
  if(!fs.existsSync(installedPath))fs.symlinkSync(path.join(sourceRoot,'node_modules',name),installedPath,'dir');
}
if(publicDependencies['circuit-json'])preservePublicBoundary('zod');
fs.writeFileSync(path.join(scratch,'public-type-dependencies.json'),JSON.stringify(publicDependencies,null,2)+'\n');
const globalReferences=[...new Set(Object.values(preservedPaths).map(paths=>paths[0]).filter(filename=>{const source=stagedSource(filename);return source&&!ts.isExternalModule(source);}))];
const globalReferenceText=globalReferences.map(filename=>{let relative=path.relative(path.dirname(stagedEntry),filename).replaceAll(path.sep,'/');if(!relative.startsWith('.'))relative='./'+relative;return `/// <reference path="${relative}" />`;}).join('\n');
fs.writeFileSync(stagedEntry,globalReferenceText+'\n'+fs.readFileSync(stagedEntry,'utf8'));
fs.writeFileSync(path.join(scratch, 'tsconfig.materialized.json'), JSON.stringify({ compilerOptions: { target:'ES2022', module:'ESNext', moduleResolution:'Bundler', strict:true, skipLibCheck:true, noEmit:true, allowImportingTsExtensions:true, types:[], baseUrl:stage, paths:preservedPaths } }, null, 2));
fs.writeFileSync(path.join(scratch, 'dts-bundle-materialized.config.json'), JSON.stringify({ compilationOptions: { preferredConfigPath:path.join(scratch,'tsconfig.materialized.json') }, entries:[{filePath:stagedEntry,outFile:path.join(scratch,'index.standalone.d.ts'),libraries:{inlinedLibraries},output:{exportReferencedTypes:false}}] }, null, 2));
console.log(JSON.stringify({ sourceRoot, originalEntry, stagedEntry, emittedSources:roots.length, materializedDeclarations:originalForStaged.size, rewrittenImports, processedDeclarations:declarationQueue.length, narrowedStatements, inlinedLibraries, duplicateGlobalDeclarations, unresolvedImports:[...unresolvedImports] }));

const strictOptions={target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,moduleResolution:ts.ModuleResolutionKind.Bundler,strict:true,skipLibCheck:false,noEmit:true,types:[]};
const closureProgram=ts.createProgram([stagedEntry],strictOptions);
const closureDiagnostics=ts.getPreEmitDiagnostics(closureProgram);
if(closureDiagnostics.length)throw new Error(ts.formatDiagnosticsWithColorAndContext(closureDiagnostics,{getCanonicalFileName:f=>f,getCurrentDirectory:()=>sourceRoot,getNewLine:()=> '\n'}));
const crypto=require('crypto');
const provenance={publicDependencies,typescript:ts.version,bundleGenerator:require(path.join(sourceRoot,'node_modules/dts-bundle-generator/package.json')).version,strict:true,skipLibCheck:false,diagnostics:0,sourceEntrySha256:crypto.createHash('sha256').update(fs.readFileSync(originalEntry)).digest('hex'),reachableFiles:declarationQueue.length,declarationRegenerations,globalReferences:globalReferences.map(filename=>path.relative(stage,filename)),files:declarationQueue.map(filename=>({path:path.relative(stage,filename),sha256:crypto.createHash('sha256').update(fs.readFileSync(filename)).digest('hex')}))};
fs.writeFileSync(path.join(scratch,'standalone-declarations-provenance.json'),JSON.stringify(provenance,null,2)+'\n');
console.log(JSON.stringify({stagedEntry,strict:true,skipLibCheck:false,diagnostics:0,reachableFiles:declarationQueue.length,publicDependencies,declarationRegenerations,globalReferences:provenance.globalReferences}));
