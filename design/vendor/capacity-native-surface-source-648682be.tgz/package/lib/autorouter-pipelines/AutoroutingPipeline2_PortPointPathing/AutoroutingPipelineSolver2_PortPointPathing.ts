import { RectDiffPipeline } from "@tscircuit/rectdiff"
import { ConnectivityMap } from "circuit-json-to-connectivity-map"
import type { GraphicsObject, Line } from "graphics-debug"
import { getGlobalInMemoryCache } from "lib/cache/setupGlobalCaches"
import { CacheProvider } from "lib/cache/types"
import { UniformPortDistributionSolver } from "lib/solvers/UniformPortDistributionSolver/UniformPortDistributionSolver"
import { getDrcErrors } from "lib/testing/getDrcErrors"
import { convertToCircuitJson } from "lib/testing/utils/convertToCircuitJson"
import {
  HighDensityIntraNodeRoute,
  HighDensityRoute,
} from "lib/types/high-density-types"
import { convertHdRouteToSimplifiedRoute } from "lib/utils/convertHdRouteToSimplifiedRoute"
import { convertSrjToGraphicsObject } from "lib/utils/convertSrjToGraphicsObject"
import { createObstacleLabelFormatter } from "lib/utils/formatObstacleLabel"
import {
  getGraphicsLayerForConnectionPoint,
  getGraphicsLayerForObstacle,
} from "lib/utils/getGraphicsObjectLayer"
import { getConnectivityMapFromSimpleRouteJson } from "lib/utils/getConnectivityMapFromSimpleRouteJson"
import { getInitiallyConnectedMapFromSimpleRouteJson } from "lib/utils/get-initially-connected-map-from-simple-route-json"
import { getViaDimensions } from "lib/utils/getViaDimensions"
import { AvailableSegmentPointSolver } from "../../solvers/AvailableSegmentPointSolver/AvailableSegmentPointSolver"
import { BaseSolver } from "../../solvers/BaseSolver"
import { CapacityMeshEdgeSolver } from "../../solvers/CapacityMeshSolver/CapacityMeshEdgeSolver"
import { CapacityMeshEdgeSolver2_NodeTreeOptimization } from "../../solvers/CapacityMeshSolver/CapacityMeshEdgeSolver2_NodeTreeOptimization"
import { CapacityMeshNodeSolver2_NodeUnderObstacle } from "../../solvers/CapacityMeshSolver/CapacityMeshNodeSolver2_NodesUnderObstacles"
import { CapacityNodeTargetMerger } from "../../solvers/CapacityNodeTargetMerger/CapacityNodeTargetMerger"
import { DeadEndSolver } from "../../solvers/DeadEndSolver/DeadEndSolver"
import { HighDensitySolver } from "../../solvers/HighDensitySolver/HighDensitySolver"
import { MultiSectionPortPointOptimizer } from "../../solvers/MultiSectionPortPointOptimizer"
import { NetToPointPairsSolver } from "../../solvers/NetToPointPairsSolver/NetToPointPairsSolver"
import { NetToPointPairsSolver2_OffBoardConnection } from "../../solvers/NetToPointPairsSolver2_OffBoardConnection/NetToPointPairsSolver2_OffBoardConnection"
import {
  HyperPortPointPathingSolver,
  HyperPortPointPathingSolverParams,
} from "../../solvers/PortPointPathingSolver/HyperPortPointPathingSolver"
import {
  InputNodeWithPortPoints,
  InputPortPoint,
  PortPointPathingSolver,
} from "../../solvers/PortPointPathingSolver/PortPointPathingSolver"
import { MultipleHighDensityRouteStitchSolver } from "../../solvers/RouteStitchingSolver/MultipleHighDensityRouteStitchSolver"
import { SingleLayerNodeMergerSolver } from "../../solvers/SingleLayerNodeMerger/SingleLayerNodeMergerSolver"
import { StrawSolver } from "../../solvers/StrawSolver/StrawSolver"
import { TraceSimplificationSolver } from "@tscircuit/trace-simplification-solver"
import { TraceWidthSolver } from "../../solvers/TraceWidthSolver/TraceWidthSolver"
import { getColorMap } from "../../solvers/colors"
import type {
  CapacityMeshEdge,
  CapacityMeshNode,
  SimpleRouteJson,
  SimplifiedPcbTrace,
  SimplifiedPcbTraces,
  TraceId,
} from "../../types"
import { combineVisualizations } from "../../utils/combineVisualizations"
import { calculateOptimalCapacityDepth } from "../../utils/getTunedTotalCapacity1"

interface CapacityMeshSolverOptions {
  capacityDepth?: number
  targetMinCapacity?: number
  cacheProvider?: CacheProvider | null
  effort?: number
}
export type AutoroutingPipelineSolverOptions = CapacityMeshSolverOptions

type PipelineStep<T extends new (...args: any[]) => BaseSolver> = {
  solverName: string
  solverClass: T
  getConstructorParams: (
    instance: AutoroutingPipelineSolver2_PortPointPathing,
  ) => ConstructorParameters<T>
  onSolved?: (instance: AutoroutingPipelineSolver2_PortPointPathing) => void
}

function definePipelineStep<
  T extends new (
    ...args: any[]
  ) => BaseSolver,
  const P extends ConstructorParameters<T>,
>(
  solverName: keyof AutoroutingPipelineSolver2_PortPointPathing,
  solverClass: T,
  getConstructorParams: (
    instance: AutoroutingPipelineSolver2_PortPointPathing,
  ) => P,
  opts: {
    onSolved?: (instance: AutoroutingPipelineSolver2_PortPointPathing) => void
  } = {},
): PipelineStep<T> {
  return {
    solverName,
    solverClass,
    getConstructorParams,
    onSolved: opts.onSolved,
  }
}

export class AutoroutingPipelineSolver2_PortPointPathing extends BaseSolver {
  override getSolverName(): string {
    return "AutoroutingPipelineSolver2_PortPointPathing"
  }

  netToPointPairsSolver?: NetToPointPairsSolver
  // nodeSolver?: CapacityMeshNodeSolver2_NodeUnderObstacle
  nodeSolver?: RectDiffPipeline
  nodeTargetMerger?: CapacityNodeTargetMerger
  edgeSolver?: CapacityMeshEdgeSolver
  colorMap: Record<string, string>
  highDensityRouteSolver?: HighDensitySolver
  highDensityStitchSolver?: MultipleHighDensityRouteStitchSolver
  singleLayerNodeMerger?: SingleLayerNodeMergerSolver
  strawSolver?: StrawSolver
  deadEndSolver?: DeadEndSolver
  traceSimplificationSolver?: TraceSimplificationSolver
  availableSegmentPointSolver?: AvailableSegmentPointSolver
  portPointPathingSolver?: HyperPortPointPathingSolver
  multiSectionPortPointOptimizer?: MultiSectionPortPointOptimizer
  uniformPortDistributionSolver?: UniformPortDistributionSolver
  traceWidthSolver?: TraceWidthSolver
  viaDiameter: number
  minTraceWidth: number
  effort: number

  startTimeOfPhase: Record<string, number>
  endTimeOfPhase: Record<string, number>
  timeSpentOnPhase: Record<string, number>

  activeSubSolver?: BaseSolver | null = null
  connMap: ConnectivityMap
  srjWithPointPairs?: SimpleRouteJson
  capacityNodes: CapacityMeshNode[] | null = null
  capacityEdges: CapacityMeshEdge[] | null = null
  inputNodeWithPortPoints: InputNodeWithPortPoints[] = []

  cacheProvider: CacheProvider | null = null
  pipelineDef = [
    definePipelineStep(
      "netToPointPairsSolver",
      NetToPointPairsSolver2_OffBoardConnection,
      (cms) => [
        cms.srj,
        cms.colorMap,
        getInitiallyConnectedMapFromSimpleRouteJson(cms.srj),
      ],
      {
        onSolved: (cms) => {
          cms.srjWithPointPairs =
            cms.netToPointPairsSolver?.getNewSimpleRouteJson()
          cms.colorMap = getColorMap(cms.srjWithPointPairs!, this.connMap)
          cms.connMap = getConnectivityMapFromSimpleRouteJson(
            cms.srjWithPointPairs!,
          )
        },
      },
    ),
    definePipelineStep(
      "nodeSolver",
      RectDiffPipeline,
      // Cast to any because RectDiffSolver uses an older SimpleRouteJson type
      // that doesn't support MultiLayerConnectionPoint yet
      (cms) => [
        { simpleRouteJson: cms.srjWithPointPairs! as any, maxGapFillPasses: 4 },
      ],
      {
        onSolved: (cms) => {
          cms.capacityNodes = cms.nodeSolver?.getOutput().meshNodes ?? []
        },
      },
    ),
    // definePipelineStep(
    //   "nodeSolver",
    //   CapacityMeshNodeSolver2_NodeUnderObstacle,
    //   (cms) => [
    //     cms.netToPointPairsSolver?.getNewSimpleRouteJson() || cms.srj,
    //     cms.opts,
    //   ],
    //   {
    //     onSolved: (cms) => {
    //       cms.capacityNodes = cms.nodeSolver?.finishedNodes!
    //     },
    //   },
    // ),
    // definePipelineStep(
    //   "singleLayerNodeMerger",
    //   SingleLayerNodeMergerSolver,
    //   (cms) => [cms.nodeSolver?.finishedNodes!],
    //   {
    //     onSolved: (cms) => {
    //       cms.capacityNodes = cms.singleLayerNodeMerger?.newNodes!
    //     },
    //   },
    // ),
    // definePipelineStep(
    //   "strawSolver",
    //   StrawSolver,
    //   (cms) => [{ nodes: cms.capacityNodes! }],
    //   {
    //     onSolved: (cms) => {
    //       cms.capacityNodes = cms.strawSolver?.getResultNodes()!
    //     },
    //   },
    // ),
    definePipelineStep(
      "edgeSolver",
      CapacityMeshEdgeSolver2_NodeTreeOptimization,
      (cms) => [cms.capacityNodes!],
      {
        onSolved: (cms) => {
          cms.capacityEdges = cms.edgeSolver?.edges!
        },
      },
    ),
    // definePipelineStep(
    //   "deadEndSolver",
    //   DeadEndSolver,
    //   (cms) => [{ nodes: cms.capacityNodes!, edges: cms.capacityEdges! }],
    //   {
    //     onSolved: (cms) => {
    //       const removedNodeIds = cms.deadEndSolver?.removedNodeIds!

    //       cms.capacityNodes = cms.capacityNodes!.filter(
    //         (n) => !removedNodeIds.has(n.capacityMeshNodeId),
    //       )
    //       cms.capacityEdges = cms.capacityEdges!.filter((e) =>
    //         e.nodeIds.every((nodeId) => !removedNodeIds.has(nodeId)),
    //       )
    //     },
    //   },
    // ),
    definePipelineStep(
      "availableSegmentPointSolver",
      AvailableSegmentPointSolver,
      (cms) => [
        {
          nodes: cms.capacityNodes!,
          edges: cms.capacityEdges || [],
          traceWidth: cms.minTraceWidth,
          colorMap: cms.colorMap,
          shouldReturnCrampedPortPoints: false,
        },
      ],
    ),
    definePipelineStep(
      "portPointPathingSolver",
      HyperPortPointPathingSolver,
      (cms) => {
        // Convert capacity nodes and segment points to InputNodeWithPortPoints
        this.inputNodeWithPortPoints = cms.capacityNodes!.map((node) => ({
          capacityMeshNodeId: node.capacityMeshNodeId,
          center: node.center,
          width: node.width,
          height: node.height,
          portPoints: [] as InputPortPoint[],
          availableZ: node.availableZ,
          _containsTarget: node._containsTarget,
          _containsObstacle: node._containsObstacle,
        }))

        // Build a map for quick lookup
        const nodeMap = new Map(
          this.inputNodeWithPortPoints.map((n) => [n.capacityMeshNodeId, n]),
        )

        // Add port points from the available segment point solver
        const segmentPointSolver = cms.availableSegmentPointSolver!
        for (const segment of segmentPointSolver.sharedEdgeSegments) {
          for (const segmentPortPoint of segment.portPoints) {
            const [nodeId1, nodeId2] = segmentPortPoint.nodeIds
            const inputPortPoint: InputPortPoint = {
              portPointId: segmentPortPoint.segmentPortPointId,
              x: segmentPortPoint.x,
              y: segmentPortPoint.y,
              z: segmentPortPoint.availableZ[0] ?? 0,
              connectionNodeIds: [nodeId1, nodeId2],
              distToCentermostPortOnZ: segmentPortPoint.distToCentermostPortOnZ,
            }

            // Add to first node
            const node1 = nodeMap.get(nodeId1)
            if (node1) {
              node1.portPoints.push(inputPortPoint)
            }
            // Note: Don't add to second node - the solver will handle the shared edge
          }
        }

        return [
          {
            simpleRouteJson: cms.srjWithPointPairs!,
            inputNodes: this.inputNodeWithPortPoints,
            capacityMeshNodes: cms.capacityNodes!,
            colorMap: cms.colorMap,
            numShuffleSeeds: 200,
            hyperParameters: {
              NODE_PF_MAX_PENALTY: 100,
              FORCE_OFF_BOARD_FREQUENCY: 0,
              STRAIGHT_LINE_DEVIATION_PENALTY_FACTOR: 4,
              // MAX_ITERATIONS_PER_PATH: 10e3,
            },
          } as HyperPortPointPathingSolverParams,
        ]
      },
    ),
    definePipelineStep(
      "multiSectionPortPointOptimizer",
      MultiSectionPortPointOptimizer,
      (cms) => {
        const portPointSolver = cms.portPointPathingSolver!
        return [
          {
            simpleRouteJson: cms.srjWithPointPairs!,
            inputNodes: portPointSolver.inputNodes,
            capacityMeshNodes: cms.capacityNodes!,
            capacityMeshEdges: cms.capacityEdges!,
            colorMap: cms.colorMap,
            initialConnectionResults: portPointSolver.connectionsWithResults,
            initialAssignedPortPoints: portPointSolver.assignedPortPoints,
            initialNodeAssignedPortPoints:
              portPointSolver.nodeAssignedPortPoints,
            effort: Math.min(1, cms.effort),
          },
        ]
      },
    ),
    definePipelineStep(
      "uniformPortDistributionSolver",
      UniformPortDistributionSolver,
      (cms) => [
        {
          nodeWithPortPoints:
            cms.multiSectionPortPointOptimizer?.getNodesWithPortPoints() ??
            cms.portPointPathingSolver?.getNodesWithPortPoints() ??
            [],
          inputNodesWithPortPoints: this.inputNodeWithPortPoints,
          minTraceWidth: cms.minTraceWidth,
          obstacles: cms.srj.obstacles,
          layerCount: cms.srj.layerCount,
        },
      ],
    ),
    definePipelineStep("highDensityRouteSolver", HighDensitySolver, (cms) => [
      {
        nodePortPoints:
          cms.uniformPortDistributionSolver?.getOutput() ??
          cms.multiSectionPortPointOptimizer?.getNodesWithPortPoints() ??
          cms.portPointPathingSolver?.getNodesWithPortPoints() ??
          [],
        nodePfById:
          cms.multiSectionPortPointOptimizer?.nodePfMap ??
          new Map(
            (cms.portPointPathingSolver?.inputNodes ?? []).map((node) => [
              node.capacityMeshNodeId,
              cms.portPointPathingSolver?.computeNodePf(node) ?? null,
            ]),
          ),
        colorMap: cms.colorMap,
        connMap: cms.connMap,
        viaDiameter: cms.viaDiameter,
        traceWidth: cms.minTraceWidth,
        effort: Math.min(1, cms.effort),
      },
    ]),
    definePipelineStep(
      "highDensityStitchSolver",
      MultipleHighDensityRouteStitchSolver,
      (cms) => [
        {
          connections: cms.srjWithPointPairs!.connections,
          hdRoutes: cms.highDensityRouteSolver!.routes,
          colorMap: cms.colorMap,
          layerCount: cms.srj.layerCount,
          defaultViaDiameter: cms.viaDiameter,
        },
      ],
    ),
    definePipelineStep(
      "traceSimplificationSolver",
      TraceSimplificationSolver,
      (cms) => [
        {
          hdRoutes: cms.highDensityStitchSolver!.mergedHdRoutes,
          obstacles: cms.srj.obstacles,
          connMap: cms.connMap,
          colorMap: cms.colorMap,
          outline: cms.srj.outline,
          defaultViaDiameter: cms.viaDiameter,
          layerCount: cms.srj.layerCount,
          iterations: 2,
        },
      ],
    ),
    definePipelineStep("traceWidthSolver", TraceWidthSolver, (cms) => {
      return [
        {
          hdRoutes: cms.traceSimplificationSolver!.simplifiedHdRoutes,
          obstacles: cms.srj.obstacles,
          connMap: cms.connMap,
          colorMap: cms.colorMap,
          minTraceWidth: cms.minTraceWidth,
          connection: cms.srj.connections,
          layerCount: cms.srj.layerCount,
        },
      ]
    }),
  ]

  constructor(
    public readonly srj: SimpleRouteJson,
    public readonly opts: CapacityMeshSolverOptions = {},
  ) {
    super()
    this.srj = srj
    this.opts = { ...opts }
    this.viaDiameter = getViaDimensions(srj).padDiameter
    this.minTraceWidth = srj.minTraceWidth
    const mutableOpts = this.opts
    this.effort = mutableOpts.effort ?? 1
    // scale with effort so the outer cap never decapitates inner solvers
    this.MAX_ITERATIONS = 100e6 * this.effort

    // If capacityDepth is not provided, calculate it automatically
    if (mutableOpts.capacityDepth === undefined) {
      // Calculate max width/height from bounds for initial node size
      const boundsWidth = srj.bounds.maxX - srj.bounds.minX
      const boundsHeight = srj.bounds.maxY - srj.bounds.minY
      const maxWidthHeight = Math.max(boundsWidth, boundsHeight)

      // Use the calculateOptimalCapacityDepth function to determine the right depth
      const targetMinCapacity = mutableOpts.targetMinCapacity ?? 0.5
      mutableOpts.capacityDepth = calculateOptimalCapacityDepth(
        maxWidthHeight,
        targetMinCapacity,
      )
    }

    this.connMap = getConnectivityMapFromSimpleRouteJson(srj)
    this.colorMap = getColorMap(srj, this.connMap)
    this.cacheProvider =
      mutableOpts.cacheProvider === undefined
        ? getGlobalInMemoryCache()
        : mutableOpts.cacheProvider === null
          ? null
          : mutableOpts.cacheProvider
    this.startTimeOfPhase = {}
    this.endTimeOfPhase = {}
    this.timeSpentOnPhase = {}
  }

  getConstructorParams() {
    return [this.srj, this.opts] as const
  }

  currentPipelineStepIndex = 0
  _step() {
    const pipelineStepDef = this.pipelineDef[this.currentPipelineStepIndex]
    if (!pipelineStepDef) {
      this.solved = true
      return
    }

    if (this.activeSubSolver) {
      this.activeSubSolver.step()
      if (this.activeSubSolver.solved) {
        this.endTimeOfPhase[pipelineStepDef.solverName] = performance.now()
        this.timeSpentOnPhase[pipelineStepDef.solverName] =
          this.endTimeOfPhase[pipelineStepDef.solverName] -
          this.startTimeOfPhase[pipelineStepDef.solverName]
        pipelineStepDef.onSolved?.(this)
        this.activeSubSolver = null
        this.currentPipelineStepIndex++
      } else if (this.activeSubSolver.failed) {
        this.error = this.activeSubSolver?.error
        this.failed = true
        this.activeSubSolver = null
      }
      return
    }

    const constructorParams = pipelineStepDef.getConstructorParams(this)
    // @ts-ignore
    this.activeSubSolver = new pipelineStepDef.solverClass(...constructorParams)
    ;(this as any)[pipelineStepDef.solverName] = this.activeSubSolver
    this.timeSpentOnPhase[pipelineStepDef.solverName] = 0
    this.startTimeOfPhase[pipelineStepDef.solverName] = performance.now()
  }

  solveUntilPhase(phase: string) {
    while (this.getCurrentPhase() !== phase) {
      this.step()
    }
  }

  getCurrentPhase(): string {
    return this.pipelineDef[this.currentPipelineStepIndex]?.solverName ?? "none"
  }

  visualize(): GraphicsObject {
    if (!this.solved && this.activeSubSolver)
      return this.activeSubSolver.visualize()
    const netToPPSolver = this.netToPointPairsSolver?.visualize()
    const nodeViz = this.nodeSolver?.visualize()
    const nodeTargetMergerViz = this.nodeTargetMerger?.visualize()
    const singleLayerNodeMergerViz = this.singleLayerNodeMerger?.visualize()
    const strawSolverViz = this.strawSolver?.visualize()
    const edgeViz = this.edgeSolver?.visualize()
    const deadEndViz = this.deadEndSolver?.visualize()
    const availableSegmentPointViz =
      this.availableSegmentPointSolver?.visualize()
    const portPointPathingViz = this.portPointPathingSolver?.visualize()
    const multiSectionOptViz = this.multiSectionPortPointOptimizer?.visualize()
    const uniformPortDistributionViz =
      this.uniformPortDistributionSolver?.visualize()
    const highDensityViz = this.highDensityRouteSolver?.visualize()
    const highDensityStitchViz = this.highDensityStitchSolver?.visualize()
    const traceSimplificationViz = this.traceSimplificationSolver?.visualize()
    const problemOutline = this.srj.outline
    const problemLines: Line[] = []

    problemLines.push({
      points: [
        // Add five points representing the bounds of the PCB
        {
          x: this.srj.bounds?.minX ?? -50,
          y: this.srj.bounds?.minY ?? -50,
        },
        { x: this.srj.bounds?.maxX ?? 50, y: this.srj.bounds?.minY ?? -50 },
        { x: this.srj.bounds?.maxX ?? 50, y: this.srj.bounds?.maxY ?? 50 },
        { x: this.srj.bounds?.minX ?? -50, y: this.srj.bounds?.maxY ?? 50 },
        {
          x: this.srj.bounds?.minX ?? -50,
          y: this.srj.bounds?.minY ?? -50,
        }, // Close the rectangle
      ],
      strokeColor: "rgba(255,0,0,0.25)",
    })

    if (problemOutline && problemOutline.length >= 2) {
      const outlinePoints = problemOutline.map(
        (point: { x: number; y: number }) => ({
          x: point.x,
          y: point.y,
        }),
      )

      outlinePoints.push({ ...outlinePoints[0]! })

      problemLines.push({
        points: outlinePoints,
        strokeColor: "rgba(0, 136, 255, 0.95)",
      })
    }

    const formatObstacleLabel = createObstacleLabelFormatter(this.srj)

    const problemViz = {
      points: [
        ...this.srj.connections.flatMap((c) =>
          c.pointsToConnect.map((p) => ({
            ...p,
            layer: getGraphicsLayerForConnectionPoint(p, this.srj.layerCount),
            label: `${c.name} ${p.pcb_port_id ?? ""}`,
          })),
        ),
      ],
      rects: [
        ...(this.srj.obstacles ?? [])
          .filter((o) => !o.isCopperPour)
          .map((o) => ({
            ...o,
            fill: o.layers?.includes("top")
              ? "rgba(255,0,0,0.25)"
              : o.layers?.includes("bottom")
                ? "rgba(0,0,255,0.25)"
                : "rgba(255,0,0,0.25)",
            layer: getGraphicsLayerForObstacle(o, this.srj.layerCount),
            label: formatObstacleLabel(o),
          })),
      ],
      lines: problemLines,
    } as GraphicsObject
    const visualizations = [
      problemViz,
      netToPPSolver,
      nodeViz,
      nodeTargetMergerViz,
      singleLayerNodeMergerViz,
      strawSolverViz,
      edgeViz,
      deadEndViz,
      availableSegmentPointViz,
      portPointPathingViz,
      multiSectionOptViz,
      uniformPortDistributionViz,
      highDensityViz ? combineVisualizations(problemViz, highDensityViz) : null,
      highDensityStitchViz,
      traceSimplificationViz,
      this.solved
        ? combineVisualizations(
            { lines: problemLines },
            convertSrjToGraphicsObject(this.getOutputSimpleRouteJson()),
          )
        : null,
    ].filter(Boolean) as GraphicsObject[]
    // return visualizations[visualizations.length - 1]
    return combineVisualizations(...visualizations)
  }

  /**
   * A lightweight version of the visualize method that can be used to stream
   * progress
   *
   * We return the most relevant graphic for the stage:
   * 1. netToPointPairs output
   * 2. Capacity Planning Output
   * 3. High Density Route Solver Output, max 200 lines
   */
  preview(): GraphicsObject {
    if (this.highDensityRouteSolver) {
      const lines: Line[] = []
      for (let i = this.highDensityRouteSolver.routes.length - 1; i >= 0; i--) {
        const route = this.highDensityRouteSolver.routes[i]
        lines.push({
          points: route.route.map((n) => ({
            x: n.x,
            y: n.y,
          })),
          strokeColor: this.colorMap[route.connectionName],
        })
        if (lines.length > 200) break
      }
      return { lines }
    }

    if (this.portPointPathingSolver) {
      const lines: Line[] = []
      for (const connection of this.portPointPathingSolver
        .connectionsWithResults) {
        if (!connection.path) continue
        lines.push({
          points: connection.path.map((candidate) => ({
            x: candidate.point.x,
            y: candidate.point.y,
          })),
          strokeColor: this.colorMap[connection.connection.name],
        })
      }
      return { lines }
    }

    // This output is good as-is
    if (this.netToPointPairsSolver) {
      return this.netToPointPairsSolver?.visualize()
    }

    return {}
  }

  _getOutputHdRoutes(): HighDensityRoute[] {
    return (
      this.traceWidthSolver?.getHdRoutesWithWidths() ??
      this.traceSimplificationSolver?.simplifiedHdRoutes ??
      this.highDensityStitchSolver!.mergedHdRoutes
    )
  }

  /**
   * Returns the SimpleRouteJson with routes converted to SimplifiedPcbTraces
   */
  getOutputSimplifiedPcbTraces(): SimplifiedPcbTraces {
    if (!this.solved || !this.highDensityRouteSolver) {
      throw new Error("Cannot get output before solving is complete")
    }

    const traces: SimplifiedPcbTraces = []
    const allHdRoutes = this._getOutputHdRoutes()

    for (const connection of this.netToPointPairsSolver?.newConnections ?? []) {
      const netConnectionName =
        connection.__netConnectionName ??
        this.srj.connections.find((c) => c.name === connection.name)
          ?.__netConnectionName

      // Find all the hdRoutes that correspond to this connection
      const hdRoutes = allHdRoutes.filter(
        (r) => r.connectionName === connection.name,
      )

      for (let i = 0; i < hdRoutes.length; i++) {
        const hdRoute = hdRoutes[i]
        const simplifiedPcbTrace: SimplifiedPcbTrace = {
          type: "pcb_trace",
          pcb_trace_id: `${connection.name}_${i}`,
          connection_name:
            netConnectionName ??
            connection.__rootConnectionNames?.[0] ??
            connection.name,
          route: convertHdRouteToSimplifiedRoute(hdRoute, this.srj.layerCount),
        }

        traces.push(simplifiedPcbTrace)
      }
    }

    return traces
  }

  getOutputSimpleRouteJson(): SimpleRouteJson {
    return {
      ...this.srj,
      traces: this.getOutputSimplifiedPcbTraces(),
    }
  }
}

/** @deprecated Use AutoroutingPipelineSolver instead */
export const CapacityMeshSolver = AutoroutingPipelineSolver2_PortPointPathing
export type CapacityMeshSolver = AutoroutingPipelineSolver2_PortPointPathing
