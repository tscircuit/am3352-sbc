import type { ConnectivityMap } from "circuit-json-to-connectivity-map"
import type { Obstacle, SimpleRouteJson } from "lib/types"
import type { HighDensityRoute } from "lib/types/high-density-types"
import { generateApproximatingRects } from "lib/utils/addApproximatingRectsToSrj"
import { mapZToLayerName } from "lib/utils/mapZToLayerName"
import { minimumDistanceBetweenSegments } from "lib/utils/minimumDistanceBetweenSegments"
import type { PreloadedHighDensityRoute } from "./convertPreloadedTraceToHdRoutes"
import { getPipeline9LayerTransitionViaEndpoint } from "./getPipeline9LayerTransitionViaEndpoint"

export type Pipeline9RouteWireSegment = {
  start: HighDensityRoute["route"][number]
  end: HighDensityRoute["route"][number]
  z: number
  width: number
}

export type Pipeline9RouteViaSpan = {
  center: { x: number; y: number }
  minZ: number
  maxZ: number
  diameter: number
}

export type Pipeline9RouteCopperGeometry = {
  wireSegments: Pipeline9RouteWireSegment[]
  viaSpans: Pipeline9RouteViaSpan[]
}

export type Pipeline9Bounds = {
  minX: number
  maxX: number
  minY: number
  maxY: number
}

export type Pipeline9AxisAlignedRect = {
  center: { x: number; y: number }
  width: number
  height: number
}

const FIXED_WIRE_MAX_APPROXIMATION_LENGTH = 0.75
const routeCopperGeometryCache = new WeakMap<
  HighDensityRoute,
  Map<string, Pipeline9RouteCopperGeometry>
>()

export const getPipeline9RouteCopperGeometry = (
  route: HighDensityRoute,
  {
    layerCount,
    allowBlindAndBuriedVias,
  }: Pick<SimpleRouteJson, "layerCount" | "allowBlindAndBuriedVias">,
): Pipeline9RouteCopperGeometry => {
  const cacheKey = `${layerCount}:${allowBlindAndBuriedVias === true}`
  const cachedGeometry = routeCopperGeometryCache.get(route)?.get(cacheKey)
  if (cachedGeometry) return cachedGeometry
  const wireSegments: Pipeline9RouteWireSegment[] = []
  const viaSpans: Pipeline9RouteViaSpan[] = []
  for (
    let routePointIndex = 1;
    routePointIndex < route.route.length;
    routePointIndex++
  ) {
    const start = route.route[routePointIndex - 1]!
    const end = route.route[routePointIndex]!
    const xyDistance = Math.hypot(end.x - start.x, end.y - start.y)
    const segmentWidth = Math.max(
      start.traceThickness ?? route.traceThickness,
      end.traceThickness ?? route.traceThickness,
    )
    if (start.z !== end.z && start.toNextSegmentType === "through_obstacle") {
      const minZ = Math.min(start.z, end.z)
      const maxZ = Math.max(start.z, end.z)
      if (xyDistance <= 1e-9) {
        const hasExplicitVia = route.vias.some(
          (via) => Math.hypot(via.x - end.x, via.y - end.y) <= 1e-9,
        )
        viaSpans.push({
          center: { x: end.x, y: end.y },
          minZ,
          maxZ,
          diameter: hasExplicitVia ? route.viaDiameter : segmentWidth,
        })
        continue
      }
      for (let z = minZ; z <= maxZ; z++) {
        wireSegments.push({
          start: { ...start, z },
          end: { ...end, z },
          z,
          width: segmentWidth,
        })
      }
      continue
    }
    const viaEndpoint =
      start.z === end.z
        ? undefined
        : getPipeline9LayerTransitionViaEndpoint({ hdRoute: route, start, end })
    const wireZ = viaEndpoint === "start" ? end.z : start.z
    if (xyDistance > 1e-9) {
      wireSegments.push({
        start: start.z === wireZ ? start : { ...start, z: wireZ },
        end: end.z === wireZ ? end : { ...end, z: wireZ },
        z: wireZ,
        width: segmentWidth,
      })
    }
    if (start.z === end.z) continue
    const viaPoint = viaEndpoint === "start" ? start : end
    // Signal endpoints do not limit the drilled copper on a through via.
    // Validate them before expanding the span so invalid layers still fail.
    mapZToLayerName(start.z, layerCount)
    mapZToLayerName(end.z, layerCount)
    viaSpans.push({
      center: { x: viaPoint.x, y: viaPoint.y },
      minZ: allowBlindAndBuriedVias ? Math.min(start.z, end.z) : 0,
      maxZ: allowBlindAndBuriedVias ? Math.max(start.z, end.z) : layerCount - 1,
      diameter: route.viaDiameter,
    })
  }
  const geometry = { wireSegments, viaSpans }
  const geometries = routeCopperGeometryCache.get(route) ?? new Map()
  geometries.set(cacheKey, geometry)
  routeCopperGeometryCache.set(route, geometries)
  return geometry
}

export const getPipeline9AxisAlignedWireApproximations = (
  segment: Pipeline9RouteWireSegment,
  maxApproximationLength: number,
  minimumRectCount: number,
): Pipeline9AxisAlignedRect[] => {
  const dx = segment.end.x - segment.start.x
  const dy = segment.end.y - segment.start.y
  const segmentLength = Math.hypot(dx, dy)
  const center = {
    x: (segment.start.x + segment.end.x) / 2,
    y: (segment.start.y + segment.end.y) / 2,
  }
  if (Math.abs(dx) <= 1e-9 || Math.abs(dy) <= 1e-9) {
    return [
      {
        center,
        width: Math.abs(dx) > Math.abs(dy) ? segmentLength : segment.width,
        height: Math.abs(dx) > Math.abs(dy) ? segment.width : segmentLength,
      },
    ]
  }
  return generateApproximatingRects(
    {
      center,
      width: segmentLength,
      height: segment.width,
      rotation: (Math.atan2(dy, dx) * 180) / Math.PI,
    },
    Math.max(
      minimumRectCount,
      Math.ceil(segmentLength / maxApproximationLength),
    ),
  )
}

export const getPipeline9FixedRouteObstacles = ({
  fixedObstacleRoutes,
  layerCount,
  allowBlindAndBuriedVias,
}: {
  fixedObstacleRoutes: PreloadedHighDensityRoute[]
  layerCount: number
  allowBlindAndBuriedVias?: boolean
}): Obstacle[] => {
  return fixedObstacleRoutes.flatMap((route, routeIndex) => {
    const connectedTo = [route.connectionName, route.rootConnectionName].filter(
      (connectedId): connectedId is string => typeof connectedId === "string",
    )
    const geometry = getPipeline9RouteCopperGeometry(route, {
      layerCount,
      allowBlindAndBuriedVias,
    })
    return [
      ...geometry.wireSegments.flatMap((segment, segmentIndex): Obstacle[] => {
        const approximatingRects = getPipeline9AxisAlignedWireApproximations(
          segment,
          FIXED_WIRE_MAX_APPROXIMATION_LENGTH,
          2,
        )
        return approximatingRects.map((rect, approximationIndex) => ({
          obstacleId: `pipeline9_fixed_obstacle_${routeIndex}_wire_${segmentIndex}_${approximationIndex}`,
          type: "rect",
          layers: [mapZToLayerName(segment.z, layerCount)],
          center: rect.center,
          width: rect.width,
          height: rect.height,
          connectedTo,
        }))
      }),
      ...geometry.viaSpans.map(
        (via, viaIndex): Obstacle => ({
          obstacleId: `pipeline9_fixed_obstacle_${routeIndex}_via_${viaIndex}`,
          type: "rect",
          layers: Array.from(
            { length: via.maxZ - via.minZ + 1 },
            (_, layerOffset) =>
              mapZToLayerName(via.minZ + layerOffset, layerCount),
          ),
          center: via.center,
          width: via.diameter,
          height: via.diameter,
          connectedTo,
        }),
      ),
    ]
  })
}

export const arePipeline9RoutesOnSameNet = (
  left: HighDensityRoute,
  right: HighDensityRoute,
  connMap: ConnectivityMap,
): boolean => {
  const leftIds = [left.connectionName, left.rootConnectionName].filter(
    (id): id is string => typeof id === "string",
  )
  const rightIds = [right.connectionName, right.rootConnectionName].filter(
    (id): id is string => typeof id === "string",
  )
  return leftIds.some((leftId) =>
    rightIds.some(
      (rightId) =>
        leftId === rightId || connMap.areIdsConnected(leftId, rightId),
    ),
  )
}

const boundsOverlap = (
  left: Pipeline9Bounds,
  right: Pipeline9Bounds,
): boolean => {
  return (
    left.minX <= right.maxX &&
    left.maxX >= right.minX &&
    left.minY <= right.maxY &&
    left.maxY >= right.minY
  )
}

const wireSegmentOverlapsBounds = (
  segment: Pipeline9RouteWireSegment,
  bounds: Pipeline9Bounds,
): boolean => {
  const segmentBounds = {
    minX: Math.min(segment.start.x, segment.end.x) - segment.width / 2,
    maxX: Math.max(segment.start.x, segment.end.x) + segment.width / 2,
    minY: Math.min(segment.start.y, segment.end.y) - segment.width / 2,
    maxY: Math.max(segment.start.y, segment.end.y) + segment.width / 2,
  }
  return boundsOverlap(segmentBounds, bounds)
}

const viaSpanOverlapsBounds = (
  via: Pipeline9RouteViaSpan,
  bounds: Pipeline9Bounds,
): boolean => {
  const viaBounds = {
    minX: via.center.x - via.diameter / 2,
    maxX: via.center.x + via.diameter / 2,
    minY: via.center.y - via.diameter / 2,
    maxY: via.center.y + via.diameter / 2,
  }
  return boundsOverlap(viaBounds, bounds)
}

export const doPipeline9RoutesHaveCopperConflict = ({
  left,
  right,
  clearance,
  leftBounds,
  layerCount,
  allowBlindAndBuriedVias,
}: {
  left: HighDensityRoute
  right: HighDensityRoute
  clearance: number
  leftBounds?: Pipeline9Bounds
  layerCount: number
  allowBlindAndBuriedVias?: boolean
}): boolean => {
  const board = { layerCount, allowBlindAndBuriedVias }
  const leftGeometry = getPipeline9RouteCopperGeometry(left, board)
  const rightGeometry = getPipeline9RouteCopperGeometry(right, board)
  const leftWires = leftBounds
    ? leftGeometry.wireSegments.filter((segment) =>
        wireSegmentOverlapsBounds(segment, leftBounds),
      )
    : leftGeometry.wireSegments
  const leftVias = leftBounds
    ? leftGeometry.viaSpans.filter((via) =>
        viaSpanOverlapsBounds(via, leftBounds),
      )
    : leftGeometry.viaSpans
  for (const leftWire of leftWires) {
    for (const rightWire of rightGeometry.wireSegments) {
      if (leftWire.z !== rightWire.z) continue
      const requiredClearance =
        leftWire.width / 2 + rightWire.width / 2 + clearance
      if (
        minimumDistanceBetweenSegments(
          leftWire.start,
          leftWire.end,
          rightWire.start,
          rightWire.end,
        ) < requiredClearance
      ) {
        return true
      }
    }
    for (const rightVia of rightGeometry.viaSpans) {
      if (leftWire.z < rightVia.minZ || leftWire.z > rightVia.maxZ) continue
      const requiredClearance =
        leftWire.width / 2 + rightVia.diameter / 2 + clearance
      if (
        minimumDistanceBetweenSegments(
          leftWire.start,
          leftWire.end,
          rightVia.center,
          rightVia.center,
        ) < requiredClearance
      ) {
        return true
      }
    }
  }
  for (const leftVia of leftVias) {
    for (const rightWire of rightGeometry.wireSegments) {
      if (rightWire.z < leftVia.minZ || rightWire.z > leftVia.maxZ) continue
      const requiredClearance =
        leftVia.diameter / 2 + rightWire.width / 2 + clearance
      if (
        minimumDistanceBetweenSegments(
          leftVia.center,
          leftVia.center,
          rightWire.start,
          rightWire.end,
        ) < requiredClearance
      ) {
        return true
      }
    }
    for (const rightVia of rightGeometry.viaSpans) {
      if (leftVia.minZ > rightVia.maxZ || rightVia.minZ > leftVia.maxZ) continue
      const requiredClearance =
        leftVia.diameter / 2 + rightVia.diameter / 2 + clearance
      if (
        Math.hypot(
          leftVia.center.x - rightVia.center.x,
          leftVia.center.y - rightVia.center.y,
        ) < requiredClearance
      ) {
        return true
      }
    }
  }
  return false
}
