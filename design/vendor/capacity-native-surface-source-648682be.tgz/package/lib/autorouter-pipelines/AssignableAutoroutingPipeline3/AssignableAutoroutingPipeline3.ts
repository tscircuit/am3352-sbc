import { RectDiffPipeline } from "@tscircuit/rectdiff"
import { ConnectivityMap } from "circuit-json-to-connectivity-map"
import type { GraphicsObject, Line } from "graphics-debug"
import { getGlobalInMemoryCache } from "lib/cache/setupGlobalCaches"
import { CacheProvider } from "lib/cache/types"
import {
  HyperPortPointPathingSolver,
  HyperPortPointPathingSolverParams,
} from "lib/solvers/PortPointPathingSolver/HyperPortPointPathingSolver"
import { TraceKeepoutSolver } from "lib/solvers/TraceKeepoutSolver/TraceKeepoutSolver"
import {
  HighDensityIntraNodeRoute,
  HighDensityRoute,
} from "lib/types/high-density-types"
import { convertHdRouteToSimplifiedRoute } from "lib/utils/convertHdRouteToSimplifiedRoute"
import { convertSrjToGraphicsObject } from "lib/utils/convertSrjToGraphicsObject"
import { createObstacleLabelFormatter } from "lib/utils/formatObstacleLabel"
import {
  getGraphicsLayerForConnectionPoint,
  getGraphicsLayerForObstacle,
} from "lib/utils/getGraphicsObjectLayer"
import { getConnectivityMapFromSimpleRouteJson } from "lib/utils/getConnectivityMapFromSimpleRouteJson"
import { getInitiallyConnectedMapFromSimpleRouteJson } from "lib/utils/get-initially-connected-map-from-simple-route-json"
import { getViaDimensions } from "lib/utils/getViaDimensions"
import { AvailableSegmentPointSolver } from "../../solvers/AvailableSegmentPointSolver/AvailableSegmentPointSolver"
import { BaseSolver } from "../../solvers/BaseSolver"
import { CapacityMeshEdgeSolver } from "../../solvers/CapacityMeshSolver/CapacityMeshEdgeSolver"
import { CapacityMeshEdgeSolver2_NodeTreeOptimization } from "../../solvers/CapacityMeshSolver/CapacityMeshEdgeSolver2_NodeTreeOptimization"
import { CapacityMeshNodeSolver2_NodeUnderObstacle } from "../../solvers/CapacityMeshSolver/CapacityMeshNodeSolver2_NodesUnderObstacles"
import { CapacityNodeTargetMerger } from "../../solvers/CapacityNodeTargetMerger/CapacityNodeTargetMerger"
import { DeadEndSolver } from "../../solvers/DeadEndSolver/DeadEndSolver"
import { HighDensitySolver as LegacyHighDensitySolver } from "../../solvers/HighDensitySolver/HighDensitySolver"
import {
  MultiSectionPortPointOptimizer,
  MultiSectionPortPointOptimizerParams,
} from "../../solvers/MultiSectionPortPointOptimizer"
import { NetToPointPairsSolver } from "../../solvers/NetToPointPairsSolver/NetToPointPairsSolver"
import { NetToPointPairsSolver2_OffBoardConnection } from "../../solvers/NetToPointPairsSolver2_OffBoardConnection/NetToPointPairsSolver2_OffBoardConnection"
import {
  InputNodeWithPortPoints,
  InputPortPoint,
  PortPointPathingSolver,
} from "../../solvers/PortPointPathingSolver/PortPointPathingSolver"
import { MultipleHighDensityRouteStitchSolver } from "../../solvers/RouteStitchingSolver/MultipleHighDensityRouteStitchSolver"
import { MultipleHighDensityRouteStitchSolver2 } from "../../solvers/RouteStitchingSolver/MultipleHighDensityRouteStitchSolver2"
import { SingleLayerNodeMergerSolver } from "../../solvers/SingleLayerNodeMerger/SingleLayerNodeMergerSolver"
import { StrawSolver } from "../../solvers/StrawSolver/StrawSolver"
import { TraceSimplificationSolver } from "@tscircuit/trace-simplification-solver"
import { TraceWidthSolver } from "../../solvers/TraceWidthSolver/TraceWidthSolver"
import { getColorMap } from "../../solvers/colors"
import type {
  CapacityMeshEdge,
  CapacityMeshNode,
  Obstacle,
  ObstacleId,
  RootConnectionName,
  SimpleRouteJson,
  SimplifiedPcbTrace,
  SimplifiedPcbTraces,
  Jumper as SrjJumper,
  TraceId,
} from "../../types"
import { Jumper as HdJumper } from "../../types/high-density-types"
import { combineVisualizations } from "../../utils/combineVisualizations"
import { calculateOptimalCapacityDepth } from "../../utils/getTunedTotalCapacity1"
import { JUMPER_DIMENSIONS } from "../../utils/jumperSizes"
import { JumperHighDensitySolver } from "../AssignableAutoroutingPipeline2/JumperHighDensitySolver"
import { PortPointOffboardPathFragmentSolver } from "../AssignableAutoroutingPipeline2/PortPointOffboardPathFragmentSolver"
import { RelateNodesToOffBoardConnectionsSolver } from "../AssignableAutoroutingPipeline2/RelateNodesToOffBoardConnectionsSolver"
import { SimpleHighDensitySolver } from "../AssignableAutoroutingPipeline2/SimpleHighDensitySolver"
import { updateConnMapWithOffboardObstacleConnections } from "../AssignableAutoroutingPipeline2/updateConnMapWithOffboardObstacleConnections"

interface CapacityMeshSolverOptions {
  capacityDepth?: number
  targetMinCapacity?: number
  cacheProvider?: CacheProvider | null
  effort?: number
}
export type AutoroutingPipelineSolverOptions = CapacityMeshSolverOptions

type PipelineStep<T extends new (...args: any[]) => BaseSolver> = {
  solverName: string
  solverClass: T
  getConstructorParams: (
    instance: AssignableAutoroutingPipeline3,
  ) => ConstructorParameters<T>
  onSolved?: (instance: AssignableAutoroutingPipeline3) => void
}

function definePipelineStep<
  T extends new (
    ...args: any[]
  ) => BaseSolver,
  const P extends ConstructorParameters<T>,
>(
  solverName: keyof AssignableAutoroutingPipeline3,
  solverClass: T,
  getConstructorParams: (instance: AssignableAutoroutingPipeline3) => P,
  opts: {
    onSolved?: (instance: AssignableAutoroutingPipeline3) => void
  } = {},
): PipelineStep<T> {
  return {
    solverName,
    solverClass,
    getConstructorParams,
    onSolved: opts.onSolved,
  }
}

export class AssignableAutoroutingPipeline3 extends BaseSolver {
  override getSolverName(): string {
    return "AssignableAutoroutingPipeline3"
  }

  netToPointPairsSolver?: NetToPointPairsSolver
  // nodeSolver?: CapacityMeshNodeSolver2_NodeUnderObstacle
  traceKeepoutSolver?: TraceKeepoutSolver
  nodeSolver?: RectDiffPipeline
  nodeTargetMerger?: CapacityNodeTargetMerger
  edgeSolver?: CapacityMeshEdgeSolver
  relateNodesToOffBoardConnections?: RelateNodesToOffBoardConnectionsSolver
  colorMap: Record<string, string>
  highDensityRouteSolver?: LegacyHighDensitySolver
  /** @deprecated Use highDensitySolver instead */
  simpleHighDensityRouteSolver?: SimpleHighDensitySolver
  highDensitySolver?: JumperHighDensitySolver
  highDensityStitchSolver?: MultipleHighDensityRouteStitchSolver2
  singleLayerNodeMerger?: SingleLayerNodeMergerSolver
  offboardPathFragmentSolver?: PortPointOffboardPathFragmentSolver
  strawSolver?: StrawSolver
  deadEndSolver?: DeadEndSolver
  traceSimplificationSolver?: TraceSimplificationSolver
  traceWidthSolver?: TraceWidthSolver
  availableSegmentPointSolver?: AvailableSegmentPointSolver
  portPointPathingSolver?: PortPointPathingSolver
  multiSectionPortPointOptimizer?: MultiSectionPortPointOptimizer
  viaDiameter: number
  minTraceWidth: number
  effort: number

  startTimeOfPhase: Record<string, number>
  endTimeOfPhase: Record<string, number>
  timeSpentOnPhase: Record<string, number>

  activeSubSolver?: BaseSolver | null = null
  connMap: ConnectivityMap
  srjWithPointPairs?: SimpleRouteJson
  capacityNodes: CapacityMeshNode[] | null = null
  capacityEdges: CapacityMeshEdge[] | null = null

  cacheProvider: CacheProvider | null = null

  pipelineDef = [
    definePipelineStep(
      "netToPointPairsSolver",
      NetToPointPairsSolver,
      (cms) => [
        cms.srj,
        cms.colorMap,
        getInitiallyConnectedMapFromSimpleRouteJson(cms.srj),
      ],
      {
        onSolved: (cms) => {
          cms.srjWithPointPairs =
            cms.netToPointPairsSolver?.getNewSimpleRouteJson()
          cms.colorMap = getColorMap(cms.srjWithPointPairs!, this.connMap)
          cms.connMap = getConnectivityMapFromSimpleRouteJson(
            cms.srjWithPointPairs!,
          )
        },
      },
    ),
    definePipelineStep(
      "nodeSolver",
      RectDiffPipeline,
      // Cast to any because RectDiffSolver uses an older SimpleRouteJson type
      // that doesn't support MultiLayerConnectionPoint yet
      (cms) => [
        { simpleRouteJson: cms.srjWithPointPairs! as any, maxGapFillPasses: 4 },
      ],
      {
        onSolved: (cms) => {
          cms.capacityNodes = cms.nodeSolver?.getOutput().meshNodes ?? []
        },
      },
    ),
    definePipelineStep(
      "relateNodesToOffBoardConnections",
      RelateNodesToOffBoardConnectionsSolver,
      (cms) => [
        {
          capacityMeshNodes: cms.capacityNodes!,
          srj: cms.srj,
        },
      ],
      {
        onSolved: (cms) => {
          cms.capacityNodes =
            cms.relateNodesToOffBoardConnections?.getOutput().capacityNodes!
        },
      },
    ),
    definePipelineStep(
      "edgeSolver",
      CapacityMeshEdgeSolver2_NodeTreeOptimization,
      (cms) => [cms.capacityNodes!],
      {
        onSolved: (cms) => {
          cms.capacityEdges = cms.edgeSolver?.edges!
        },
      },
    ),
    definePipelineStep(
      "availableSegmentPointSolver",
      AvailableSegmentPointSolver,
      (cms) => [
        {
          nodes: cms.capacityNodes!,
          edges: cms.capacityEdges || [],
          traceWidth: cms.minTraceWidth,
          colorMap: cms.colorMap,
          shouldReturnCrampedPortPoints: false,
        },
      ],
    ),
    definePipelineStep(
      "portPointPathingSolver",
      HyperPortPointPathingSolver,
      (cms) => {
        // Convert capacity nodes and segment points to InputNodeWithPortPoints
        const inputNodes: InputNodeWithPortPoints[] = cms.capacityNodes!.map(
          (node) => ({
            capacityMeshNodeId: node.capacityMeshNodeId,
            center: node.center,
            width: node.width,
            height: node.height,
            portPoints: [] as InputPortPoint[],
            availableZ: node.availableZ,
            _containsTarget: node._containsTarget,
            _containsObstacle: node._containsObstacle,
            _offBoardConnectionId: node._offBoardConnectionId,
            _offBoardConnectedCapacityMeshNodeIds:
              node._offBoardConnectedCapacityMeshNodeIds,
          }),
        )

        // Build a map for quick lookup
        const nodeMap = new Map(
          inputNodes.map((n) => [n.capacityMeshNodeId, n]),
        )

        // Add port points from the available segment point solver
        const segmentPointSolver = cms.availableSegmentPointSolver!
        for (const segment of segmentPointSolver.sharedEdgeSegments) {
          for (const segmentPortPoint of segment.portPoints) {
            const [nodeId1, nodeId2] = segmentPortPoint.nodeIds
            const inputPortPoint: InputPortPoint = {
              portPointId: segmentPortPoint.segmentPortPointId,
              x: segmentPortPoint.x,
              y: segmentPortPoint.y,
              z: segmentPortPoint.availableZ[0] ?? 0,
              connectionNodeIds: [nodeId1, nodeId2],
              distToCentermostPortOnZ: segmentPortPoint.distToCentermostPortOnZ,
              connectsToOffBoardNode: segment.nodeIds.some(
                (n) => nodeMap.get(n)?._offBoardConnectionId,
              ),
            }

            // Add to first node
            const node1 = nodeMap.get(nodeId1)
            if (node1) {
              node1.portPoints.push(inputPortPoint)
            }
            // Note: Don't add to second node - the solver will handle the shared edge
          }
        }

        return [
          {
            simpleRouteJson: cms.srjWithPointPairs!,
            inputNodes,
            capacityMeshNodes: cms.capacityNodes!,
            colorMap: cms.colorMap,
            numShuffleSeeds: 10 * Math.min(1, cms.effort),
            // minAllowedBoardScore: -1,
            hyperParameters: {
              // 1 = 60% maximum pf (see computeSectionScore)
              // 5 = 99.3% maximum pf
              // 10 = 99.995% maximum pf (1 - e**(-10))
              // NODE_PF_MAX_PENALTY: 10,
              // RANDOM_WALK_DISTANCE: 50,
              // SHUFFLE_SEED: 275,
              JUMPER_PF_FN_ENABLED: true,
              NODE_PF_FACTOR: 100,
              MAX_RIPS: 100 * Math.min(1, cms.effort),
              RIPPING_ENABLED: true,
              MAX_RIPPING_PF_THRESHOLD: 0.9,
              MIN_RIPPING_PF_THRESHOLD: 0.1,
              RANDOM_RIP_FRACTION: 0.05,
              NODE_PF_MAX_PENALTY: 1000,
              STRAIGHT_LINE_DEVIATION_PENALTY_FACTOR: 0,
              // MIN_ALLOWED_BOARD_SCORE: -1,
              // FORCE_OFF_BOARD_FREQUENCY: 0, // 0.3,
              CENTER_OFFSET_DIST_PENALTY_FACTOR: 0,
              FORCE_CENTER_FIRST: true,
            },
          } as HyperPortPointPathingSolverParams,
        ]
      },
      {
        onSolved: (cms) => {
          const solver = cms.portPointPathingSolver
          if (!solver) return
          updateConnMapWithOffboardObstacleConnections({
            connMap: cms.connMap,
            connectionsWithResults: solver.connectionsWithResults,
            inputNodes: solver.inputNodes,
            obstacles: cms.srj.obstacles,
          })
        },
      },
    ),
    // definePipelineStep(
    //   "multiSectionPortPointOptimizer",
    //   MultiSectionPortPointOptimizer,
    //   (cms) => {
    //     const portPointSolver = cms.portPointPathingSolver!
    //     return [
    //       {
    //         simpleRouteJson: cms.srjWithPointPairs!,
    //         inputNodes: portPointSolver.inputNodes,
    //         capacityMeshNodes: cms.capacityNodes!,
    //         capacityMeshEdges: cms.capacityEdges!,
    //         colorMap: cms.colorMap,
    //         initialConnectionResults: portPointSolver.connectionsWithResults,
    //         initialAssignedPortPoints: portPointSolver.assignedPortPoints,
    //         initialNodeAssignedPortPoints:
    //           portPointSolver.nodeAssignedPortPoints,
    //         ALWAYS_RIP_INTERSECTIONS: true,
    //         FRACTION_TO_REPLACE: 0.1,
    //         MAX_ATTEMPTS_PER_NODE: 3 * this.effort,
    //         MAX_SECTION_ATTEMPTS: 30 * this.effort,
    //         JUMPER_PF_FN_ENABLED: true,
    //         SHUFFLE_SEEDS_PER_SECTION: 1,
    //         HYPERPARAMETER_SCHEDULE: [
    //           {
    //             ...this.portPointPathingSolver?.hyperParameters,
    //             EXPANSION_DEGREES: 10,
    //             MAX_RIPS: 10 * cms.effort,
    //             RANDOM_RIP_FRACTION: 0.1,
    //             RIPPING_PF_THRESHOLD: 0.9,
    //             STRAIGHT_LINE_DEVIATION_PENALTY_FACTOR: 0,
    //           },
    //         ],
    //       } as MultiSectionPortPointOptimizerParams,
    //     ]
    //   },
    // ),
    // definePipelineStep("highDensitySolver", SimpleHighDensitySolver, (cms) => [
    //   {
    //     nodePortPoints:
    //       cms.multiSectionPortPointOptimizer?.getNodesWithPortPoints() ??
    //       cms.portPointPathingSolver?.getNodesWithPortPoints() ??
    //       [],
    //     colorMap: cms.colorMap,
    //     viaDiameter: cms.viaDiameter,
    //     traceWidth: cms.minTraceWidth,
    //     connMap: cms.connMap,
    //   },
    // ]),
    definePipelineStep("highDensitySolver", JumperHighDensitySolver, (cms) => [
      {
        nodePortPoints:
          cms.multiSectionPortPointOptimizer?.getNodesWithPortPoints() ??
          cms.portPointPathingSolver?.getNodesWithPortPoints() ??
          [],
        colorMap: cms.colorMap,
        viaDiameter: cms.viaDiameter,
        traceWidth: cms.minTraceWidth,
        obstacleMargin: cms.srj.defaultObstacleMargin ?? 0.15,
        connMap: cms.connMap,
        capacityMeshNodes: cms.capacityNodes ?? [],
        capacityMeshEdges: cms.capacityEdges ?? [],
        availableJumperTypes: cms.srj.availableJumperTypes,
      },
    ]),
    definePipelineStep(
      "highDensityStitchSolver",
      MultipleHighDensityRouteStitchSolver2,
      (cms) => [
        {
          connections: cms.srjWithPointPairs!.connections,
          hdRoutes: cms.highDensitySolver!.routes,
          connectionPathResults:
            cms.multiSectionPortPointOptimizer?.connectionResults ??
            cms.portPointPathingSolver?.connectionsWithResults ??
            [],
          colorMap: cms.colorMap,
          layerCount: cms.srj.layerCount,
          defaultViaDiameter: cms.viaDiameter,
        },
      ],
    ),
    // definePipelineStep(
    //   "traceSimplificationSolver",
    //   TraceSimplificationSolver,
    //   (cms) => [
    //     {
    //       hdRoutes:
    //         cms.highDensityStitchSolver?.mergedHdRoutes ??
    //         cms.highDensitySolver?.routes ??
    //         cms.highDensityRouteSolver?.routes!,
    //       obstacles: cms.srj.obstacles,
    //       connMap: cms.connMap,
    //       colorMap: cms.colorMap,
    //       outline: cms.srj.outline,
    //       defaultViaDiameter: cms.viaDiameter,
    //       layerCount: cms.srj.layerCount,
    //       iterations: 2,
    //     },
    //   ],
    // ),
    definePipelineStep("traceKeepoutSolver", TraceKeepoutSolver, (cms) => [
      {
        hdRoutes:
          cms.traceSimplificationSolver?.simplifiedHdRoutes ??
          cms.highDensityStitchSolver?.mergedHdRoutes ??
          [],
        obstacles: cms.srj.obstacles,
        jumpers: cms.highDensitySolver?.getOutputJumpers() ?? [],
        connMap: cms.connMap,
        colorMap: cms.colorMap,
        srj: cms.srj,
      },
    ]),
    // definePipelineStep("traceWidthSolver", TraceWidthSolver, (cms) => [
    //   {
    //     hdRoutes:
    //       cms.traceSimplificationSolver?.simplifiedHdRoutes ??
    //       cms?.highDensityStitchSolver?.mergedHdRoutes ??
    //       [],
    //     obstacles: [
    //       ...cms.srj.obstacles,
    //       ...(cms.highDensitySolver?.getOutputJumpers() ?? []).flatMap(
    //         (jumper) => jumper.pads,
    //       ),
    //     ] as Obstacle[],
    //     connMap: cms.connMap,
    //     colorMap: cms.colorMap,
    //     nominalTraceWidth: cms.srj.nominalTraceWidth,
    //     minTraceWidth: cms.minTraceWidth,
    //     obstacleMargin: cms.srj.defaultObstacleMargin ?? 0.15,
    //   },
    // ]),
  ]

  constructor(
    public readonly srj: SimpleRouteJson,
    public readonly opts: CapacityMeshSolverOptions = {},
  ) {
    super()
    this.srj = srj
    this.opts = { ...opts }
    this.viaDiameter = getViaDimensions(srj).padDiameter
    this.minTraceWidth = srj.minTraceWidth
    const mutableOpts = this.opts
    this.effort = mutableOpts.effort ?? 1
    // scale with effort so the outer cap never decapitates inner solvers
    this.MAX_ITERATIONS = 100e6 * this.effort

    // If capacityDepth is not provided, calculate it automatically
    if (mutableOpts.capacityDepth === undefined) {
      // Calculate max width/height from bounds for initial node size
      const boundsWidth = srj.bounds.maxX - srj.bounds.minX
      const boundsHeight = srj.bounds.maxY - srj.bounds.minY
      const maxWidthHeight = Math.max(boundsWidth, boundsHeight)

      // Use the calculateOptimalCapacityDepth function to determine the right depth
      const targetMinCapacity = mutableOpts.targetMinCapacity ?? 0.5
      mutableOpts.capacityDepth = calculateOptimalCapacityDepth(
        maxWidthHeight,
        targetMinCapacity,
      )
    }

    this.connMap = getConnectivityMapFromSimpleRouteJson(srj)
    this.colorMap = getColorMap(srj, this.connMap)
    this.cacheProvider =
      mutableOpts.cacheProvider === undefined
        ? getGlobalInMemoryCache()
        : mutableOpts.cacheProvider === null
          ? null
          : mutableOpts.cacheProvider
    this.startTimeOfPhase = {}
    this.endTimeOfPhase = {}
    this.timeSpentOnPhase = {}
  }

  getConstructorParams() {
    return [this.srj, this.opts] as const
  }

  currentPipelineStepIndex = 0
  _step() {
    const pipelineStepDef = this.pipelineDef[this.currentPipelineStepIndex]
    if (!pipelineStepDef) {
      this.solved = true
      return
    }

    if (this.activeSubSolver) {
      this.activeSubSolver.step()
      if (this.activeSubSolver.solved) {
        this.endTimeOfPhase[pipelineStepDef.solverName] = performance.now()
        this.timeSpentOnPhase[pipelineStepDef.solverName] =
          this.endTimeOfPhase[pipelineStepDef.solverName] -
          this.startTimeOfPhase[pipelineStepDef.solverName]
        pipelineStepDef.onSolved?.(this)
        this.activeSubSolver = null
        this.currentPipelineStepIndex++
      } else if (this.activeSubSolver.failed) {
        this.error = this.activeSubSolver?.error
        this.failed = true
        this.activeSubSolver = null
      }
      return
    }

    const constructorParams = pipelineStepDef.getConstructorParams(this)
    // @ts-ignore
    this.activeSubSolver = new pipelineStepDef.solverClass(...constructorParams)
    ;(this as any)[pipelineStepDef.solverName] = this.activeSubSolver
    this.timeSpentOnPhase[pipelineStepDef.solverName] = 0
    this.startTimeOfPhase[pipelineStepDef.solverName] = performance.now()
  }

  solveUntilPhase(phase: string) {
    while (this.getCurrentPhase() !== phase) {
      this.step()
    }
  }

  getCurrentPhase(): string {
    return this.pipelineDef[this.currentPipelineStepIndex]?.solverName ?? "none"
  }

  visualize(): GraphicsObject {
    if (!this.solved && this.activeSubSolver)
      return this.activeSubSolver.visualize()
    const netToPPSolver = this.netToPointPairsSolver?.visualize()
    const nodeViz = this.nodeSolver?.visualize()
    const nodeTargetMergerViz = this.nodeTargetMerger?.visualize()
    const singleLayerNodeMergerViz = this.singleLayerNodeMerger?.visualize()
    const strawSolverViz = this.strawSolver?.visualize()
    const edgeViz = this.edgeSolver?.visualize()
    const traceKeepoutViz = this.traceKeepoutSolver?.visualize()
    const deadEndViz = this.deadEndSolver?.visualize()
    const availableSegmentPointViz =
      this.availableSegmentPointSolver?.visualize()
    const offboardPathFragmentViz = this.offboardPathFragmentSolver?.visualize()
    const portPointPathingViz = this.portPointPathingSolver?.visualize()
    const multiSectionOptViz = this.multiSectionPortPointOptimizer?.visualize()
    const highDensityViz = this.highDensityRouteSolver?.visualize()
    const newHighDensityViz = this.highDensitySolver?.visualize()
    const simpleHighDensityViz = this.simpleHighDensityRouteSolver?.visualize()
    const highDensityStitchViz = this.highDensityStitchSolver?.visualize()
    const traceSimplificationViz = this.traceSimplificationSolver?.visualize()
    const traceWidthViz = this.traceWidthSolver?.visualize()
    const problemOutline = this.srj.outline
    const problemLines: Line[] = []

    problemLines.push({
      points: [
        // Add five points representing the bounds of the PCB
        {
          x: this.srj.bounds?.minX ?? -50,
          y: this.srj.bounds?.minY ?? -50,
        },
        { x: this.srj.bounds?.maxX ?? 50, y: this.srj.bounds?.minY ?? -50 },
        { x: this.srj.bounds?.maxX ?? 50, y: this.srj.bounds?.maxY ?? 50 },
        { x: this.srj.bounds?.minX ?? -50, y: this.srj.bounds?.maxY ?? 50 },
        {
          x: this.srj.bounds?.minX ?? -50,
          y: this.srj.bounds?.minY ?? -50,
        }, // Close the rectangle
      ],
      strokeColor: "rgba(255,0,0,0.25)",
    })

    if (problemOutline && problemOutline.length >= 2) {
      const outlinePoints = problemOutline.map(
        (point: { x: number; y: number }) => ({
          x: point.x,
          y: point.y,
        }),
      )

      outlinePoints.push({ ...outlinePoints[0]! })

      problemLines.push({
        points: outlinePoints,
        strokeColor: "rgba(0, 136, 255, 0.95)",
      })
    }

    const formatObstacleLabel = createObstacleLabelFormatter(this.srj)

    const problemViz = {
      points: [
        ...this.srj.connections.flatMap((c) =>
          c.pointsToConnect.map((p) => ({
            ...p,
            layer: getGraphicsLayerForConnectionPoint(p, this.srj.layerCount),
            label: `${c.name} ${p.pcb_port_id ?? ""}`,
          })),
        ),
      ],
      rects: [
        ...(this.srj.obstacles ?? [])
          .filter((o) => !o.isCopperPour)
          .map((o) => ({
            ...o,
            fill: o.layers?.includes("top")
              ? "rgba(255,0,0,0.25)"
              : o.layers?.includes("bottom")
                ? "rgba(0,0,255,0.25)"
                : "rgba(255,0,0,0.25)",
            layer: getGraphicsLayerForObstacle(o, this.srj.layerCount),
            label: formatObstacleLabel(o),
          })),
      ],
      lines: problemLines,
    } as GraphicsObject
    const visualizations = [
      problemViz,
      netToPPSolver,
      nodeViz,
      nodeTargetMergerViz,
      singleLayerNodeMergerViz,
      strawSolverViz,
      edgeViz,
      deadEndViz,
      availableSegmentPointViz,
      offboardPathFragmentViz,
      portPointPathingViz,
      multiSectionOptViz,
      highDensityViz ? combineVisualizations(problemViz, highDensityViz) : null,
      newHighDensityViz
        ? combineVisualizations(problemViz, newHighDensityViz)
        : null,
      simpleHighDensityViz
        ? combineVisualizations(problemViz, simpleHighDensityViz)
        : null,
      highDensityStitchViz,
      traceSimplificationViz,
      traceKeepoutViz,
      traceWidthViz,
      this.solved
        ? combineVisualizations(
            { lines: problemLines },
            convertSrjToGraphicsObject(this.getOutputSimpleRouteJson()),
          )
        : null,
    ].filter(Boolean) as GraphicsObject[]
    // return visualizations[visualizations.length - 1]
    return combineVisualizations(...visualizations)
  }

  /**
   * A lightweight version of the visualize method that can be used to stream
   * progress
   *
   * We return the most relevant graphic for the stage:
   * 1. netToPointPairs output
   * 2. Capacity Planning Output
   * 3. High Density Route Solver Output, max 200 lines
   */
  preview(): GraphicsObject {
    const hdRoutes =
      this.highDensitySolver?.routes ??
      this.simpleHighDensityRouteSolver?.routes ??
      this.highDensityRouteSolver?.routes
    if (hdRoutes) {
      const lines: Line[] = []
      for (let i = hdRoutes.length - 1; i >= 0; i--) {
        const route = hdRoutes[i]
        lines.push({
          points: route.route.map((n) => ({
            x: n.x,
            y: n.y,
          })),
          strokeColor: this.colorMap[route.connectionName],
        })
        if (lines.length > 200) break
      }
      return { lines }
    }

    if (this.portPointPathingSolver) {
      const lines: Line[] = []
      for (const connection of this.portPointPathingSolver
        .connectionsWithResults) {
        if (!connection.path) continue
        lines.push({
          points: connection.path.map((candidate) => ({
            x: candidate.point.x,
            y: candidate.point.y,
          })),
          strokeColor: this.colorMap[connection.connection.name],
        })
      }
      return { lines }
    }

    // This output is good as-is
    if (this.netToPointPairsSolver) {
      return this.netToPointPairsSolver?.visualize()
    }

    return {}
  }

  _getOutputHdRoutes(): HighDensityRoute[] {
    return (
      this.traceWidthSolver?.hdRoutesWithWidths ??
      this.traceKeepoutSolver?.redrawnHdRoutes ??
      this.traceSimplificationSolver?.simplifiedHdRoutes ??
      this.highDensityStitchSolver?.mergedHdRoutes ??
      this.highDensitySolver?.routes ??
      this.simpleHighDensityRouteSolver?.routes ??
      this.highDensityRouteSolver?.routes!
    )
  }

  getConnectedOffboardObstacles(): Record<ObstacleId, RootConnectionName> {
    const connectedOffboardObstacles: Record<ObstacleId, RootConnectionName> =
      {}
    const rootConnectionNames = new Set(
      this.srj.connections.flatMap(
        (connection) => connection.__rootConnectionNames ?? [connection.name],
      ),
    )

    for (const [index, obstacle] of this.srj.obstacles.entries()) {
      if (!obstacle.offBoardConnectsTo?.length) continue
      const obstacleId = obstacle.obstacleId ?? `__obs${index}`
      obstacle.obstacleId = obstacleId

      const netId = this.connMap.getNetConnectedToId(obstacleId)
      if (!netId) continue

      const connectedIds = this.connMap.getIdsConnectedToNet(netId)
      const rootConnectionName = connectedIds.find((id) =>
        rootConnectionNames.has(id),
      )
      if (!rootConnectionName) continue

      connectedOffboardObstacles[obstacleId] = rootConnectionName
    }

    return connectedOffboardObstacles
  }

  /**
   * Returns the SimpleRouteJson with routes converted to SimplifiedPcbTraces
   */
  getOutputSimplifiedPcbTraces(): SimplifiedPcbTraces {
    if (
      !this.solved ||
      (!this.highDensityRouteSolver &&
        !this.simpleHighDensityRouteSolver &&
        !this.highDensitySolver)
    ) {
      throw new Error("Cannot get output before solving is complete")
    }

    const traces: SimplifiedPcbTraces = []
    const allHdRoutes = this._getOutputHdRoutes()

    for (const connection of this.netToPointPairsSolver?.newConnections ?? []) {
      const netConnectionName =
        connection.__netConnectionName ??
        this.srj.connections.find((c) => c.name === connection.name)
          ?.__netConnectionName

      // Find all the hdRoutes that correspond to this connection
      const hdRoutes = allHdRoutes.filter(
        (r) => r.connectionName === connection.name,
      )

      for (let i = 0; i < hdRoutes.length; i++) {
        const hdRoute = hdRoutes[i]
        const simplifiedPcbTrace: SimplifiedPcbTrace = {
          type: "pcb_trace",
          pcb_trace_id: `${connection.name}_${i}`,
          connection_name:
            netConnectionName ??
            connection.__rootConnectionNames?.[0] ??
            connection.name,
          route: convertHdRouteToSimplifiedRoute(hdRoute, this.srj.layerCount),
        }

        traces.push(simplifiedPcbTrace)
      }
    }

    return traces
  }

  /**
   * Collects ALL jumpers from the highDensitySolver and converts them to SRJ Jumper format.
   * This returns all jumpers placed in the jumper grid (from baseGraph.jumperLocations),
   * not just the ones used by routes. These will be used as obstacles for the keepout
   * solver and added to the final SRJ output.
   */
  getOutputJumpers(): SrjJumper[] {
    if (!this.highDensitySolver) {
      return []
    }
    return this.highDensitySolver.getOutputJumpers()
  }

  getOutputSimpleRouteJson(): SimpleRouteJson {
    const jumpers = this.getOutputJumpers()
    return {
      ...this.srj,
      traces: this.getOutputSimplifiedPcbTraces(),
      jumpers: jumpers.length > 0 ? jumpers : undefined,
    }
  }
}
