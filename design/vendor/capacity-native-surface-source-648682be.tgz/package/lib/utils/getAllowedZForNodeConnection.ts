import type { NodeWithPortPoints } from "lib/types/high-density-types"

/** Resolve a node-local wire domain without compacting native layer indexes. */
export function getAllowedZForNodeConnection(
  node: NodeWithPortPoints,
  connectionName: string,
  rootConnectionName?: string,
): number[] {
  const nodeZ = node.availableZ ?? [...new Set(node.portPoints.map((point) => point.z))]
  if (node.allowedZByConnectionName === undefined) return [...nodeZ].sort((a, b) => a - b)
  const connectionZ = node.allowedZByConnectionName[connectionName] ??
    (rootConnectionName === undefined ? undefined : node.allowedZByConnectionName[rootConnectionName])
  if (connectionZ === undefined) throw new Error(`Missing wire-layer domain for node connection "${connectionName}"`)
  const allowedZ = nodeZ.filter((z) => connectionZ.includes(z))
  if (allowedZ.length === 0) throw new Error(`Node connection "${connectionName}" has no legal wire layer`)
  return [...new Set(allowedZ)].sort((a, b) => a - b)
}
