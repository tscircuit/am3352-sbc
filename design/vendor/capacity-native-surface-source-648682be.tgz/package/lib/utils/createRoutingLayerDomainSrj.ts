import type { SimpleRouteConnection, SimpleRouteJson } from "lib/types"

/** Keep native ownership declarations even when routing drops satisfied nets. */
export function createRoutingLayerDomainSrj(
  originalSrj: SimpleRouteJson,
  routingConnections: readonly SimpleRouteConnection[],
): SimpleRouteJson {
  return {
    ...originalSrj,
    connections: [
      ...originalSrj.connections,
      ...routingConnections.map((connection): SimpleRouteConnection => ({
        ...connection,
        // Derived aliases and narrowed domains are useful; derived terminal
        // coordinates must not grant ownership of native copper geometry.
        pointsToConnect: [],
      })),
    ],
  }
}
