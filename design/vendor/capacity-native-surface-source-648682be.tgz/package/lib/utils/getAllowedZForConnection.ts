import type { Obstacle, SimpleRouteConnection, SimpleRouteJson } from "lib/types"
import { getConnectivityMapFromSimpleRouteJson } from "./getConnectivityMapFromSimpleRouteJson"
import { mapLayerNameToZ } from "./mapLayerNameToZ"
import { mapZToLayerName } from "./mapZToLayerName"

type Point = { x: number; y: number }

function getConnectionNames(connection: SimpleRouteConnection): string[] {
  return [...new Set([
    connection.name, connection.rootConnectionName, connection.source_trace_id,
    connection.netConnectionName, connection.__netConnectionName,
    ...connection.mergedConnectionNames ?? [],
    ...connection.__rootConnectionNames ?? [],
  ].filter((name): name is string => typeof name === "string"))]
}

function getPhysicalLayers(layers: readonly string[], layerCount: number): number[] {
  return [...new Set(layers.map((layer) => {
    const z = mapLayerNameToZ(layer, layerCount)
    if (!Number.isInteger(z) || z < 0 || z >= layerCount || mapZToLayerName(z, layerCount) !== layer) {
      throw new Error(`Invalid allowed routing layer "${layer}" for ${layerCount} physical layers`)
    }
    return z
  }))].sort((a, b) => a - b)
}

function coversBoard(obstacle: Obstacle, vertices: readonly Point[]): boolean {
  const radians = (obstacle.ccwRotationDegrees ?? 0) * Math.PI / 180
  const cosine = Math.cos(radians)
  const sine = Math.sin(radians)
  if (![obstacle.center.x, obstacle.center.y, obstacle.width, obstacle.height, radians].every(Number.isFinite) || obstacle.width <= 0 || obstacle.height <= 0) {
    throw new Error(`Invalid copper-pour geometry "${obstacle.obstacleId}"`)
  }
  return vertices.every((point) => {
    const dx = point.x - obstacle.center.x
    const dy = point.y - obstacle.center.y
    if (obstacle.shape === "circle") return Math.hypot(dx, dy) <= Math.max(obstacle.width, obstacle.height) / 2 + 1e-9
    return Math.abs(cosine * dx + sine * dy) <= obstacle.width / 2 + 1e-9 &&
      Math.abs(-sine * dx + cosine * dy) <= obstacle.height / 2 + 1e-9
  })
}

/** Compile domains once for an immutable native SRJ snapshot. */
export function createAllowedZResolver(srj: SimpleRouteJson): (connectionName: string) => number[] {
  if (!Number.isInteger(srj.layerCount) || srj.layerCount < 1) throw new Error("Invalid physical layer count")
  const connectivity = getConnectivityMapFromSimpleRouteJson(srj)
  const declarations: SimpleRouteConnection[] = [...srj.connections]
  for (const trace of srj.traces ?? []) {
    if (!trace.connection_name) throw new Error(`Preloaded trace "${trace.pcb_trace_id}" has no source connection`)
    if (!declarations.some((connection) => getConnectionNames(connection).includes(trace.connection_name))) {
      declarations.push({ name: trace.connection_name, source_trace_id: trace.pcb_trace_id, pointsToConnect: [] })
    }
  }
  for (const connection of declarations) connectivity.addConnections([getConnectionNames(connection)])
  const { minX, maxX, minY, maxY } = srj.bounds
  const vertices = srj.outline && srj.outline.length >= 3 ? srj.outline : [
    { x: minX, y: minY }, { x: maxX, y: minY }, { x: maxX, y: maxY }, { x: minX, y: maxY },
  ]
  const fullPours = srj.obstacles.filter((obstacle) => obstacle.isCopperPour && coversBoard(obstacle, vertices))
    .map((obstacle) => ({
      blockedZ: new Set(getPhysicalLayers(obstacle.layers, srj.layerCount)),
      ownerNets: new Set(obstacle.connectedTo.map((owner) => connectivity.getNetConnectedToId(owner)).filter((net) => net !== undefined)),
    }))
  const domains = new Map<string, number[]>()
  return (connectionName: string): number[] => {
    const cached = domains.get(connectionName)
    if (cached !== undefined) return [...cached]
    const exactMatches = declarations.filter((connection) => connection.name === connectionName)
    const matches = exactMatches.length > 0 ? exactMatches : declarations.filter((connection) => getConnectionNames(connection).includes(connectionName))
    if (matches.length === 0) throw new Error(`Could not resolve routing layers for connection "${connectionName}"`)
    let allowedZ = Array.from({ length: srj.layerCount }, (_, z) => z)
    const names = new Set(matches.flatMap(getConnectionNames))
    const constraints = [srj.allowedLayers, ...matches.map((connection) => connection.allowedLayers),
      ...(srj.buses ?? []).filter((bus) => bus.connectionNames.some((name) => names.has(name))).map((bus) => bus.allowedLayers)]
    for (const layers of constraints) {
      if (layers === undefined) continue
      const permitted = new Set(getPhysicalLayers(layers, srj.layerCount))
      allowedZ = allowedZ.filter((z) => permitted.has(z))
    }
    const sourceNet = connectivity.getNetConnectedToId(connectionName)
    for (const pour of fullPours) {
      if (sourceNet !== undefined && pour.ownerNets.has(sourceNet)) continue
      allowedZ = allowedZ.filter((z) => !pour.blockedZ.has(z))
    }
    if (allowedZ.length === 0) throw new Error(`Connection "${connectionName}" has no legal wire layers`)
    domains.set(connectionName, allowedZ)
    return [...allowedZ]
  }
}

/** Resolve a single connection without changing the physical stack or native ownership. */
export function getAllowedZForConnection(srj: SimpleRouteJson, connectionName: string): number[] {
  const resolve = createAllowedZResolver(srj)
  const allowedZ = resolve(connectionName)
  // Keep each consumer's domain independent from the immutable source snapshot.
  // A repair may narrow its local domain, but cannot grant a new physical layer.
  return [...allowedZ]
}
