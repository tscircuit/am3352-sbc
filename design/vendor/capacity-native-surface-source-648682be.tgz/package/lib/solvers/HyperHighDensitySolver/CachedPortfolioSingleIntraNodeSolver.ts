import type { ConnectivityMap } from "circuit-json-to-connectivity-map"
import {
  getGlobalInMemoryCache,
  setupGlobalCaches,
} from "lib/cache/setupGlobalCaches"
import { CachableSolver, CacheProvider } from "lib/cache/types"
import type {
  HighDensityIntraNodeRoute,
  NodeWithPortPoints,
  PortPoint,
} from "lib/types/high-density-types"
import objectHash from "object-hash"
import type { HighDensityHyperParameters } from "../HighDensitySolver/HighDensityHyperParameters"
import { PortfolioSingleIntraNodeSolver } from "./PortfolioSingleIntraNodeSolver"

// Define the structure of the cached data
type CachedSolvedPortfolioSingleIntraNode =
  | { success: true; solvedRoutes: HighDensityIntraNodeRoute[] }
  | { success: false }

// Define the transform type (currently unused but required by the interface)
type CacheToPortfolioSingleIntraNodeTransform = Record<string, never> // Or define specific transform data if needed

// Round coordinates to mitigate floating point inconsistencies in cache keys

// Round to nearest 5um (0.005mm)
const roundCoord = (n: number) => Math.round(n * 200) / 200

setupGlobalCaches()

const PORTFOLIO_SINGLE_INTRA_NODE_CACHE_SCHEMA_VERSION = 4

export class CachedPortfolioSingleIntraNodeSolver
  extends PortfolioSingleIntraNodeSolver
  implements
    CachableSolver<
      CacheToPortfolioSingleIntraNodeTransform,
      CachedSolvedPortfolioSingleIntraNode
    >
{
  cacheHit = false
  cacheProvider: CacheProvider | null
  declare cacheKey?: string | undefined
  declare cacheToSolveSpaceTransform?:
    | CacheToPortfolioSingleIntraNodeTransform
    | undefined
  hasAttemptedToUseCache = false

  constructor(
    params: ConstructorParameters<typeof PortfolioSingleIntraNodeSolver>[0] & {
      cacheProvider?: CacheProvider | null
    },
  ) {
    super(params)
    this.cacheProvider =
      params.cacheProvider === undefined
        ? getGlobalInMemoryCache() // Default to in-memory if undefined
        : params.cacheProvider // Use null if explicitly passed as null
  }

  _step(): void {
    if (!this.hasAttemptedToUseCache && this.cacheProvider) {
      if (this.attemptToUseCacheSync()) {
        // If cache hit and applied, we might be done or failed based on cache
        return
      }
    }
    super._step()
    if ((this.solved || this.failed) && this.cacheProvider && !this.cacheHit) {
      // Save to cache only if it wasn't a cache hit initially
      this.saveToCacheSync()
    }
  }

  computeCacheKeyAndTransform(): {
    cacheKey: string
    cacheToSolveSpaceTransform: CacheToPortfolioSingleIntraNodeTransform
  } {
    const connectionNameToNormNameMap = new Map<string, string>()

    // TODO connection names need proper normalization

    // 1. Normalize NodeWithPortPoints
    const node = this.nodeWithPortPoints
    const center = node.center
    const normalizedPortPoints = [...node.portPoints]
      .sort((a, b) => {
        if (a.connectionName !== b.connectionName)
          return a.connectionName.localeCompare(b.connectionName)
        if (a.x !== b.x) return a.x - b.x
        if (a.y !== b.y) return a.y - b.y
        return (a.z ?? 0) - (b.z ?? 0)
      })
      .map((pp) => {
        return {
          connectionName: pp.connectionName,
          portPointId: pp.portPointId,
          x: roundCoord(pp.x - center.x),
          y: roundCoord(pp.y - center.y),
          z: pp.z ?? 0,
          prevPortPointId: pp.prevPortPointId,
          nextPortPointId: pp.nextPortPointId,
          // Include other relevant properties if they affect routing
          // e.g., traceThickness, viaDiameter if they vary per portPoint
        }
      })

    const normalizedNodeData = {
      width: roundCoord(node.width),
      height: roundCoord(node.height),
      center: {
        x: roundCoord(center.x),
        y: roundCoord(center.y),
      },
      availableZ: node.availableZ ? [...node.availableZ].sort() : undefined,
      allowedZByConnectionName: node.allowedZByConnectionName,
      portPoints: normalizedPortPoints,
    }

    const normalizedRelevantConnMap: string[][] = []

    for (const portPoint of normalizedPortPoints) {
      const relevantConnMap = this.connMap?.getIdsConnectedToNet(
        portPoint.connectionName,
      )
      if (relevantConnMap) {
        normalizedRelevantConnMap.push(relevantConnMap)
      }
    }

    const normalizedHyperParameters = Object.fromEntries(
      Object.entries(this.constructorParams.hyperParameters ?? {})
        .filter(([, value]) => value !== undefined)
        .sort(([a], [b]) => a.localeCompare(b)),
    )

    // Note: connMap is omitted as hashing it is complex and might be too broad.
    const keyData = {
      cacheSchemaVersion: PORTFOLIO_SINGLE_INTRA_NODE_CACHE_SCHEMA_VERSION,
      normalizedNodeData,
      normalizedHyperParameters,
      gridSearchSegmentWork: this.gridSearchSegmentWork,
      gridSearchWorkScale: this.gridSearchWorkScale,
      rejectOverlappingTerminals: this.rejectOverlappingTerminals,
      traceWidth: roundCoord(this.constructorParams.traceWidth ?? 0.15),
      viaDiameter: roundCoord(this.constructorParams.viaDiameter ?? 0.3),
      obstacleMargin: roundCoord(this.constructorParams.obstacleMargin ?? 0.15),
      // TODO connMap
    }

    const cacheKey = `intranode:${objectHash(keyData)}`
    const cacheToSolveSpaceTransform = {} // No transform needed for this approach

    this.cacheKey = cacheKey
    this.cacheToSolveSpaceTransform = cacheToSolveSpaceTransform

    return { cacheKey, cacheToSolveSpaceTransform }
  }

  applyCachedSolution(
    cachedSolution: CachedSolvedPortfolioSingleIntraNode,
  ): void {
    if (cachedSolution.success) {
      // Important: Deep clone the cached routes if they might be mutated later
      // For now, assuming they are treated as immutable after retrieval.
      this.solvedRoutes = cachedSolution.solvedRoutes
      this.solved = true
      this.failed = false
    } else {
      this.solvedRoutes = []
      this.solved = false
      this.failed = true
    }
    this.cacheHit = true // Mark that we used a cached result
    this.progress = 1 // Mark as complete
  }

  attemptToUseCacheSync(): boolean {
    this.hasAttemptedToUseCache = true
    if (!this.cacheProvider?.isSyncCache) {
      // console.log("Cache provider is not synchronous, skipping sync cache check.")
      return false
    }

    if (!this.cacheKey) {
      try {
        this.computeCacheKeyAndTransform()
      } catch (error) {
        console.error("Error computing cache key:", error)
        return false // Cannot use cache if key generation fails
      }
    }

    if (!this.cacheKey) {
      console.error("Failed to compute cache key.")
      return false
    }

    try {
      const cachedSolution = this.cacheProvider.getCachedSolutionSync(
        this.cacheKey,
      )

      if (cachedSolution !== undefined && cachedSolution !== null) {
        // console.log(`Cache hit for PortfolioSingleIntraNodeSolver: ${this.cacheKey}`)
        this.applyCachedSolution(
          cachedSolution as CachedSolvedPortfolioSingleIntraNode,
        )
        return true // Cache hit and applied
      } else {
        // console.log(`Cache miss for PortfolioSingleIntraNodeSolver: ${this.cacheKey}`)
      }
    } catch (error) {
      console.error("Error attempting to use cache:", error)
      // Decide how to handle cache read errors, e.g., treat as miss
    }

    return false // Cache miss or error
  }

  saveToCacheSync(): void {
    if (!this.cacheKey) {
      console.error(
        "Cannot save to cache without cache key. Trying to compute.",
      )
      try {
        this.computeCacheKeyAndTransform()
        if (!this.cacheKey) {
          console.error("Still failed to compute cache key. Cannot save.")
          return
        }
      } catch (error) {
        console.error("Error computing cache key during save:", error)
        return
      }
    }

    if (!this.cacheProvider?.isSyncCache) {
      // console.log("Cache provider is not synchronous, skipping sync cache save.")
      return
    }

    let solutionToCache: CachedSolvedPortfolioSingleIntraNode

    if (this.failed) {
      solutionToCache = { success: false }
    } else if (this.solved) {
      // Important: Deep clone routes if necessary before caching
      solutionToCache = { success: true, solvedRoutes: this.solvedRoutes }
    } else {
      // Solver finished without being solved or failed? Should not happen in typical flow.
      // console.warn("Attempting to save cache for solver that is neither solved nor failed.")
      return // Don't cache intermediate states unless intended
    }

    try {
      // console.log(`Saving to cache for PortfolioSingleIntraNodeSolver: ${this.cacheKey}`)
      this.cacheProvider.setCachedSolutionSync(this.cacheKey, solutionToCache)
    } catch (error) {
      console.error("Error saving solution to cache:", error)
      // Handle cache write errors if necessary
    }
  }
}
