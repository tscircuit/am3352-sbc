import {
  HighDensitySolverA03 as HighDensityA03Solver,
  HighDensitySolverA01,
} from "@tscircuit/high-density-a01"
import { HighDensitySolverA13 } from "@tscircuit/high-density-a13"
import { ConnectivityMap } from "circuit-json-to-connectivity-map"
import type { HighDensityBoardGeometry } from "lib/types/high-density-board-geometry"
import {
  HighDensityIntraNodeRoute,
  NodeWithPortPoints,
} from "lib/types/high-density-types"
import { CachedIntraNodeRouteSolver } from "../HighDensitySolver/CachedIntraNodeRouteSolver"
import type { BaseSolver } from "../BaseSolver"
import { IntraNodeRouteSolver } from "../HighDensitySolver/IntraNodeSolver"
import { MultiHeadPolyLineIntraNodeSolver2 } from "../HighDensitySolver/MultiHeadPolyLineIntraNodeSolver/MultiHeadPolyLineIntraNodeSolver2_Optimized"
import { MultiHeadPolyLineIntraNodeSolver3 } from "../HighDensitySolver/MultiHeadPolyLineIntraNodeSolver/MultiHeadPolyLineIntraNodeSolver3_ViaPossibilitiesSolverIntegration"
import { SingleLayerNoDifferentRootIntersectionsIntraNodeSolver } from "../HighDensitySolver/SingleLayerNoDifferentRootIntersectionsIntraNodeSolver"
import { SingleTransitionIntraNodeSolver } from "../HighDensitySolver/SingleTransitionIntraNodeSolver"
import { SingleTransitionThroughObstacleIntraNodeSolver } from "../HighDensitySolver/SingleTransitionThroughObstacleIntraNodeSolver"
import {
  precomputeIntraNodeRouteParams,
  type PrecomputedIntraNodeRouteParams,
} from "../HighDensitySolver/precomputeIntraNodeRouteParams"
import { SingleTransitionCrossingRouteSolver } from "../HighDensitySolver/TwoRouteHighDensitySolver/SingleTransitionCrossingRouteSolver"
import { TwoCrossingRoutesHighDensitySolver } from "../HighDensitySolver/TwoRouteHighDensitySolver/TwoCrossingRoutesHighDensitySolver"
import {
  HyperParameterSupervisorSolver,
  SupervisedSolver,
} from "../HyperParameterSupervisorSolver"
import { HighDensitySolverA13WithDrcValidation } from "./HighDensitySolverA13WithDrcValidation"
import { repairDisconnectedSameRootPortPoints } from "./repairDisconnectedSameRootPortPoints"
import { getAllowedZForNodeConnection } from "lib/utils/getAllowedZForNodeConnection"

// Match the existing six-ordering portfolio used by the other intra-node
// solver. The first ordering remains in the normal portfolio; the remaining
// orderings are introduced only after that portfolio spends its dynamically
// derived exploration budget or exhausts all of its candidates.
const ORDERING_SHUFFLE_SEEDS = Array.from({ length: 6 }, (_, seed) => seed)

/** Coordinates a fitness-scheduled portfolio of intra-node routing solvers. */
export class PortfolioSingleIntraNodeSolver extends HyperParameterSupervisorSolver<
  | IntraNodeRouteSolver
  | TwoCrossingRoutesHighDensitySolver
  | SingleTransitionCrossingRouteSolver
  | SingleTransitionIntraNodeSolver
  | SingleTransitionThroughObstacleIntraNodeSolver
  | SingleLayerNoDifferentRootIntersectionsIntraNodeSolver
  | HighDensityA03Solver
  | HighDensitySolverA13
> {
  override getSolverName(): string {
    return "PortfolioSingleIntraNodeSolver"
  }

  constructorParams: ConstructorParameters<
    typeof CachedIntraNodeRouteSolver
  >[0] & {
    boardGeometry?: HighDensityBoardGeometry
  }
  solvedRoutes: HighDensityIntraNodeRoute[] = []
  nodeWithPortPoints: NodeWithPortPoints
  connMap?: ConnectivityMap
  effort: number
  adaptiveSearchExpanded = false
  negotiatedSearchStarted = false
  readonly enableNegotiatedSearch: boolean
  readonly gridSearchSegmentWork: number
  readonly gridSearchWorkScale: number
  readonly rejectOverlappingTerminals: boolean
  private precomputedIntraNodeRouteParams?: PrecomputedIntraNodeRouteParams
  private nodeSegmentCount?: number
  private totalCandidateWork = 0
  private dynamicExpansionWorkBudget = 1
  private candidateWorkBySolver = new WeakMap<
    BaseSolver,
    { iterations: number; maxIterations: number }
  >()

  private getSolvedSegmentCount(solver: unknown): number | null {
    const solvedConnectionsMap = (solver as any).solvedConnectionsMap
    if (!(solvedConnectionsMap instanceof Map)) return null

    let solvedSegmentCount = 0
    for (const routes of solvedConnectionsMap.values()) {
      if (Array.isArray(routes)) solvedSegmentCount += routes.length
    }
    return solvedSegmentCount
  }

  private getNodeSegmentCount(): number {
    this.nodeSegmentCount ??= Math.max(
      1,
      this.nodeWithPortPoints.portPointsInPairs?.length ??
        new Set(
          this.nodeWithPortPoints.portPoints.map(
            (portPoint) => portPoint.connectionName,
          ),
        ).size,
    )
    return this.nodeSegmentCount
  }

  private getCandidateProgress(solver: { progress: number }): number {
    if (solver instanceof HighDensitySolverA13) {
      if (solver.solved) return 1
      const connectionCount = solver.connections.length
      if (connectionCount === 0) return 0
      // A complete set of provisional paths still needs congestion negotiation.
      const routedFraction = solver.routedCount / connectionCount
      const conflictFreeFraction = Math.max(
        0,
        (solver.routedCount - solver.conflictCount) / connectionCount,
      )
      return Math.min(0.99, (routedFraction + conflictFreeFraction) / 2)
    }
    const solvedSegmentCount = this.getSolvedSegmentCount(solver)
    if (solvedSegmentCount !== null) {
      return Math.min(1, solvedSegmentCount / this.getNodeSegmentCount())
    }
    return Math.max(0, Math.min(1, solver.progress || 0))
  }

  constructor(
    opts: ConstructorParameters<typeof CachedIntraNodeRouteSolver>[0] & {
      effort?: number
      enableNegotiatedSearch?: boolean
      gridSearchSegmentWork?: number
      gridSearchWorkScale?: number
      rejectOverlappingTerminals?: boolean
      boardGeometry?: HighDensityBoardGeometry
    },
  ) {
    super()
    this.nodeWithPortPoints = opts.nodeWithPortPoints
    this.connMap = opts.connMap
    this.constructorParams = opts
    this.effort = opts.effort ?? 1
    this.gridSearchSegmentWork = opts.gridSearchSegmentWork ?? 10_000
    this.gridSearchWorkScale = opts.gridSearchWorkScale ?? 1
    this.rejectOverlappingTerminals = opts.rejectOverlappingTerminals ?? false
    this.enableNegotiatedSearch = opts.enableNegotiatedSearch ?? false
    this.MAX_ITERATIONS = 20_000_000 * this.effort
    this.GREEDY_MULTIPLIER = 5
    this.MIN_SUBSTEPS = 100
    // These endpoints are fixed within this attempt. No route ordering can
    // separate overlapping copper; let the existing grow/shrink search move
    // to a feasible scale instead of exhausting every candidate here.
    if (this.rejectOverlappingTerminals) {
      const ports = this.nodeWithPortPoints.portPoints
      const traceWidth = opts.traceWidth ?? 0.15
      for (let i = 0; i < ports.length; i++) {
        for (let j = i + 1; j < ports.length; j++) {
          const a = ports[i]!
          const b = ports[j]!
          if (
            a.z !== b.z ||
            (a.rootConnectionName ?? a.connectionName) ===
              (b.rootConnectionName ?? b.connectionName) ||
            this.connMap?.areIdsConnected(a.connectionName, b.connectionName)
          ) {
            continue
          }
          if (Math.hypot(a.x - b.x, a.y - b.y) < traceWidth - 1e-6) {
            this.failed = true
            this.error =
              "Unrelated route terminals overlap at the requested trace width"
            return
          }
        }
      }
    }
  }

  private getGridSearchIterationBudget(): number {
    const node = this.nodeWithPortPoints
    const layerCount =
      node.availableZ?.length ??
      new Set(node.portPoints.map((point) => point.z)).size
    const states =
      Math.floor(node.width / 0.1) * Math.floor(node.height / 0.1) * layerCount
    // Avoid the external solvers' two-million-iteration floor on small grids,
    // while retaining room for interacting connections on crowded nodes.
    const budgetScale = layerCount > 2 ? this.gridSearchWorkScale : 1
    return Math.round(
      budgetScale *
        Math.max(
          150_000,
          (layerCount <= 2 ? 10_000 : this.gridSearchSegmentWork) *
            this.getNodeSegmentCount() ** 2,
          Math.round(
            states *
              (8 + 1.2 * Math.sqrt(this.getNodeSegmentCount())) *
              this.effort,
          ),
        ),
    )
  }

  getCombinationDefs() {
    const domains = new Set(this.nodeWithPortPoints.portPoints.map((point) =>
      getAllowedZForNodeConnection(this.nodeWithPortPoints, point.connectionName, point.rootConnectionName).join(","),
    ))
    // External kernels accept a node-wide layer domain. The internal grid
    // router carries a separate domain into every single-connection search.
    if (domains.size > 1) return [
      ["majorCombinations", "orderings6", "cellSizeFactor"], ["noVias"],
      ["orderings50"], ["flipTraceAlignmentDirection", "orderings6"],
    ]
    return [
      ["throughObstacle"],
      ["singleLayerNoDifferentRootIntersections"],
      ["multiHeadPolyLine"],
      ["majorCombinations", "orderings6", "cellSizeFactor"],
      ["noVias"],
      ["orderings50"],
      ["flipTraceAlignmentDirection", "orderings6"],
      ["closedFormSingleTrace"],
      // ["closedFormTwoTrace"],
      ["highDensityA01"],
      ["highDensityA03"],
      ...(this.enableNegotiatedSearch ? [["highDensityA13"]] : []),
    ]
  }

  getHyperParameterDefs() {
    return [
      {
        name: "singleLayerNoDifferentRootIntersections",
        possibleValues: [
          {
            SINGLE_LAYER_NO_DIFFERENT_ROOT_INTERSECTIONS: true,
          },
        ],
      },
      {
        name: "majorCombinations",
        possibleValues: [
          {
            FUTURE_CONNECTION_PROX_TRACE_PENALTY_FACTOR: 2,
            FUTURE_CONNECTION_PROX_VIA_PENALTY_FACTOR: 1,
            FUTURE_CONNECTION_PROXIMITY_VD: 10,
            MISALIGNED_DIST_PENALTY_FACTOR: 5,
          },
          {
            FUTURE_CONNECTION_PROX_TRACE_PENALTY_FACTOR: 1,
            FUTURE_CONNECTION_PROX_VIA_PENALTY_FACTOR: 0.5,
            FUTURE_CONNECTION_PROXIMITY_VD: 5,
            MISALIGNED_DIST_PENALTY_FACTOR: 2,
          },
          {
            FUTURE_CONNECTION_PROX_TRACE_PENALTY_FACTOR: 10,
            FUTURE_CONNECTION_PROX_VIA_PENALTY_FACTOR: 1,
            FUTURE_CONNECTION_PROXIMITY_VD: 5,
            MISALIGNED_DIST_PENALTY_FACTOR: 10,
            VIA_PENALTY_FACTOR_2: 1,
          },
        ],
      },
      {
        name: "orderings6",
        possibleValues: ORDERING_SHUFFLE_SEEDS.map((shuffleSeed) => ({
          SHUFFLE_SEED: shuffleSeed,
        })),
      },
      {
        name: "cellSizeFactor",
        possibleValues: [
          {
            CELL_SIZE_FACTOR: 0.5,
          },
          {
            CELL_SIZE_FACTOR: 1,
          },
        ],
      },
      {
        name: "flipTraceAlignmentDirection",
        possibleValues: [
          {
            FLIP_TRACE_ALIGNMENT_DIRECTION: true,
          },
        ],
      },
      {
        name: "noVias",
        possibleValues: [
          {
            CELL_SIZE_FACTOR: 2,
            VIA_PENALTY_FACTOR_2: 10,
          },
        ],
      },
      {
        name: "orderings50",
        possibleValues: Array.from({ length: 20 }, (_, i) => ({
          SHUFFLE_SEED: 100 + i,
        })),
      },
      // {
      //   name: "closedFormTwoTrace",
      //   possibleValues: [
      //     {
      //       CLOSED_FORM_TWO_TRACE_SAME_LAYER: true,
      //     },
      //     {
      //       CLOSED_FORM_TWO_TRACE_TRANSITION_CROSSING: true,
      //     },
      //   ],
      // },
      {
        name: "throughObstacle",
        possibleValues: [
          {
            THROUGH_OBSTACLE: true,
          },
        ],
      },
      {
        name: "closedFormSingleTrace",
        possibleValues: [
          {
            CLOSED_FORM_SINGLE_TRANSITION: true,
          },
        ],
      },
      {
        name: "multiHeadPolyLine",
        possibleValues: [
          {
            MULTI_HEAD_POLYLINE_SOLVER: true,
            SEGMENTS_PER_POLYLINE: 6,
            BOUNDARY_PADDING: 0.05,
          },
          {
            MULTI_HEAD_POLYLINE_SOLVER: true,
            SEGMENTS_PER_POLYLINE: 6,
            BOUNDARY_PADDING: -0.05, // Allow vias/traces outside the boundary
            ITERATION_PENALTY: 10000,
            MINIMUM_FINAL_ACCEPTANCE_GAP: 0.001,
          },
        ],
      },
      {
        name: "highDensityA01",
        possibleValues: [
          {
            HIGH_DENSITY_A01: true,
            SHUFFLE_SEED: ORDERING_SHUFFLE_SEEDS[0],
          },
        ],
      },
      {
        name: "highDensityA03",
        possibleValues: [
          {
            HIGH_DENSITY_A03: true,
          },
        ],
      },
      {
        name: "highDensityA13",
        possibleValues: [{ HIGH_DENSITY_A13: true, SHUFFLE_SEED: 0 }],
      },
    ]
  }

  /**
   * Some external solvers expose an idempotent setup phase that calculates
   * their natural iteration budget from the problem. Running setup here does
   * not advance the solver or give it preference in the portfolio.
   */
  private initializeCandidateBudget(solver: unknown) {
    // A13 already declares its search limit; allocate its grid only if selected.
    if (solver instanceof HighDensitySolverA13) return
    const setup = (solver as any).setup
    if (typeof setup === "function") setup.call(solver)
    if (
      solver instanceof HighDensitySolverA01 ||
      solver instanceof HighDensityA03Solver
    ) {
      solver.MAX_ITERATIONS = Math.min(
        solver.MAX_ITERATIONS,
        this.getGridSearchIterationBudget(),
      )
    }
  }

  private refreshDynamicIterationLimit() {
    this.totalCandidateWork = 0
    this.dynamicExpansionWorkBudget = 1
    const remainingSupervisorIterations = (this.supervisedSolvers ?? []).reduce(
      (total, { solver }) => {
        // A13 negotiates route orders internally. Its larger budget must not
        // delay expansion of the existing A01 ordering search.
        if (!(solver instanceof HighDensitySolverA13)) {
          this.totalCandidateWork += solver.iterations
          // Preserve the work budget of the most expensive initial candidate.
          this.dynamicExpansionWorkBudget = Math.max(
            this.dynamicExpansionWorkBudget,
            solver.MAX_ITERATIONS,
          )
          this.candidateWorkBySolver.set(solver, {
            iterations: solver.iterations,
            maxIterations: solver.MAX_ITERATIONS,
          })
        }
        if (solver.solved || solver.failed) return total
        const remainingCandidateIterations = Math.max(
          0,
          solver.MAX_ITERATIONS - solver.iterations + 1,
        )
        return (
          total + Math.ceil(remainingCandidateIterations / this.MIN_SUBSTEPS)
        )
      },
      0,
    )

    // Keep one supervisor step available to observe that the current
    // portfolio is exhausted and expand it before BaseSolver can fail.
    this.MAX_ITERATIONS = Math.max(
      this.iterations + 1,
      this.iterations + remainingSupervisorIterations,
    )
    this.stats.dynamicSupervisorIterationLimit = this.MAX_ITERATIONS
  }

  override initializeSolvers() {
    super.initializeSolvers()
    for (const { solver } of this.supervisedSolvers ?? []) {
      this.initializeCandidateBudget(solver)
    }
    this.refreshDynamicIterationLimit()
    this.stats.dynamicExpansionWorkBudget = this.dynamicExpansionWorkBudget
  }

  private addSupervisedCandidate(hyperParameters: Record<string, any>) {
    const solver = this.generateSolver(hyperParameters)
    this.initializeCandidateBudget(solver)
    const g = this.computeG(solver)
    this.supervisedSolvers!.push({
      hyperParameters,
      solver,
      h: 0,
      g,
      f: g,
    })
  }

  private expandAdaptiveSearch() {
    if (this.adaptiveSearchExpanded) return

    this.adaptiveSearchExpanded = true
    for (const shuffleSeed of ORDERING_SHUFFLE_SEEDS.slice(1)) {
      this.addSupervisedCandidate({
        HIGH_DENSITY_A01: true,
        SHUFFLE_SEED: shuffleSeed,
      })
    }
    this.refreshDynamicIterationLimit()
    this.stats.adaptiveSearchExpanded = true
    this.stats.adaptiveSearchExpandedAtIteration = this.iterations
    this.stats.candidateWorkAtExpansion = this.totalCandidateWork
    this.stats.bestProgressAtExpansion = Math.max(
      0,
      ...(this.supervisedSolvers ?? []).map(({ solver }) =>
        this.getCandidateProgress(solver),
      ),
    )
  }

  private shouldExpandPortfolio(): boolean {
    if (this.adaptiveSearchExpanded) return false

    const expansionWorkBudget = this.dynamicExpansionWorkBudget
    this.stats.dynamicExpansionWorkBudget = expansionWorkBudget
    return this.totalCandidateWork >= expansionWorkBudget
  }

  override _step() {
    if (!this.supervisedSolvers) this.initializeSolvers()

    if (
      !this.adaptiveSearchExpanded &&
      !this.getSupervisedSolverWithBestFitness()
    ) {
      this.expandAdaptiveSearch()
    }

    super._step()

    if (
      !this.negotiatedSearchStarted &&
      this.activeSubSolver instanceof HighDensitySolverA13
    ) {
      this.negotiatedSearchStarted = true
      this.stats.negotiatedSearchStartedAtIteration = this.iterations
    }

    if (!this.solved && !this.failed && this.shouldExpandPortfolio()) {
      this.expandAdaptiveSearch()
    }
  }

  computeG(solver: IntraNodeRouteSolver): number {
    if (solver instanceof HighDensitySolverA13) {
      return solver.routingIterations / 1_000_000
    }
    // The supervisor advances one candidate before recomputing its fitness.
    // Account for that candidate's actual work without rescanning the portfolio.
    const accountedWork = this.candidateWorkBySolver.get(solver)
    if (accountedWork) {
      this.totalCandidateWork += solver.iterations - accountedWork.iterations
      accountedWork.iterations = solver.iterations
      if (accountedWork.maxIterations !== solver.MAX_ITERATIONS) {
        accountedWork.maxIterations = solver.MAX_ITERATIONS
        this.dynamicExpansionWorkBudget = 1
        for (const { solver: candidate } of this.supervisedSolvers ?? []) {
          if (candidate instanceof HighDensitySolverA13) continue
          this.dynamicExpansionWorkBudget = Math.max(
            this.dynamicExpansionWorkBudget,
            candidate.MAX_ITERATIONS,
          )
        }
      }
    }
    if (
      (solver as any) instanceof HighDensitySolverA01 ||
      (solver as any) instanceof HighDensityA03Solver ||
      (solver as any) instanceof HighDensitySolverA13
    ) {
      return (solver as any).iterations / 1_000_000
    }
    if (solver?.hyperParameters?.MULTI_HEAD_POLYLINE_SOLVER) {
      return (
        1000 +
        ((solver.hyperParameters?.ITERATION_PENALTY ?? 0) + solver.iterations) /
          10_000 +
        10_000 * (solver.hyperParameters.SEGMENTS_PER_POLYLINE! - 3)
      )
    }
    return (
      solver.iterations / 10_000 // + solver.hyperParameters.SHUFFLE_SEED! * 0.05
    )
  }

  computeH(solver: IntraNodeRouteSolver): number {
    if (solver instanceof HighDensitySolverA13) {
      return 1 - this.getCandidateProgress(solver)
    }
    if (this.adaptiveSearchExpanded) {
      return 1 - this.getCandidateProgress(solver)
    }
    return 1 - (solver.progress || 0)
  }

  generateSolver(hyperParameters: any): IntraNodeRouteSolver {
    // Each grow/shrink attempt owns a distinct node and portfolio. Keep this
    // shared data local so later attempts and caller edits are recomputed.
    this.precomputedIntraNodeRouteParams ??= precomputeIntraNodeRouteParams(
      this.nodeWithPortPoints,
    )
    if (hyperParameters.SINGLE_LAYER_NO_DIFFERENT_ROOT_INTERSECTIONS) {
      if (
        !SingleLayerNoDifferentRootIntersectionsIntraNodeSolver.isApplicable(
          this.nodeWithPortPoints,
        )
      ) {
        const ineligibleSolver = new IntraNodeRouteSolver({
          nodeWithPortPoints: this.nodeWithPortPoints,
          connMap: this.connMap,
          traceWidth: this.constructorParams.traceWidth,
          viaDiameter: this.constructorParams.viaDiameter,
          obstacleMargin: this.constructorParams.obstacleMargin,
          precomputedIntraNodeRouteParams: this.precomputedIntraNodeRouteParams,
        })
        ineligibleSolver.failed = true
        ineligibleSolver.error =
          "Single-layer no-different-root-intersection solver not applicable"
        return ineligibleSolver as any
      }

      return new SingleLayerNoDifferentRootIntersectionsIntraNodeSolver({
        nodeWithPortPoints: this.nodeWithPortPoints,
        traceWidth: this.constructorParams.traceWidth,
        viaDiameter: this.constructorParams.viaDiameter,
      }) as any
    }

    if (hyperParameters.HIGH_DENSITY_A13) {
      const maxSearchIterations = Math.max(
        1,
        Math.round(50_000_000 * this.effort),
      )
      const solver = new HighDensitySolverA13WithDrcValidation({
        obstacles: this.constructorParams.obstacles ?? [],
        boardGeometry: this.constructorParams.boardGeometry,
        connMap: this.connMap,
        layerCount: this.constructorParams.layerCount ?? 2,
        nodeWithPortPoints: this.nodeWithPortPoints,
        cellSizeMm: 0.1,
        viaDiameter: this.constructorParams.viaDiameter ?? 0.3,
        viaMinDistFromBorder: (this.constructorParams.viaDiameter ?? 0.3) / 2,
        traceThickness: this.constructorParams.traceWidth ?? 0.15,
        traceMargin: 0.1,
        // Use the optimized kernel in batches; fitness accounts for search work
        // rather than the number of calls into the kernel.
        stepMultiplier: 1000,
        maxSearchIterations,
        maxRounds: Math.max(1, Math.round(200 * this.effort)),
        hyperParameters: { shuffleSeed: hyperParameters.SHUFFLE_SEED ?? 0 },
      })
      solver.MAX_ITERATIONS = maxSearchIterations * 2
      return solver as any
    }
    if (hyperParameters.HIGH_DENSITY_A01) {
      const solver = new HighDensitySolverA01({
        nodeWithPortPoints: this.nodeWithPortPoints,
        cellSizeMm: 0.1,
        viaDiameter: this.constructorParams.viaDiameter ?? 0.3,
        viaMinDistFromBorder: (this.constructorParams.viaDiameter ?? 0.3) / 2,
        traceMargin: 0.1,
        traceThickness: this.constructorParams.traceWidth ?? 0.15,
        effort: this.effort,
        hyperParameters: {
          shuffleSeed: hyperParameters.SHUFFLE_SEED ?? 0,
        },
      })
      return solver as any
    }
    if (hyperParameters.HIGH_DENSITY_A03) {
      const solver = new HighDensityA03Solver({
        nodeWithPortPoints: this.nodeWithPortPoints,
        highResolutionCellSize: 0.1,
        highResolutionCellThickness: 8,
        lowResolutionCellSize: 0.4,
        viaDiameter: this.constructorParams.viaDiameter ?? 0.3,
        viaMinDistFromBorder: (this.constructorParams.viaDiameter ?? 0.3) / 2,
        traceMargin: 0.1,
        // This likely needs to be corrected to use the actual trace width-
        // but using anything but 0.1 for traceThickness is causing issues
        // needs more debugging- repro01 in the high-density-a01 repo
        // has a good reproduction
        traceThickness: 0.1, // this.constructorParams.traceWidth ?? 0.15,
        effort: this.effort,
        hyperParameters,
      })
      return solver as any
    }
    if (hyperParameters.CLOSED_FORM_TWO_TRACE_SAME_LAYER) {
      return new TwoCrossingRoutesHighDensitySolver({
        nodeWithPortPoints: this.nodeWithPortPoints,
        viaDiameter: this.constructorParams.viaDiameter,
      }) as any
    }
    if (hyperParameters.CLOSED_FORM_TWO_TRACE_TRANSITION_CROSSING) {
      return new SingleTransitionCrossingRouteSolver({
        nodeWithPortPoints: this.nodeWithPortPoints,
        viaDiameter: this.constructorParams.viaDiameter,
      }) as any
    }
    if (hyperParameters.CLOSED_FORM_SINGLE_TRANSITION) {
      return new SingleTransitionIntraNodeSolver({
        nodeWithPortPoints: this.nodeWithPortPoints,
        viaDiameter: this.constructorParams.viaDiameter,
      }) as any
    }
    if (hyperParameters.THROUGH_OBSTACLE) {
      return new SingleTransitionThroughObstacleIntraNodeSolver({
        nodeWithPortPoints: this.nodeWithPortPoints,
        obstacles: this.constructorParams.obstacles,
        connMap: this.connMap,
        layerCount: this.constructorParams.layerCount,
        viaDiameter: this.constructorParams.viaDiameter,
        traceThickness: this.constructorParams.traceWidth,
      }) as any
    }
    if (hyperParameters.MULTI_HEAD_POLYLINE_SOLVER) {
      return new MultiHeadPolyLineIntraNodeSolver3({
        nodeWithPortPoints: this.nodeWithPortPoints,
        connMap: this.connMap,
        hyperParameters: hyperParameters,
        viaDiameter: this.constructorParams.viaDiameter,
      }) as any
    }
    return new CachedIntraNodeRouteSolver({
      ...this.constructorParams,
      hyperParameters,
      precomputedIntraNodeRouteParams: this.precomputedIntraNodeRouteParams,
    })
  }

  onSolve(solver: SupervisedSolver<IntraNodeRouteSolver>) {
    let routes: HighDensityIntraNodeRoute[]
    if (
      (solver.solver as any) instanceof HighDensitySolverA01 ||
      (solver.solver as any) instanceof HighDensityA03Solver ||
      (solver.solver as any) instanceof HighDensitySolverA13
    ) {
      routes = (solver.solver as any).getOutput()
    } else {
      routes = solver.solver.solvedRoutes
    }
    const routesWithRootConnectionNames = routes.map((route) => {
      const matchingPortPoint = this.nodeWithPortPoints.portPoints.find(
        (p) => p.connectionName === route.connectionName,
      )
      if (matchingPortPoint?.rootConnectionName) {
        return {
          ...route,
          rootConnectionName: matchingPortPoint.rootConnectionName,
        }
      }
      return route
    })
    const repairedRoutes = repairDisconnectedSameRootPortPoints(
      routesWithRootConnectionNames,
      this.nodeWithPortPoints,
    )
    const forbiddenRoute = repairedRoutes.find((route) => {
      const allowedZ = getAllowedZForNodeConnection(this.nodeWithPortPoints, route.connectionName, route.rootConnectionName)
      return route.route.some((point) => !allowedZ.includes(point.z))
    })
    if (forbiddenRoute) {
      solver.solver.solved = false
      solver.solver.failed = true
      solver.solver.error = `Candidate uses a forbidden wire layer for "${forbiddenRoute.connectionName}"`
      this.solved = false
      this.winningSolver = undefined
      return
    }

    this.solvedRoutes = repairedRoutes
  }
}
