import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter"
import { changedFanoutCopperIsSelfClear } from "./normalize-fanout-plan-corners"
import { getSourcePadReentries } from "./source-pad-reentry"
import { validateRoutedCopperDrc } from "./validate-routed-copper-drc"
import type { FanoutRoutePlan, FanoutRoutePoint, RoutedSegment } from "./types"

const EPSILON = 1e-9
const distance = (a: { x: number; y: number }, b: { x: number; y: number }): number => Math.hypot(a.x - b.x, a.y - b.y)
const hasPortAnchor = (point: FanoutRoutePoint): boolean =>
  "start_pcb_port_id" in point && !!point.start_pcb_port_id ||
  "end_pcb_port_id" in point && !!point.end_pcb_port_id ||
  "pcb_port_id" in point && !!point.pcb_port_id ||
  "pointId" in point && !!point.pointId

function routeSegments(route: readonly FanoutRoutePoint[]): RoutedSegment[] {
  return route.slice(1).flatMap((point, index) => {
    const previous = route[index]!
    return point.route_type === "wire" && previous.route_type === "wire" && point.layer === previous.layer && distance(point, previous) > EPSILON
      ? [{ start: { x: previous.x, y: previous.y }, end: { x: point.x, y: point.y }, layer: point.layer, width: Math.max(previous.width, point.width) }]
      : []
  })
}

function hasConventionalCorners(route: readonly FanoutRoutePoint[]): boolean {
  for (let index = 1; index < route.length; index++) {
    const a = route[index - 1]!, b = route[index]!
    if (a.route_type !== "wire" || b.route_type !== "wire" || a.layer !== b.layer) continue
    const dx = b.x - a.x, dy = b.y - a.y
    if (Math.hypot(dx, dy) <= EPSILON || Math.min(Math.abs(dx), Math.abs(dy)) > EPSILON && Math.abs(Math.abs(dx) - Math.abs(dy)) > EPSILON) return false
    const c = route[index + 1]
    if (!c || c.route_type !== "wire" || c.layer !== b.layer) continue
    const ox = c.x - b.x, oy = c.y - b.y, denominator = Math.hypot(dx, dy) * Math.hypot(ox, oy)
    if (denominator <= EPSILON * EPSILON || (dx * ox + dy * oy) / denominator < Math.SQRT1_2 - EPSILON) return false
  }
  return true
}

/** Clean newly computed source copper without moving terminals or barrels.
 * Supplied/held traces stay byte exact. Every changed path retains the native
 * widths and passes source, self and collective physical clearance checks.
 */
export function normalizeFreshSourceCorners(params: {
  inputSrj: SimpleRouteJson
  plans: readonly FanoutRoutePlan[]
  clearance: number
  immutableTraceIds?: ReadonlySet<string>
}): FanoutRoutePlan[] | null {
  const { inputSrj, clearance } = params
  const supplied = new Map((inputSrj.traces ?? []).map(trace => [trace.pcb_trace_id, trace]))
  const plans: FanoutRoutePlan[] = []
  for (const original of params.plans) {
    const inputTrace = supplied.get(original.trace.pcb_trace_id)
    if (inputTrace && JSON.stringify(inputTrace) !== JSON.stringify(original.trace)) return null
    const immutable = !!inputTrace || params.immutableTraceIds?.has(original.trace.pcb_trace_id) === true
    const route = original.trace.route.map(point => ({ ...point }))
    const escapeEnd = original.sourceEscapeSegmentCount === undefined ? undefined : original.segments[original.sourceEscapeSegmentCount - 1]
    const anchored = (index: number): boolean => index === 0 || index === route.length - 1 || hasPortAnchor(route[index]!) ||
      !!escapeEnd && route[index]!.route_type === "wire" && route[index]!.layer === escapeEnd.layer && distance(route[index]!, escapeEnd.end) <= EPSILON
    for (let index = 1; index < route.length - 1;) {
      const a = route[index - 1]!, b = route[index]!
      if (a.route_type === "wire" && b.route_type === "wire" && a.layer === b.layer && a.width === b.width && distance(a, b) <= EPSILON && !anchored(index)) {
        route.splice(index, 1)
        continue
      }
      index++
    }
    for (let index = 1; index < route.length - 1; index++) {
      const a = route[index - 1]!, b = route[index]!, c = route[index + 1]!
      if (a.route_type !== "wire" || b.route_type !== "wire" || c.route_type !== "wire" || a.layer !== b.layer || b.layer !== c.layer || a.width !== b.width || b.width !== c.width || anchored(index)) continue
      const ix = b.x - a.x, iy = b.y - a.y, ox = c.x - b.x, oy = c.y - b.y, il = Math.hypot(ix, iy), ol = Math.hypot(ox, oy)
      if (il <= EPSILON || ol <= EPSILON || Math.abs(ix * ox + iy * oy) > EPSILON * il * ol || Math.min(Math.abs(ix), Math.abs(iy)) > EPSILON || Math.min(Math.abs(ox), Math.abs(oy)) > EPSILON) continue
      const chamfer = Math.min(b.width / 2, il / 2, ol / 2)
      route.splice(index, 1, { ...b, x: b.x - ix / il * chamfer, y: b.y - iy / il * chamfer }, { ...b, x: b.x + ox / ol * chamfer, y: b.y + oy / ol * chamfer })
      index++
    }
    const changed = JSON.stringify(route) !== JSON.stringify(original.trace.route)
    if (changed && immutable) return null
    const segments = changed ? routeSegments(route) : original.segments
    const plan = changed ? { ...original, trace: { ...original.trace, route }, segments, length: segments.reduce((sum, segment) => sum + distance(segment.start, segment.end), 0) } : original
    if (changed && escapeEnd) {
      const endIndex = segments.findIndex(segment => segment.layer === escapeEnd.layer && distance(segment.end, escapeEnd.end) <= EPSILON)
      if (endIndex < 0) return null
      plan.sourceEscapeSegmentCount = endIndex + 1
    }
    if (JSON.stringify(route[0]) !== JSON.stringify(original.trace.route[0]) || JSON.stringify(route.at(-1)) !== JSON.stringify(original.trace.route.at(-1)) ||
      JSON.stringify(route.filter(point => point.route_type !== "wire")) !== JSON.stringify(original.trace.route.filter(point => point.route_type !== "wire")) ||
      !hasConventionalCorners(route) || getSourcePadReentries(plan, clearance).length ||
      !changedFanoutCopperIsSelfClear(plan, segments, clearance, new Set(segments.map((_, index) => index)))) return null
    plans.push(plan)
  }
  const candidates = plans.filter(plan => !supplied.has(plan.trace.pcb_trace_id)).map(plan => plan.trace)
  return validateRoutedCopperDrc({ inputSrj, routedSrj: { ...inputSrj, traces: [...(inputSrj.traces ?? []), ...candidates] }, clearance, allowBlindAndBuriedVias: false }).valid ? plans : null
}
