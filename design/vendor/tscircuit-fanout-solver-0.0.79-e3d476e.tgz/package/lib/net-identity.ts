import type {
  Obstacle,
  SimpleRouteConnection,
  SimpleRouteJson,
  SimplifiedPcbTrace,
} from "@tscircuit/capacity-autorouter"

interface ElectricalNetIdentity {
  connectionNetKeys: Map<string, string>
  tokenNetKeys: Map<string, string>
  conflictingSuppliedTraceIds: Set<string>
  obstacleNetKeys: WeakMap<Obstacle, ReadonlySet<string>>
}

const identityCache = new WeakMap<SimpleRouteJson, ElectricalNetIdentity>()

export function getConnectionNetKey(connection: SimpleRouteConnection): string {
  return (
    connection.netConnectionName ??
    connection.rootConnectionName ??
    connection.name
  )
}

function addTokenNet(
  tokenNetKeys: Map<string, Set<string>>,
  token: string | undefined,
  netKey: string,
): boolean {
  if (!token) return false
  const keys = tokenNetKeys.get(token) ?? new Set<string>()
  const sizeBefore = keys.size
  keys.add(netKey)
  tokenNetKeys.set(token, keys)
  return keys.size !== sizeBefore
}

function getKnownNetKeys(
  tokenNetKeys: Map<string, Set<string>>,
  tokens: readonly string[],
): Set<string> {
  const keys = new Set<string>()
  for (const token of tokens) {
    for (const key of tokenNetKeys.get(token) ?? []) keys.add(key)
  }
  return keys
}

function suppliedTraceTokens(trace: SimplifiedPcbTrace): string[] {
  return [
    trace.connection_name,
    trace.pcb_trace_id,
    ...(trace.connectsTo ?? []),
    ...("source_trace_id" in trace && typeof trace.source_trace_id === "string"
      ? [trace.source_trace_id]
      : []),
    ...trace.route.flatMap((point) =>
      point.route_type === "wire"
        ? [point.start_pcb_port_id, point.end_pcb_port_id]
        : [],
    ),
  ].filter(
    (token): token is string => typeof token === "string" && token.length > 0,
  )
}

function createElectricalNetIdentity(
  srj: SimpleRouteJson,
): ElectricalNetIdentity {
  const connectionNetKeys = new Map<string, string>()
  const tokenNetKeys = new Map<string, Set<string>>()

  for (const connection of srj.connections) {
    const netKey = getConnectionNetKey(connection)
    connectionNetKeys.set(connection.name, netKey)
    addTokenNet(tokenNetKeys, connection.name, netKey)
    addTokenNet(tokenNetKeys, connection.rootConnectionName, netKey)
    addTokenNet(tokenNetKeys, connection.netConnectionName, netKey)
    for (const point of connection.pointsToConnect) {
      addTokenNet(tokenNetKeys, point.pointId, netKey)
      addTokenNet(tokenNetKeys, point.pcb_port_id, netKey)
    }
  }

  for (const trace of srj.traces ?? []) {
    if (!trace.connection_name) continue
    // Earlier-phase copper remains authoritative even when its owner has no
    // active source connection. Seed its original declared owner, then resolve
    // native pad/port aliases without modifying any supplied trace or obstacle.
    const netKey =
      connectionNetKeys.get(trace.connection_name) ?? trace.connection_name
    connectionNetKeys.set(trace.connection_name, netKey)
    addTokenNet(tokenNetKeys, trace.connection_name, netKey)
    // An opaque trace ID cannot merge a previously known foreign owner. If an
    // ID is already known, native obstacle metadata must prove equivalence;
    // otherwise the canonical conflict check below rejects the supplied trace.
    if (!tokenNetKeys.has(trace.pcb_trace_id)) {
      addTokenNet(tokenNetKeys, trace.pcb_trace_id, netKey)
    }
  }

  // Obstacle metadata often contains both a connection id and a lower-level
  // connectivity id. Propagate the known net across that metadata so another
  // pad that only names the connectivity id is still recognized as same-net.
  for (let pass = 0; pass < 2; pass++) {
    let changed = false
    for (const obstacle of srj.obstacles) {
      const netKeys = getKnownNetKeys(tokenNetKeys, obstacle.connectedTo)
      if (netKeys.size !== 1) continue
      const netKey = [...netKeys][0]!
      for (const token of obstacle.connectedTo) {
        changed = addTokenNet(tokenNetKeys, token, netKey) || changed
      }
    }
    if (!changed) break
  }

  const parentByNetKey = new Map<string, string>()
  const findRoot = (netKey: string): string => {
    const parent = parentByNetKey.get(netKey) ?? netKey
    parentByNetKey.set(netKey, parent)
    if (parent === netKey) return netKey
    const root = findRoot(parent)
    parentByNetKey.set(netKey, root)
    return root
  }
  const union = (first: string, second: string): void => {
    const firstRoot = findRoot(first)
    const secondRoot = findRoot(second)
    if (firstRoot !== secondRoot) parentByNetKey.set(secondRoot, firstRoot)
  }
  for (const netKeys of tokenNetKeys.values()) {
    const [firstNetKey, ...otherNetKeys] = [...netKeys]
    if (!firstNetKey) continue
    for (const otherNetKey of otherNetKeys) union(firstNetKey, otherNetKey)
  }
  for (const obstacle of srj.obstacles) {
    const [firstNetKey, ...otherNetKeys] = [
      ...getKnownNetKeys(tokenNetKeys, obstacle.connectedTo),
    ]
    if (!firstNetKey) continue
    for (const otherNetKey of otherNetKeys) union(firstNetKey, otherNetKey)
  }
  for (const [connectionName, netKey] of connectionNetKeys) {
    connectionNetKeys.set(connectionName, findRoot(netKey))
  }
  // Every net associated with a token was unioned above. Store its one
  // canonical key directly instead of repeatedly querying a singleton Set.
  const resolvedTokenNetKeys = new Map<string, string>()
  for (const [token, netKeys] of tokenNetKeys) {
    const first = netKeys.values().next().value
    if (first !== undefined) resolvedTokenNetKeys.set(token, findRoot(first))
  }

  // Raw aliases can name several active connections that the original native
  // pad metadata proves are one net. Bind those only after canonicalization;
  // a supplied trace claiming distinct native owners must never union them.
  const conflictingSuppliedTraceIds = new Set<string>()
  for (const trace of srj.traces ?? []) {
    const tokens = suppliedTraceTokens(trace)
    const known = new Set(
      tokens.flatMap((token) => {
        const key = resolvedTokenNetKeys.get(token)
        return key === undefined ? [] : [key]
      }),
    )
    if (known.size > 1) {
      conflictingSuppliedTraceIds.add(trace.pcb_trace_id)
      continue
    }
    const key = known.values().next().value
    if (key === undefined || !trace.connection_name) continue
    connectionNetKeys.set(trace.connection_name, key)
    for (const token of tokens) resolvedTokenNetKeys.set(token, key)
  }
  for (let pass = 0; pass < 2; pass++) {
    let changed = false
    for (const obstacle of srj.obstacles) {
      const known = new Set(
        obstacle.connectedTo.flatMap((token) => {
          const key = resolvedTokenNetKeys.get(token)
          return key === undefined ? [] : [key]
        }),
      )
      if (known.size !== 1) continue
      const key = known.values().next().value!
      for (const token of obstacle.connectedTo) {
        if (!resolvedTokenNetKeys.has(token)) {
          resolvedTokenNetKeys.set(token, key)
          changed = true
        }
      }
    }
    if (!changed) break
  }

  return {
    connectionNetKeys,
    tokenNetKeys: resolvedTokenNetKeys,
    conflictingSuppliedTraceIds,
    obstacleNetKeys: new WeakMap(),
  }
}

function getElectricalNetIdentity(srj: SimpleRouteJson): ElectricalNetIdentity {
  const cached = identityCache.get(srj)
  if (cached) return cached
  const identity = createElectricalNetIdentity(srj)
  identityCache.set(srj, identity)
  return identity
}

export function getConflictingSuppliedTraceIds(
  srj: SimpleRouteJson,
): ReadonlySet<string> {
  return getElectricalNetIdentity(srj).conflictingSuppliedTraceIds
}

export function connectionsShareElectricalNet(
  srj: SimpleRouteJson,
  firstConnectionName: string,
  secondConnectionName: string,
): boolean {
  const identity = getElectricalNetIdentity(srj)
  const firstNet = identity.connectionNetKeys.get(firstConnectionName)
  const secondNet = identity.connectionNetKeys.get(secondConnectionName)
  return firstNet !== undefined && firstNet === secondNet
}

export function obstacleSharesElectricalNet(
  srj: SimpleRouteJson,
  obstacle: Obstacle,
  connectionName: string,
): boolean {
  const identity = getElectricalNetIdentity(srj)
  const connectionNet = identity.connectionNetKeys.get(connectionName)
  if (!connectionNet) return false
  let obstacleKeys = identity.obstacleNetKeys.get(obstacle)
  if (!obstacleKeys) {
    obstacleKeys = new Set(
      obstacle.connectedTo.flatMap((token) => {
        const key = identity.tokenNetKeys.get(token)
        return key === undefined ? [] : [key]
      }),
    )
    identity.obstacleNetKeys.set(obstacle, obstacleKeys)
  }
  return obstacleKeys.has(connectionNet)
}
