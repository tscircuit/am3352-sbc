import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter"
import { buildOutputSimpleRouteJson } from "./build-output"
import { FanoutSolver } from "./fanout-solver"
import {
  distance,
  distancePointToSegment,
  distanceSegmentToSegment,
  segmentsAreClear,
} from "./geometry"
import { getNativeSourceCopperBlockers } from "./get-native-source-copper-blockers"
import { getCopperLayerNames } from "./layer-names"
import {
  getComponentDogboneViaSiteCandidates,
  matchComponentDogboneViaSites,
  type ComponentDogboneViaSiteCandidate,
} from "./match-component-dogbone-via-sites"
import { validateFanoutSolution } from "./validate-fanout-solution"
import { validateRoutedCopperDrc } from "./validate-routed-copper-drc"
import type {
  FanoutDirection,
  FanoutEdge,
  FanoutRoutePlan,
  PreparedBus,
} from "./types"

const EPSILON = 1e-7
const SITE_EPSILON = 1e-9
const SIDES: readonly FanoutEdge[] = ["left", "right", "top", "bottom"]
const DIRECTION: Record<FanoutEdge, FanoutDirection> = {
  left: "left", right: "right", top: "up", bottom: "down",
}

export interface CriticalSourceCorridorParams {
  srj: SimpleRouteJson
  /** Independent boundary singletons sharing one outside source layer. */
  buses: readonly PreparedBus[]
  traceWidth: number
  clearance: number
  viaDiameter: number
  viaHoleDiameter: number
  /** Total states across all bounded corridor selections. Defaults to 200000. */
  maximumCandidateSearchStates?: number
  /** Public singleton solver steps per physical side. Defaults to 10000. */
  maximumCandidateSolverSteps?: number
  /** Active solver time per physical side, excluding caller pauses. Defaults to 2000. */
  maximumCandidateSolverMilliseconds?: number
  /** Alternate choices of scarce native-domain owners. Defaults to 16. */
  maximumSourceVariants?: number
}

function bitCount(value: bigint): number {
  let count = 0
  while (value) {
    value &= value - 1n
    count++
  }
  return count
}

/** Local corner bodies may touch themselves; separated returning arms may not. */
function sourceGeometryIsSafe(plan: FanoutRoutePlan, clearance: number): boolean {
  const segments = plan.segments
  const lengths = [0]
  for (let index = 0; index < segments.length; index++) {
    const segment = segments[index]!
    const dx = segment.end.x - segment.start.x
    const dy = segment.end.y - segment.start.y
    const length = distance(segment.start, segment.end)
    if (![dx, dy, length, segment.width].every(Number.isFinite) || segment.width <= 0 ||
      Math.min(Math.abs(dx), Math.abs(dy), Math.abs(Math.abs(dx) - Math.abs(dy))) > EPSILON)
      return false
    lengths.push(lengths.at(-1)! + length)
    const next = segments[index + 1]
    if (!next) continue
    if (distance(segment.end, next.start) > EPSILON) return false
    const nextLength = distance(next.start, next.end)
    if (length > EPSILON && nextLength > EPSILON &&
      (dx * (next.end.x - next.start.x) + dy * (next.end.y - next.start.y)) /
        (length * nextLength) < Math.SQRT1_2 - EPSILON)
      return false
  }
  for (let lo = 0; lo < segments.length; lo++) {
    for (let hi = lo + 1; hi < segments.length; hi++) {
      const a = segments[lo]!, b = segments[hi]!
      const required = (a.width + b.width) / 2 + clearance
      if (lengths[hi]! - lengths[lo + 1]! <= required + EPSILON ||
        distanceSegmentToSegment(a.start, a.end, b.start, b.end) >= required - EPSILON)
        continue
      let xSign = 0, ySign = 0
      for (let index = lo; index <= hi; index++) {
        const segment = segments[index]!
        const dx = segment.end.x - segment.start.x, dy = segment.end.y - segment.start.y
        if (Math.abs(dx) > EPSILON) {
          const sign = Math.sign(dx)
          if (xSign && sign !== xSign) return false
          xSign = sign
        }
        if (Math.abs(dy) > EPSILON) {
          const sign = Math.sign(dy)
          if (ySign && sign !== ySign) return false
          ySign = sign
        }
      }
    }
  }
  return true
}

function* sourceSideCandidateSteps(params: CriticalSourceCorridorParams, bus: PreparedBus,
  side: FanoutEdge, sourceLayer: string): Generator<void, FanoutRoutePlan | null> {
  const { srj, traceWidth, clearance, viaDiameter, viaHoleDiameter } = params
  const connection = bus.connections[0]!
  const original = srj.connections[connection.connectionIndex]!
  // The full native obstacles, supplied copper, and authoritative terminals
  // remain in every public singleton solve. Only the connection list changes.
  const input = { ...srj, connections: [original] }
  const solver = new FanoutSolver(input, {
    sourceComponentId: bus.componentId,
    sharedBoundary: bus.sharedBoundary,
    buses: [{ busId: bus.busId, connectionNames: [original.name],
      sourceComponentId: bus.componentId, allowedLayers: [sourceLayer],
      preferredExit: side, exitEdge: side }],
    availableCornersAndSides: [side], escapeLayers: [sourceLayer],
    allowBlindAndBuriedVias: false, singleLayerPushAndShove: true,
    singleLayerAdaptiveExits: true, completeOriginalEndpoints: false,
    traceWidth, clearance, viaDiameter, viaHoleDiameter,
  })
  let steps = 0, activeMilliseconds = 0
  while (!solver.solved && !solver.failed &&
    steps < (params.maximumCandidateSolverSteps ?? 10000) &&
    activeMilliseconds < (params.maximumCandidateSolverMilliseconds ?? 2000)) {
    const start = performance.now()
    solver.step()
    activeMilliseconds += performance.now() - start
    if (++steps % 10 === 0) yield
  }
  if (!solver.solved || activeMilliseconds >= (params.maximumCandidateSolverMilliseconds ?? 2000))
    return null
  // getOutput independently revalidates the complete public singleton prefix.
  const output = solver.getOutput()
  if (!output.validation.valid || output.fanoutTraces.length !== 1) return null
  const trace = output.fanoutTraces[0]!
  if (trace.connection_name !== original.name || trace.route.length < 2 ||
    trace.route.some(point => point.route_type !== "wire" || point.layer !== sourceLayer))
    return null
  const wires = trace.route.filter(point => point.route_type === "wire")
  const first = wires[0]!, last = wires.at(-1)!
  const source = connection.sourcePoint, boundary = bus.sharedBoundary
  if (distance(first, source) > EPSILON ||
    source.pcb_port_id && first.start_pcb_port_id !== source.pcb_port_id)
    return null
  const onSide = side === "left" ? Math.abs(last.x - boundary.minX) :
    side === "right" ? Math.abs(last.x - boundary.maxX) :
      side === "top" ? Math.abs(last.y - boundary.maxY) : Math.abs(last.y - boundary.minY)
  if (onSide > EPSILON || wires.some(point => !Number.isFinite(point.x) || !Number.isFinite(point.y) ||
    point.x < boundary.minX - EPSILON || point.x > boundary.maxX + EPSILON ||
    point.y < boundary.minY - EPSILON || point.y > boundary.maxY + EPSILON ||
    ((Math.abs(point.x - boundary.minX) <= EPSILON || Math.abs(point.x - boundary.maxX) <= EPSILON ||
      Math.abs(point.y - boundary.minY) <= EPSILON || Math.abs(point.y - boundary.maxY) <= EPSILON) &&
      distance(point, last) > EPSILON)))
    return null
  const segments = wires.slice(1).map((end, index) => ({
    start: { x: wires[index]!.x, y: wires[index]!.y }, end: { x: end.x, y: end.y },
    width: Math.max(wires[index]!.width, end.width), layer: sourceLayer,
  }))
  const plan: FanoutRoutePlan = {
    busId: bus.busId, connectionName: original.name, connectionIndex: connection.connectionIndex,
    sourcePointIndex: connection.sourcePointIndex, sourcePoint: connection.sourcePoint,
    sourceObstacle: connection.sourceObstacle, sourceLayer,
    targetPoint: connection.targetPoint, targetLayer: sourceLayer, termination: bus.termination,
    direction: DIRECTION[side], ...(bus.exitEdge ? { exitEdge: bus.exitEdge } : {}),
    exitPoint: { x: last.x, y: last.y }, trace, segments,
    sourceEscapeSegmentCount: segments.length,
    length: segments.reduce((sum, segment) => sum + distance(segment.start, segment.end), 0),
  }
  if (!sourceGeometryIsSafe(plan, clearance)) return null
  const drc = validateRoutedCopperDrc({ inputSrj: srj,
    routedSrj: { ...srj, traces: [...(srj.traces ?? []), trace] }, clearance,
    allowBlindAndBuriedVias: false })
  return drc.valid ? plan : null
}

/**
 * Hold complete source-layer routes for native sources that cannot all take a
 * conventional drilled via. Candidate copper is freshly generated through the
 * public solver, and a bounded CSP preserves the remaining native via domains.
 * The result is an entire critical cohort, not a complete mixed-layer fanout;
 * null means its collective copper or remaining joint via assignment failed.
 */
export function* selectCriticalSourceCorridorsSteps(params: CriticalSourceCorridorParams):
  Generator<void, FanoutRoutePlan[] | null> {
  const { srj, buses, traceWidth, clearance, viaDiameter, viaHoleDiameter } = params
  for (const [name, value] of [
    ["maximumCandidateSearchStates", params.maximumCandidateSearchStates ?? 200000],
    ["maximumCandidateSolverSteps", params.maximumCandidateSolverSteps ?? 10000],
    ["maximumSourceVariants", params.maximumSourceVariants ?? 16],
  ] as const)
    if (!Number.isSafeInteger(value) || value < 1)
      throw new Error(`${name} must be a positive safe integer`)
  if (!Number.isFinite(params.maximumCandidateSolverMilliseconds ?? 2000) ||
    (params.maximumCandidateSolverMilliseconds ?? 2000) <= 0)
    throw new Error("maximumCandidateSolverMilliseconds must be positive and finite")
  if ((params.maximumSourceVariants ?? 16) > 16)
    throw new Error("maximumSourceVariants must not exceed 16")
  if (!buses.length) return []
  if (new Set(buses.map(bus => bus.busId)).size !== buses.length ||
    new Set(buses.flatMap(bus => bus.connections.map(connection => connection.connectionIndex))).size !==
      buses.reduce((count, bus) => count + bus.connections.length, 0))
    throw new Error("Critical source corridors require unique bus and connection identities")
  const boundary = buses[0]!.sharedBoundary
  if (buses.some(bus => (["minX", "maxX", "minY", "maxY"] as const)
    .some(axis => bus.sharedBoundary[axis] !== boundary[axis])))
    throw new Error("Critical source corridors require one shared boundary")
  if (buses.some(bus => bus.termination.type !== "boundary" || bus.connections.length !== 1 ||
    bus.connections[0]!.hasExplicitLayeredExitTarget))
    return null
  const layerNames = getCopperLayerNames(srj.layerCount)
  if (layerNames.length < 2 || (srj as SimpleRouteJson & { allowBlindAndBuriedVias?: boolean })
    .allowBlindAndBuriedVias === true)
    return null
  const surfaceLayers = [layerNames[0]!, layerNames.at(-1)!]
  const sourceLayer = buses[0]!.connections[0]!.sourceLayer
  if (!surfaceLayers.includes(sourceLayer) || buses.some(bus => bus.connections[0]!.sourceLayer !== sourceLayer))
    return null
  const bridgeLayer = surfaceLayers.find(layer => layer !== sourceLayer)!
  const allowed = (bus: PreparedBus, layer: string): boolean =>
    (bus.routableEscapeLayers ?? bus.allowedLayers ?? surfaceLayers).includes(layer)
  for (const bus of buses) {
    const connection = bus.connections[0]!
    const original = srj.connections[connection.connectionIndex]
    if (!original || original.name !== connection.connection.name ||
      JSON.stringify(original.pointsToConnect[connection.sourcePointIndex]) !== JSON.stringify(connection.sourcePoint))
      throw new Error("Critical source index must identify its exact original source terminal")
    if (!surfaceLayers.some(layer => allowed(bus, layer))) return null
  }
  const byIndex = new Map(buses.map(bus => [bus.connections[0]!.connectionIndex, bus]))
  const { blockingSegments: nativeSegments, blockingVias: nativeVias } =
    getNativeSourceCopperBlockers(srj, buses)
  const rules = { traceWidth, clearance, viaDiameter, viaHoleDiameter, expandLocalSites: true,
    additionalObstacles: srj.obstacles, blockingSegments: nativeSegments, blockingVias: nativeVias }
  const baseline = new Map<number, ComponentDogboneViaSiteCandidate[]>()
  const mandatory = new Set<number>()
  for (const bus of buses) {
    const index = bus.connections[0]!.connectionIndex
    const domain = getComponentDogboneViaSiteCandidates([bus], rules)
    baseline.set(index, domain)
    if (!allowed(bus, bridgeLayer) || domain.length === 0) mandatory.add(index)
    yield
  }
  const cost = (index: number): number => {
    const source = byIndex.get(index)!.connections[0]!.sourcePoint
    return Math.min(source.x - boundary.minX, boundary.maxX - source.x,
      source.y - boundary.minY, boundary.maxY - source.y)
  }
  const small = buses.filter(bus => !mandatory.has(bus.connections[0]!.connectionIndex) &&
    baseline.get(bus.connections[0]!.connectionIndex)!.length <= 3)
  const pairs: Array<{ first: number; second: number; preferredSource: number }> = []
  for (let firstIndex = 0; firstIndex < small.length; firstIndex++) {
    for (let secondIndex = firstIndex + 1; secondIndex < small.length; secondIndex++) {
      const first = small[firstIndex]!.connections[0]!.connectionIndex
      const second = small[secondIndex]!.connections[0]!.connectionIndex
      if (baseline.get(first)!.some(a => baseline.get(second)!.some(b =>
        distance(a.point, b.point) < viaDiameter + clearance - SITE_EPSILON)) &&
        !matchComponentDogboneViaSites([small[firstIndex]!, small[secondIndex]!], rules))
        pairs.push({ first, second, preferredSource: cost(first) <= cost(second) ? first : second })
      yield
    }
  }
  const candidateIndexes = new Set([...mandatory, ...pairs.flatMap(pair => [pair.first, pair.second])])
  const candidates = new Map<number, FanoutRoutePlan[]>()
  for (const bus of buses.filter(bus => candidateIndexes.has(bus.connections[0]!.connectionIndex))) {
    const index = bus.connections[0]!.connectionIndex, plans: FanoutRoutePlan[] = []
    candidates.set(index, plans)
    if (!allowed(bus, sourceLayer)) continue
    // Side cost and geometry, rather than board coordinates or owner names,
    // determine the deterministic public candidate ordering.
    const source = bus.connections[0]!.sourcePoint
    const sideCost = (side: FanoutEdge): number => side === "left" ? source.x - boundary.minX :
      side === "right" ? boundary.maxX - source.x : side === "top" ? boundary.maxY - source.y :
        source.y - boundary.minY
    const sides = SIDES.filter(side => (!bus.exitEdge || bus.exitEdge === side) &&
      (!bus.preferredExit || bus.preferredExit === side))
      .toSorted((a, b) => sideCost(a) - sideCost(b) || a.localeCompare(b))
    for (const side of sides) {
      const plan = yield* sourceSideCandidateSteps(params, bus, side, sourceLayer)
      if (plan) plans.push(plan)
      yield
    }
  }
  const variants: Set<number>[] = []
  const pendingVariants = [{ pairIndex: 0, selected: new Set(mandatory) }]
  let variantStates = 0
  while (pendingVariants.length && variants.length < (params.maximumSourceVariants ?? 16) &&
    variantStates++ < (params.maximumCandidateSearchStates ?? 200000)) {
    let { pairIndex, selected } = pendingVariants.pop()!
    while (pairIndex < pairs.length &&
      (selected.has(pairs[pairIndex]!.first) || selected.has(pairs[pairIndex]!.second)))
      pairIndex++
    if (pairIndex === pairs.length) {
      if (!variants.some(prior => prior.size === selected.size && [...prior].every(index => selected.has(index))))
        variants.push(selected)
      continue
    }
    const pair = pairs[pairIndex]!
    // LIFO order preserves the nearest-boundary preference of a depth-first
    // expansion without unbounded recursion through overlapping scarce pairs.
    for (const member of [pair.preferredSource === pair.first ? pair.second : pair.first,
      pair.preferredSource])
      pendingVariants.push({ pairIndex: pairIndex + 1, selected: new Set([...selected, member]) })
    if (variantStates % 256 === 0) yield
  }
  interface Selection {
    plans: FanoutRoutePlan[]
    viable: number
    score: number
    length: number
    critical: Set<number>
  }
  let visited = 0, best: Selection | null = null
  for (const critical of variants) {
    const remainingIndexes = buses.filter(bus => !critical.has(bus.connections[0]!.connectionIndex))
      .map(bus => bus.connections[0]!.connectionIndex)
    const initial = remainingIndexes.map(index => (1n << BigInt(baseline.get(index)!.length)) - 1n)
    const entries = buses.filter(bus => critical.has(bus.connections[0]!.connectionIndex))
      .map(bus => ({ index: bus.connections[0]!.connectionIndex,
        plans: candidates.get(bus.connections[0]!.connectionIndex) ?? [] }))
      .toSorted((a, b) => a.plans.length - b.plans.length || cost(b.index) - cost(a.index))
    if (entries.some(entry => entry.plans.length === 0)) continue
    const masks = new Map<FanoutRoutePlan, bigint[]>()
    for (const entry of entries) {
      for (const plan of entry.plans) {
        masks.set(plan, remainingIndexes.map(index => {
          const connection = byIndex.get(index)!.connections[0]!
          return baseline.get(index)!.reduce((mask, candidate, siteIndex) =>
            plan.segments.every(segment =>
              distancePointToSegment(candidate.point, segment.start, segment.end) >=
                (viaDiameter + segment.width) / 2 + clearance - SITE_EPSILON &&
              (segment.layer !== connection.sourceLayer ||
                distanceSegmentToSegment(connection.sourcePoint, candidate.point, segment.start, segment.end) >=
                  (traceWidth + segment.width) / 2 + clearance - SITE_EPSILON))
              ? mask | (1n << BigInt(siteIndex)) : mask, 0n)
        }))
        yield
      }
    }
    const compatibility = new Map<FanoutRoutePlan, Map<FanoutRoutePlan, boolean>>()
    const clear = (a: FanoutRoutePlan, b: FanoutRoutePlan): boolean => {
      const cache = compatibility.get(a) ?? new Map<FanoutRoutePlan, boolean>()
      compatibility.set(a, cache)
      if (!cache.has(b)) cache.set(b, a.segments.every(first =>
        b.segments.every(second => segmentsAreClear(first, second, clearance))))
      return cache.get(b)!
    }
    const pending = [{ depth: 0, plans: [] as FanoutRoutePlan[], domains: initial, length: 0 }]
    while (pending.length && visited < (params.maximumCandidateSearchStates ?? 200000)) {
      const { depth, plans, domains, length } = pending.pop()!
      if (++visited % 256 === 0) yield
      const viable = domains.filter(mask => mask !== 0n).length
      const score = domains.reduce((sum, mask) => sum + Math.min(5, bitCount(mask)), 0)
      // An emptied native domain cannot be recovered by adding another held
      // corridor, so it is never a successful candidate for this variant.
      if (viable !== domains.length) continue
      if (best && (viable < best.viable || viable === best.viable && score < best.score)) continue
      if (depth === entries.length) {
        if (!best || viable > best.viable || viable === best.viable &&
          (score > best.score || score === best.score && length < best.length))
          best = { plans: [...plans], viable, score, length, critical }
        continue
      }
      const choices = entries[depth]!.plans.filter(plan => plans.every(accepted => clear(plan, accepted)))
        .map(plan => {
          const next = domains.map((mask, index) => mask & masks.get(plan)![index]!)
          return { plan, next, viable: next.filter(mask => mask !== 0n).length,
            score: next.reduce((sum, mask) => sum + Math.min(5, bitCount(mask)), 0) }
        }).toSorted((a, b) => b.viable - a.viable || b.score - a.score || a.plan.length - b.plan.length)
      for (const choice of choices.toReversed())
        pending.push({ depth: depth + 1, plans: [...plans, choice.plan], domains: choice.next,
          length: length + choice.plan.length })
    }
  }
  const selected = best
  if (!selected || selected.plans.length !== selected.critical.size) return null
  const remaining = buses.filter(bus => !selected.critical.has(bus.connections[0]!.connectionIndex))
  if (selected.viable !== remaining.length) return null
  const blockingSegments = [...nativeSegments, ...selected.plans.flatMap(plan =>
    plan.segments.map(segment => ({ connectionIndex: plan.connectionIndex, segment })))]
  const finalRules = { ...rules, blockingSegments }
  if (remaining.some(bus => !allowed(bus, bridgeLayer) ||
    getComponentDogboneViaSiteCandidates([bus], finalRules).length === 0))
    return null
  yield
  const matched = matchComponentDogboneViaSites(remaining, finalRules)
  if (!matched || matched.size !== remaining.length) return null
  const selectedBuses = buses.filter(bus => selected.critical.has(bus.connections[0]!.connectionIndex))
  const subsetConnections = selectedBuses.map(bus => srj.connections[bus.connections[0]!.connectionIndex]!)
  const subsetInput = { ...srj, connections: subsetConnections }
  const localIndex = new Map(selectedBuses.map((bus, index) => [bus.connections[0]!.connectionIndex, index]))
  const subsetPlans = selected.plans.map(plan => ({ ...plan, connectionIndex: localIndex.get(plan.connectionIndex)! }))
  const planByIndex = new Map(selected.plans.map(plan => [plan.connectionIndex, plan]))
  const subsetBuses = selectedBuses.map(bus => {
    const plan = planByIndex.get(bus.connections[0]!.connectionIndex)!
    return { ...bus, direction: plan.direction,
      preferredExit: plan.direction === "up" ? "top" as const : plan.direction === "down" ? "bottom" as const : plan.direction,
      connections: bus.connections.map(connection => ({ ...connection,
        connectionIndex: localIndex.get(connection.connectionIndex)! })) }
  })
  const output = buildOutputSimpleRouteJson({ inputSrj: subsetInput, plans: subsetPlans, layerNames })
  const contract = validateFanoutSolution({ inputSrj: subsetInput, outputSrj: output,
    plans: subsetPlans, preparedBuses: subsetBuses, sharedBoundary: boundary, clearance,
    allowBlindAndBuriedVias: false })
  const drc = validateRoutedCopperDrc({ inputSrj: srj,
    routedSrj: { ...srj, traces: [...(srj.traces ?? []), ...selected.plans.map(plan => plan.trace)] },
    clearance, allowBlindAndBuriedVias: false })
  return contract.valid && drc.valid ? selected.plans : null
}
