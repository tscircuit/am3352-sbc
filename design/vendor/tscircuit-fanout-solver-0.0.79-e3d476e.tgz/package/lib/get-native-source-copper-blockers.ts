import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter"
import { getAllRoutedTraceCopper } from "./get-routed-trace-copper"
import type { PreparedBus } from "./types"

/** Preserve supplied segment and physical barrel geometry. Only an unambiguous
 * original connection owner may exempt its own supplied copper. */
export function getNativeSourceCopperBlockers(srj: SimpleRouteJson, buses: readonly PreparedBus[]) {
  const byIndex = new Map(buses.flatMap(bus => bus.connections.map(connection =>
    [connection.connectionIndex, connection] as const)))
  const nativeCopper = getAllRoutedTraceCopper(srj, false)
  const ownersByToken = new Map<string, Set<number>>()
  const addOwnerToken = (token: string | undefined, index: number): void => {
    if (!token) return
    const owners = ownersByToken.get(token) ?? new Set<number>()
    owners.add(index)
    ownersByToken.set(token, owners)
  }
  for (const [index, connection] of srj.connections.entries()) {
    for (const token of [connection.name, connection.rootConnectionName, connection.netConnectionName,
      ...connection.pointsToConnect.flatMap(point => [point.pcb_port_id, point.pointId]),
      ...(byIndex.get(index)?.sourceObstacle.connectedTo ?? [])])
      addOwnerToken(token, index)
  }
  const nativeOwners = nativeCopper.map((copper, index) => {
    const tokens = [copper.connectionName, copper.trace.pcb_trace_id, ...(copper.trace.connectsTo ?? []),
      ...copper.trace.route.flatMap(point => point.route_type === "wire"
        ? [point.start_pcb_port_id, point.end_pcb_port_id] : [])]
    const owners = new Set(tokens.flatMap(token => token ? [...(ownersByToken.get(token) ?? [])] : []))
    // Ambiguous net aliases are hard foreign copper, never owner exemptions.
    return owners.size === 1 ? [...owners][0]! : -index - 1
  })
  return {
    blockingSegments: nativeCopper.flatMap((copper, index) => copper.segments.map(segment => ({
      connectionIndex: nativeOwners[index]!, segment,
    }))),
    blockingVias: nativeCopper.flatMap((copper, index) => copper.vias.map(via => ({
      connectionIndex: nativeOwners[index]!, ...via,
    }))),
  }
}
